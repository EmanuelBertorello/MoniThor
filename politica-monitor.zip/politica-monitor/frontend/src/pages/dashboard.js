// src/pages/dashboard.js
import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../lib/auth';
import { campaignsAPI, mentionsAPI, analyticsAPI, keywordsAPI, reportsAPI } from '../lib/api';
import { useSocket } from '../hooks/useSocket';
import toast from 'react-hot-toast';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar
} from 'recharts';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const SRC_ICONS = { WEB:'🌐', TWITTER:'🐦', FACEBOOK:'📘', INSTAGRAM:'📸', NEWS:'📰', GOOGLE_ALERTS:'🔔', RSS:'📡' };
const SRC_COLORS = { WEB:'#0ea5e9', TWITTER:'#1d9bf0', FACEBOOK:'#1877f2', INSTAGRAM:'#e1306c', NEWS:'#f59e0b' };
const SENT_COLORS = { POSITIVE:'#10b981', NEGATIVE:'#ef4444', NEUTRAL:'#64748b' };
const KW_COLORS = ['#3b82f6','#8b5cf6','#10b981','#f59e0b','#ef4444','#e1306c','#0ea5e9'];

const PERIOD_OPTIONS = [
  { value: '1h', label: '1 hora' },
  { value: '24h', label: '24 horas' },
  { value: '7d', label: '7 días' },
  { value: '30d', label: '30 días' },
];

function fmtNum(n) {
  if (!n) return '0';
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n.toString();
}

function timeAgo(date) {
  const diff = Math.floor((Date.now() - new Date(date)) / 1000);
  if (diff < 60) return `hace ${diff}s`;
  if (diff < 3600) return `hace ${Math.floor(diff / 60)}min`;
  if (diff < 86400) return `hace ${Math.floor(diff / 3600)}h`;
  return format(new Date(date), "d MMM HH:mm", { locale: es });
}

export default function Dashboard() {
  const { user, logout, loading: authLoading } = useAuth();
  const router = useRouter();

  const [campaigns, setCampaigns] = useState([]);
  const [activeCampaign, setActiveCampaign] = useState(null);
  const [mentions, setMentions] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [timeseries, setTimeseries] = useState([]);
  const [keywords, setKeywords] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('24h');
  const [sourceFilter, setSourceFilter] = useState('ALL');
  const [sentimentFilter, setSentimentFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [newKeyword, setNewKeyword] = useState('');
  const [sidebarView, setSidebarView] = useState('feed');
  const [newMentionsBanner, setNewMentionsBanner] = useState(0);
  const [alertBanner, setAlertBanner] = useState(null);
  const [showNewCampaign, setShowNewCampaign] = useState(false);
  const [newCampaignName, setNewCampaignName] = useState('');
  const [mentionPage, setMentionPage] = useState(1);
  const [totalMentions, setTotalMentions] = useState(0);
  const feedRef = useRef(null);

  // ─── Auth Guard ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!authLoading && !user) router.push('/login');
  }, [user, authLoading]);

  // ─── Load campaigns ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    campaignsAPI.list().then(res => {
      const cps = res.data.campaigns;
      setCampaigns(cps);
      if (cps.length > 0) setActiveCampaign(cps[0]);
    }).catch(() => toast.error('Error al cargar campañas'));
  }, [user]);

  // ─── Load campaign data ──────────────────────────────────────────────────────
  const loadData = useCallback(async () => {
    if (!activeCampaign) return;
    setLoading(true);
    try {
      const params = {
        campaignId: activeCampaign.id,
        ...(sourceFilter !== 'ALL' && { source: sourceFilter }),
        ...(sentimentFilter !== 'ALL' && { sentiment: sentimentFilter }),
        ...(searchQuery && { search: searchQuery }),
        page: mentionPage,
        limit: 20,
      };

      const [mentRes, analytRes, tsRes, kwRes, ucRes] = await Promise.allSettled([
        mentionsAPI.list(params),
        analyticsAPI.summary(activeCampaign.id, period),
        analyticsAPI.timeseries(activeCampaign.id, period),
        keywordsAPI.list(activeCampaign.id),
        mentionsAPI.unreadCount(activeCampaign.id),
      ]);

      if (mentRes.status === 'fulfilled') {
        setMentions(mentRes.value.data.mentions);
        setTotalMentions(mentRes.value.data.pagination.total);
      }
      if (analytRes.status === 'fulfilled') setAnalytics(analytRes.value.data);
      if (tsRes.status === 'fulfilled') setTimeseries(tsRes.value.data.series || []);
      if (kwRes.status === 'fulfilled') setKeywords(kwRes.value.data.keywords);
      if (ucRes.status === 'fulfilled') setUnreadCount(ucRes.value.data.count);
    } catch (err) {
      toast.error('Error al cargar datos');
    } finally {
      setLoading(false);
    }
  }, [activeCampaign, period, sourceFilter, sentimentFilter, searchQuery, mentionPage]);

  useEffect(() => { loadData(); }, [loadData]);

  // ─── Auto-refresh analytics ────────────────────────────────────────────────
  useEffect(() => {
    if (!activeCampaign) return;
    const interval = setInterval(() => {
      analyticsAPI.summary(activeCampaign.id, period).then(r => setAnalytics(r.data)).catch(() => {});
    }, 60000);
    return () => clearInterval(interval);
  }, [activeCampaign, period]);

  // ─── Socket real-time ────────────────────────────────────────────────────────
  useSocket(activeCampaign?.id, {
    onMentionsNew: ({ count, mentions: newMentions }) => {
      setNewMentionsBanner(prev => prev + count);
      setUnreadCount(prev => prev + count);
      toast(`📡 ${count} nuevas menciones`, { icon: '🔔', duration: 3000 });
    },
    onAlert: (data) => {
      setAlertBanner(data);
      toast.error(`⚠️ ALERTA: ${data.message}`, { duration: 8000 });
    },
  });

  // ─── Actions ────────────────────────────────────────────────────────────────
  async function addKeyword() {
    if (!newKeyword.trim() || !activeCampaign) return;
    try {
      const res = await keywordsAPI.create({
        term: newKeyword.trim(),
        campaignId: activeCampaign.id,
        color: KW_COLORS[keywords.length % KW_COLORS.length],
      });
      setKeywords(prev => [...prev, res.data.keyword]);
      setNewKeyword('');
      toast.success(`Keyword "${newKeyword}" agregada`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error al agregar keyword');
    }
  }

  async function removeKeyword(id) {
    await keywordsAPI.delete(id);
    setKeywords(prev => prev.filter(k => k.id !== id));
    toast.success('Keyword eliminada');
  }

  async function createCampaign() {
    if (!newCampaignName.trim()) return;
    try {
      const res = await campaignsAPI.create({ name: newCampaignName });
      setCampaigns(prev => [...prev, res.data.campaign]);
      setActiveCampaign(res.data.campaign);
      setNewCampaignName('');
      setShowNewCampaign(false);
      toast.success('Campaña creada');
    } catch {
      toast.error('Error al crear campaña');
    }
  }

  async function generateReport() {
    if (!activeCampaign) return;
    const toastId = toast.loading('Generando reporte...');
    try {
      const res = await reportsAPI.generate({
        campaignId: activeCampaign.id,
        period,
        type: 'SUMMARY',
      });
      toast.dismiss(toastId);
      toast.success('Reporte generado exitosamente');
      downloadReport(res.data.data);
    } catch {
      toast.dismiss(toastId);
      toast.error('Error al generar reporte');
    }
  }

  function downloadReport(data) {
    const content = `
REPORTE DE CAMPAÑA - ${data.campaign}
Período: ${data.period} | Generado: ${new Date(data.generatedAt).toLocaleString('es-AR')}

RESUMEN
=======
Total menciones: ${data.summary.total}

POR FUENTE:
${data.summary.bySource.map(s => `  ${s.source}: ${s.count} menciones (alcance: ${fmtNum(s.reach)})`).join('\n')}

MENCIONES DESTACADAS:
${data.topMentions.slice(0, 5).map((m, i) => `  ${i + 1}. [${m.source}] ${m.content.slice(0, 150)}...`).join('\n')}
    `.trim();

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_${data.campaign.replace(/\s+/g, '_')}_${data.period}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ─── Derived stats ─────────────────────────────────────────────────────────
  const sentimentData = analytics?.bySentiment?.map(s => ({
    name: s.sentiment === 'POSITIVE' ? 'Positivo' : s.sentiment === 'NEGATIVE' ? 'Negativo' : 'Neutral',
    value: s.count,
    color: SENT_COLORS[s.sentiment],
  })) || [];

  const sourceData = analytics?.bySource?.slice(0, 5) || [];
  const totalSent = sentimentData.reduce((a, b) => a + b.value, 0) || 1;
  const posPercent = Math.round(((sentimentData.find(s => s.name === 'Positivo')?.value || 0) / totalSent) * 100);
  const negPercent = Math.round(((sentimentData.find(s => s.name === 'Negativo')?.value || 0) / totalSent) * 100);

  if (authLoading) return null;

  // ─── RENDER ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>

      {/* ALERT BANNER */}
      {alertBanner && (
        <div style={{
          background: '#ef444415', borderBottom: '1px solid #ef444440',
          padding: '10px 24px', display: 'flex', alignItems: 'center', gap: '12px',
          fontSize: '13px', zIndex: 50
        }}>
          <span>🚨</span>
          <span style={{ flex: 1 }}><strong>ALERTA:</strong> {alertBanner.message}</span>
          <button onClick={() => setAlertBanner(null)} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', fontSize: '18px' }}>×</button>
        </div>
      )}

      {/* TOP BAR */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 24px', background: 'var(--bg2)',
        borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 40
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '32px', height: '32px', borderRadius: '8px',
            background: 'linear-gradient(135deg,#3b82f6,#8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px'
          }}>📡</div>
          <span style={{ fontSize: '18px', fontWeight: '700' }}>PoliticaMonitor</span>
          <div style={{
            background: '#ef444420', border: '1px solid #ef4444', color: '#ef4444',
            fontSize: '11px', fontWeight: '600', padding: '3px 8px', borderRadius: '20px',
            display: 'flex', alignItems: 'center', gap: '5px'
          }}>
            <div className="pulse-dot" style={{ width: '6px', height: '6px', background: '#ef4444', borderRadius: '50%' }}/>
            EN VIVO
          </div>
        </div>

        {/* Campaign selector */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <select
            value={activeCampaign?.id || ''}
            onChange={e => {
              const cp = campaigns.find(c => c.id === e.target.value);
              if (cp) { setActiveCampaign(cp); setMentionPage(1); }
            }}
            style={{ background: 'var(--bg3)', border: '1px solid var(--border2)', color: 'var(--text)', padding: '7px 12px', borderRadius: '8px', fontSize: '13px', width: 'auto' }}
          >
            {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button className="btn btn-ghost" style={{ fontSize: '12px', padding: '7px 12px' }} onClick={() => setShowNewCampaign(true)}>+ Nueva</button>
          <button className="btn btn-primary" style={{ fontSize: '12px', padding: '7px 14px' }} onClick={generateReport}>📊 Reporte</button>
          <button className="btn btn-ghost" style={{ fontSize: '12px', padding: '7px 12px' }} onClick={logout}>Salir</button>
        </div>
      </div>

      {/* NEW MENTION BANNER */}
      {newMentionsBanner > 0 && (
        <button onClick={() => { setNewMentionsBanner(0); setMentionPage(1); loadData(); feedRef.current?.scrollTo(0, 0); }}
          style={{ background: 'var(--accent)', border: 'none', color: '#fff', padding: '10px', fontSize: '13px', fontWeight: '600', cursor: 'pointer', width: '100%' }}>
          📡 {newMentionsBanner} nuevas menciones — Clic para actualizar
        </button>
      )}

      {/* MAIN LAYOUT */}
      <div style={{ display: 'flex', flex: 1 }}>

        {/* ── SIDEBAR ─────────────────────────────────────────────────────── */}
        <div style={{
          width: '260px', flexShrink: 0, background: 'var(--bg2)',
          borderRight: '1px solid var(--border)', padding: '16px 0',
          display: 'flex', flexDirection: 'column', gap: '4px',
          overflowY: 'auto'
        }}>
          {[
            { id: 'feed', icon: '📡', label: 'Feed en tiempo real', badge: unreadCount },
            { id: 'analytics', icon: '📈', label: 'Análisis' },
            { id: 'keywords', icon: '🔑', label: 'Palabras clave' },
            { id: 'alerts', icon: '⚠️', label: 'Alertas' },
          ].map(item => (
            <div key={item.id} onClick={() => setSidebarView(item.id)} style={{
              display: 'flex', alignItems: 'center', gap: '10px',
              padding: '10px 20px', cursor: 'pointer',
              background: sidebarView === item.id ? 'var(--bg3)' : 'transparent',
              borderLeft: sidebarView === item.id ? '3px solid var(--accent)' : '3px solid transparent',
              color: sidebarView === item.id ? 'var(--accent2)' : 'var(--text2)',
              fontSize: '14px', transition: 'all 0.15s'
            }}>
              <span>{item.icon}</span>
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge > 0 && (
                <span style={{ background: 'var(--red)', color: '#fff', fontSize: '11px', fontWeight: '700', padding: '2px 7px', borderRadius: '10px' }}>
                  {item.badge > 99 ? '99+' : item.badge}
                </span>
              )}
            </div>
          ))}

          {/* Custom sources shortcut */}
          <div onClick={() => router.push('/sources')} style={{
            display: 'flex', alignItems: 'center', gap: '10px',
            padding: '10px 20px', cursor: 'pointer',
            borderLeft: '3px solid transparent',
            color: 'var(--text2)', fontSize: '14px', transition: 'all 0.15s'
          }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--bg3)'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          >
            <span>🌐</span>
            <span>Mis páginas a monitorear</span>
            <span style={{ marginLeft: 'auto', fontSize: '10px', color: 'var(--accent2)' }}>→</span>
          </div>
            <div key={item.id} onClick={() => setSidebarView(item.id)} style={{
              display: 'flex', alignItems: 'center', gap: '10px',
              padding: '10px 20px', cursor: 'pointer',
              background: sidebarView === item.id ? 'var(--bg3)' : 'transparent',
              borderLeft: sidebarView === item.id ? '3px solid var(--accent)' : '3px solid transparent',
              color: sidebarView === item.id ? 'var(--accent2)' : 'var(--text2)',
              fontSize: '14px', transition: 'all 0.15s'
            }}>
              <span>{item.icon}</span>
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge > 0 && (
                <span style={{ background: 'var(--red)', color: '#fff', fontSize: '11px', fontWeight: '700', padding: '2px 7px', borderRadius: '10px' }}>
                  {item.badge > 99 ? '99+' : item.badge}
                </span>
              )}
            </div>
          ))}

          {/* Keywords quick list */}
          <div style={{ padding: '16px 12px 0', borderTop: '1px solid var(--border)', marginTop: '8px' }}>
            <div style={{ fontSize: '10px', fontWeight: '700', color: 'var(--text3)', letterSpacing: '1.5px', textTransform: 'uppercase', marginBottom: '10px', paddingLeft: '8px' }}>
              Términos monitoreados
            </div>
            {keywords.map((kw, i) => (
              <div key={kw.id} style={{
                display: 'flex', alignItems: 'center', gap: '8px',
                background: 'var(--bg3)', border: '1px solid var(--border)',
                borderRadius: '8px', padding: '7px 10px', marginBottom: '5px', fontSize: '13px'
              }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: kw.color || KW_COLORS[i % KW_COLORS.length], flexShrink: 0 }}/>
                <span style={{ flex: 1, fontWeight: '600', color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{kw.term}</span>
                <span style={{ fontSize: '11px', color: 'var(--text3)' }}>{kw._count?.mentions || 0}</span>
              </div>
            ))}

            {/* Add keyword */}
            <div style={{ display: 'flex', gap: '6px', marginTop: '8px' }}>
              <input
                value={newKeyword}
                onChange={e => setNewKeyword(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addKeyword()}
                placeholder="Agregar término..."
                style={{ flex: 1, padding: '7px 10px', fontSize: '13px' }}
              />
              <button onClick={addKeyword} style={{
                background: 'var(--accent)', color: '#fff', border: 'none', borderRadius: '6px',
                padding: '7px 12px', cursor: 'pointer', fontSize: '18px', fontWeight: 'bold'
              }}>+</button>
            </div>
          </div>
        </div>

        {/* ── MAIN CONTENT ─────────────────────────────────────────────────── */}
        <div ref={feedRef} style={{ flex: 1, overflowY: 'auto', padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>

          {/* STATS ROW */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '16px' }}>
            {[
              { label: 'Menciones totales', value: fmtNum(analytics?.mentions?.total || 0), delta: `${analytics?.mentions?.delta >= 0 ? '↑' : '↓'} ${Math.abs(analytics?.mentions?.delta || 0)}% vs período anterior`, color: '#60a5fa', deltaUp: (analytics?.mentions?.delta || 0) >= 0 },
              { label: 'Sentimiento positivo', value: posPercent + '%', delta: 'últimas ' + period, color: '#10b981', deltaUp: true },
              { label: 'Sentimiento negativo', value: negPercent + '%', delta: negPercent > 30 ? '⚠️ requiere atención' : 'bajo control', color: '#ef4444', deltaUp: false },
              { label: 'Alcance estimado', value: fmtNum(analytics?.reach || 0), delta: 'personas impactadas', color: '#8b5cf6', deltaUp: true },
            ].map((stat, i) => (
              <div key={i} className="card" style={{ padding: '16px 20px', position: 'relative', overflow: 'hidden' }}>
                <div style={{ fontSize: '12px', color: 'var(--text3)', fontWeight: '500', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '6px' }}>{stat.label}</div>
                <div style={{ fontSize: '28px', fontWeight: '700', color: stat.color, lineHeight: 1, marginBottom: '4px' }}>{stat.value}</div>
                <div style={{ fontSize: '12px', color: stat.deltaUp ? '#10b981' : '#ef4444' }}>{stat.delta}</div>
              </div>
            ))}
          </div>

          {/* CHARTS ROW */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '16px' }}>

            {/* Time series chart */}
            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '700' }}>Volumen de menciones</div>
                  <div style={{ fontSize: '12px', color: 'var(--text3)' }}>Actualización automática</div>
                </div>
                <div style={{ display: 'flex', gap: '4px' }}>
                  {PERIOD_OPTIONS.map(p => (
                    <button key={p.value} onClick={() => { setPeriod(p.value); setMentionPage(1); }}
                      style={{
                        padding: '5px 10px', borderRadius: '6px', border: 'none',
                        fontSize: '12px', fontWeight: '600', cursor: 'pointer',
                        background: period === p.value ? 'var(--accent)' : 'var(--bg3)',
                        color: period === p.value ? '#fff' : 'var(--text3)'
                      }}>{p.label}</button>
                  ))}
                </div>
              </div>
              <div style={{ height: '200px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timeseries} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e3058" />
                    <XAxis dataKey="time" tick={{ fill: '#64748b', fontSize: 11 }}
                      tickFormatter={v => v ? format(new Date(v), 'HH:mm') : ''} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: '#1a2235', border: '1px solid #2d4a7a', borderRadius: '8px', color: '#f1f5f9' }}
                      labelFormatter={v => v ? format(new Date(v), 'dd/MM HH:mm') : ''} />
                    <Line type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={2} dot={false} name="Total" />
                    <Line type="monotone" dataKey="negative" stroke="#ef4444" strokeWidth={1.5} dot={false} name="Negativo" />
                    <Line type="monotone" dataKey="positive" stroke="#10b981" strokeWidth={1.5} dot={false} name="Positivo" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Sentiment pie */}
            <div className="card">
              <div style={{ fontSize: '14px', fontWeight: '700', marginBottom: '4px' }}>Análisis de sentimiento</div>
              <div style={{ fontSize: '12px', color: 'var(--text3)', marginBottom: '16px' }}>En tiempo real</div>
              <div style={{ height: '130px', display: 'flex', justifyContent: 'center' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={sentimentData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" paddingAngle={2}>
                      {sentimentData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                    </Pie>
                    <Tooltip contentStyle={{ background: '#1a2235', border: '1px solid #2d4a7a', borderRadius: '8px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '8px' }}>
                {sentimentData.map((s, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
                    <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: s.color }}/>
                    <span style={{ flex: 1, color: 'var(--text2)' }}>{s.name}</span>
                    <span style={{ fontWeight: '700' }}>{Math.round((s.value / totalSent) * 100)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* SOURCE BAR CHART */}
          {sourceData.length > 0 && (
            <div className="card">
              <div style={{ fontSize: '14px', fontWeight: '700', marginBottom: '16px' }}>Menciones por fuente</div>
              <div style={{ height: '140px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={sourceData} margin={{ top: 0, right: 10, left: -10, bottom: 0 }}>
                    <XAxis dataKey="source" tick={{ fill: '#64748b', fontSize: 11 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: '#1a2235', border: '1px solid #2d4a7a', borderRadius: '8px' }} />
                    <Bar dataKey="count" name="Menciones" radius={[4, 4, 0, 0]}>
                      {sourceData.map((entry, i) => (
                        <Cell key={i} fill={SRC_COLORS[entry.source] || '#3b82f6'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* MENTIONS FEED */}
          <div className="card">
            {/* Filters */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <div style={{ fontSize: '14px', fontWeight: '700' }}>Feed de menciones</div>
                <div style={{ fontSize: '12px', color: 'var(--text3)' }}>{totalMentions.toLocaleString()} menciones encontradas</div>
              </div>
              <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
                <input
                  value={searchQuery}
                  onChange={e => { setSearchQuery(e.target.value); setMentionPage(1); }}
                  placeholder="🔍 Buscar..."
                  style={{ width: '160px', padding: '6px 10px', fontSize: '12px' }}
                />
                {['ALL','WEB','TWITTER','FACEBOOK','INSTAGRAM','NEWS'].map(src => (
                  <button key={src} onClick={() => { setSourceFilter(src); setMentionPage(1); }}
                    style={{
                      padding: '5px 10px', borderRadius: '20px', border: '1px solid var(--border)',
                      fontSize: '12px', fontWeight: '600', cursor: 'pointer',
                      background: sourceFilter === src ? (SRC_COLORS[src] || 'var(--accent)') : 'var(--bg3)',
                      color: sourceFilter === src ? '#fff' : 'var(--text2)',
                    }}>
                    {SRC_ICONS[src] || '🌐'} {src === 'ALL' ? 'Todos' : src}
                  </button>
                ))}
                {['ALL','POSITIVE','NEGATIVE','NEUTRAL'].map(sent => (
                  <button key={sent} onClick={() => { setSentimentFilter(sent); setMentionPage(1); }}
                    style={{
                      padding: '5px 10px', borderRadius: '20px', border: '1px solid var(--border)',
                      fontSize: '12px', fontWeight: '600', cursor: 'pointer',
                      background: sentimentFilter === sent ? (SENT_COLORS[sent] || 'var(--accent)') : 'transparent',
                      color: sentimentFilter === sent ? '#fff' : 'var(--text3)',
                    }}>
                    {sent === 'ALL' ? 'Todos' : sent === 'POSITIVE' ? '😊 Pos' : sent === 'NEGATIVE' ? '⚠️ Neg' : '😐 Neu'}
                  </button>
                ))}
              </div>
            </div>

            {/* Mention cards */}
            {loading ? (
              <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text3)' }}>⏳ Cargando menciones...</div>
            ) : mentions.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text3)' }}>
                <div style={{ fontSize: '40px', marginBottom: '12px' }}>📡</div>
                <p>No hay menciones todavía. Agregá keywords y esperá el próximo ciclo de scraping.</p>
              </div>
            ) : (
              <>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {mentions.map(m => (
                    <MentionCard key={m.id} mention={m} onDelete={() => {
                      mentionsAPI.delete(m.id);
                      setMentions(prev => prev.filter(x => x.id !== m.id));
                    }} />
                  ))}
                </div>

                {/* Pagination */}
                <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '20px' }}>
                  <button className="btn btn-ghost" disabled={mentionPage <= 1} onClick={() => setMentionPage(p => p - 1)}>← Anterior</button>
                  <span style={{ padding: '8px 16px', color: 'var(--text3)', fontSize: '13px' }}>
                    Pág {mentionPage} de {Math.ceil(totalMentions / 20)}
                  </span>
                  <button className="btn btn-ghost" disabled={mentionPage >= Math.ceil(totalMentions / 20)} onClick={() => setMentionPage(p => p + 1)}>Siguiente →</button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* NEW CAMPAIGN MODAL */}
      {showNewCampaign && (
        <div style={{
          position: 'fixed', inset: 0, background: '#000000aa', zIndex: 100,
          display: 'flex', alignItems: 'center', justifyContent: 'center'
        }} onClick={e => e.target === e.currentTarget && setShowNewCampaign(false)}>
          <div className="card" style={{ width: '440px', padding: '28px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '700', marginBottom: '6px' }}>Nueva campaña</h2>
            <p style={{ color: 'var(--text3)', fontSize: '13px', marginBottom: '20px' }}>Crea un nuevo espacio de monitoreo</p>
            <label>Nombre de la campaña</label>
            <input value={newCampaignName} onChange={e => setNewCampaignName(e.target.value)}
              placeholder="Ej: Campaña Presidencial 2027"
              onKeyDown={e => e.key === 'Enter' && createCampaign()}
              style={{ marginBottom: '16px' }} />
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
              <button className="btn btn-ghost" onClick={() => setShowNewCampaign(false)}>Cancelar</button>
              <button className="btn btn-primary" onClick={createCampaign}>Crear campaña</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Mention Card Component ────────────────────────────────────────────────────
function MentionCard({ mention: m, onDelete }) {
  const sentClass = { POSITIVE: { bg: '#10b98120', color: '#34d399', border: '#10b98140', label: '😊 Positivo' },
    NEGATIVE: { bg: '#ef444420', color: '#f87171', border: '#ef444440', label: '⚠️ Negativo' },
    NEUTRAL: { bg: '#64748b20', color: '#94a3b8', border: '#64748b40', label: '😐 Neutral' } };
  const sent = sentClass[m.sentiment] || sentClass.NEUTRAL;
  const SRC_ICONS = { WEB:'🌐', TWITTER:'🐦', FACEBOOK:'📘', INSTAGRAM:'📸', NEWS:'📰' };
  const SRC_COLORS = { WEB:'#0ea5e9', TWITTER:'#1d9bf0', FACEBOOK:'#1877f2', INSTAGRAM:'#e1306c', NEWS:'#f59e0b' };

  function fmtNum(n) {
    if (!n) return '0';
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(0) + 'k';
    return n.toString();
  }

  function timeAgo(date) {
    const diff = Math.floor((Date.now() - new Date(date)) / 1000);
    if (diff < 60) return `hace ${diff}s`;
    if (diff < 3600) return `hace ${Math.floor(diff / 60)}min`;
    return `hace ${Math.floor(diff / 3600)}h`;
  }

  return (
    <div className="animate-slide-in" style={{
      background: 'var(--bg3)', border: '1px solid var(--border)',
      borderRadius: '10px', padding: '14px 16px',
      transition: 'border-color 0.2s'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px', flexWrap: 'wrap' }}>
        <span style={{
          display: 'flex', alignItems: 'center', gap: '5px',
          background: `${SRC_COLORS[m.source] || '#3b82f6'}20`,
          color: SRC_COLORS[m.source] || '#60a5fa',
          border: `1px solid ${SRC_COLORS[m.source] || '#3b82f6'}40`,
          padding: '3px 8px', borderRadius: '12px', fontSize: '11px', fontWeight: '700'
        }}>
          {SRC_ICONS[m.source] || '🌐'} {m.source}
        </span>
        {m.keyword && (
          <span style={{
            background: 'var(--bg4)', border: '1px solid var(--border2)',
            color: 'var(--accent2)', fontSize: '11px', fontWeight: '600',
            padding: '3px 8px', borderRadius: '12px'
          }}>#{m.keyword.term}</span>
        )}
        <span style={{ marginLeft: 'auto', fontSize: '11px', color: 'var(--text3)' }}>{timeAgo(m.publishedAt)}</span>
        <button onClick={onDelete} style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', fontSize: '14px', padding: '2px 4px' }} title="Eliminar">✕</button>
      </div>

      <div style={{ fontSize: '13px', color: 'var(--text)', lineHeight: '1.6', marginBottom: '8px' }}>
        {m.content.slice(0, 280)}{m.content.length > 280 ? '...' : ''}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px', color: 'var(--text3)', flexWrap: 'wrap' }}>
        <span style={{ background: sent.bg, color: sent.color, border: `1px solid ${sent.border}`, padding: '2px 8px', borderRadius: '10px', fontSize: '11px', fontWeight: '600' }}>
          {sent.label}
        </span>
        {m.reach > 0 && <span>👁️ {fmtNum(m.reach)} alcance</span>}
        {m.author && <span>— {m.author}</span>}
        {m.sourceName && <span>· {m.sourceName}</span>}
        {m.sourceUrl && (
          <a href={m.sourceUrl} target="_blank" rel="noopener noreferrer"
            style={{ color: 'var(--accent2)', fontSize: '12px' }}>
            🔗 Ver fuente
          </a>
        )}
      </div>
    </div>
  );
}

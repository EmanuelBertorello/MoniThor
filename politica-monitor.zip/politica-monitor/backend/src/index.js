// src/index.js
require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { Server } = require('socket.io');

const logger = require('./lib/logger');
const { connectDB } = require('./lib/db');
const { initQueues } = require('./workers/queueManager');
const { startScheduler } = require('./workers/scheduler');

// Routes
const authRoutes = require('./routes/auth');
const campaignRoutes = require('./routes/campaigns');
const mentionRoutes = require('./routes/mentions');
const keywordRoutes = require('./routes/keywords');
const analyticsRoutes = require('./routes/analytics');
const alertRoutes = require('./routes/alerts');
const reportRoutes = require('./routes/reports');
const sourceRoutes = require('./routes/sources');

const app = express();
const server = http.createServer(app);

// ─── Socket.IO ────────────────────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

// Attach io to app for use in routes/services
app.set('io', io);

io.on('connection', (socket) => {
  logger.info(`Socket connected: ${socket.id}`);

  socket.on('join:campaign', (campaignId) => {
    socket.join(`campaign:${campaignId}`);
    logger.info(`Socket ${socket.id} joined campaign:${campaignId}`);
  });

  socket.on('leave:campaign', (campaignId) => {
    socket.leave(`campaign:${campaignId}`);
  });

  socket.on('disconnect', () => {
    logger.info(`Socket disconnected: ${socket.id}`);
  });
});

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(morgan('combined', { stream: { write: (msg) => logger.http(msg.trim()) } }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '1.0.0' });
});

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/campaigns', campaignRoutes);
app.use('/api/mentions', mentionRoutes);
app.use('/api/keywords', keywordRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/sources', sourceRoutes);

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Error interno del servidor',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;

async function start() {
  try {
    await connectDB();
    logger.info('✅ Base de datos conectada');

    await initQueues();
    logger.info('✅ Colas de trabajo iniciadas');

    startScheduler(io);
    logger.info('✅ Scheduler de scraping iniciado');

    server.listen(PORT, () => {
      logger.info(`🚀 Servidor corriendo en http://localhost:${PORT}`);
      logger.info(`📡 Socket.IO listo para conexiones en tiempo real`);
    });
  } catch (err) {
    logger.error('Error al iniciar el servidor:', err);
    process.exit(1);
  }
}

start();

module.exports = { app, io };

// src/routes/reports.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// POST /api/reports/generate
router.post('/generate', async (req, res) => {
  try {
    const { campaignId, period, type = 'SUMMARY', email } = req.body;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const periodMap = { '24h': 24, '7d': 168, '30d': 720 };
    const hours = periodMap[period] || 24;
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);

    const [total, bySentiment, bySource, topMentions, keywords] = await Promise.all([
      prisma.mention.count({ where: { campaignId, publishedAt: { gte: since } } }),
      prisma.mention.groupBy({
        by: ['sentiment'],
        where: { campaignId, publishedAt: { gte: since } },
        _count: true,
      }),
      prisma.mention.groupBy({
        by: ['source'],
        where: { campaignId, publishedAt: { gte: since } },
        _count: true,
        _sum: { reach: true },
      }),
      prisma.mention.findMany({
        where: { campaignId, publishedAt: { gte: since } },
        orderBy: { reach: 'desc' },
        take: 10,
        include: { keyword: { select: { term: true } } },
      }),
      prisma.keyword.findMany({
        where: { campaignId, isActive: true },
        include: { _count: { select: { mentions: true } } },
      }),
    ]);

    const reportData = {
      campaign: campaign.name,
      period,
      generatedAt: new Date().toISOString(),
      summary: {
        total,
        bySentiment: bySentiment.map(s => ({ [s.sentiment]: s._count })),
        bySource: bySource.map(s => ({ source: s.source, count: s._count, reach: s._sum.reach })),
      },
      topMentions,
      keywords,
    };

    const report = await prisma.report.create({
      data: {
        campaignId,
        type,
        period,
        data: reportData,
      },
    });

    res.json({ report, data: reportData });
  } catch (err) {
    res.status(500).json({ error: 'Error al generar reporte' });
  }
});

// GET /api/reports?campaignId=
router.get('/', async (req, res) => {
  try {
    const { campaignId } = req.query;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const reports = await prisma.report.findMany({
      where: { campaignId },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    res.json({ reports });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener reportes' });
  }
});

module.exports = router;

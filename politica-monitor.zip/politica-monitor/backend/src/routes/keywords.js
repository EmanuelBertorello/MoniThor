// src/routes/keywords.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/keywords?campaignId=xxx
router.get('/', async (req, res) => {
  try {
    const { campaignId } = req.query;
    if (!campaignId) return res.status(400).json({ error: 'campaignId requerido' });

    // Verify ownership
    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const keywords = await prisma.keyword.findMany({
      where: { campaignId, isActive: true },
      include: { _count: { select: { mentions: true } } },
      orderBy: { createdAt: 'asc' },
    });

    res.json({ keywords });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener keywords' });
  }
});

// POST /api/keywords
router.post('/', async (req, res) => {
  try {
    const { term, campaignId, color } = req.body;
    if (!term || !campaignId) {
      return res.status(400).json({ error: 'term y campaignId son requeridos' });
    }

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const keyword = await prisma.keyword.upsert({
      where: { term_campaignId: { term, campaignId } },
      update: { isActive: true, color: color || '#3b82f6' },
      create: { term, campaignId, color: color || '#3b82f6' },
    });

    res.status(201).json({ keyword });
  } catch (err) {
    res.status(500).json({ error: 'Error al crear keyword' });
  }
});

// DELETE /api/keywords/:id
router.delete('/:id', async (req, res) => {
  try {
    const keyword = await prisma.keyword.findUnique({
      where: { id: req.params.id },
      include: { campaign: true },
    });
    if (!keyword || keyword.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Keyword no encontrada' });
    }

    await prisma.keyword.update({
      where: { id: req.params.id },
      data: { isActive: false },
    });

    res.json({ message: 'Keyword eliminada' });
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar keyword' });
  }
});

module.exports = router;

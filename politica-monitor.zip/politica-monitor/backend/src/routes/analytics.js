// src/routes/analytics.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/analytics/summary?campaignId=&period=24h|7d|30d
router.get('/summary', async (req, res) => {
  try {
    const { campaignId, period = '24h' } = req.query;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const periodMap = { '1h': 1, '24h': 24, '7d': 168, '30d': 720 };
    const hours = periodMap[period] || 24;
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);
    const prevSince = new Date(Date.now() - hours * 2 * 60 * 60 * 1000);

    const [current, previous, bySource, bySentiment, byKeyword, topMentions] = await Promise.all([
      prisma.mention.count({ where: { campaignId, publishedAt: { gte: since } } }),
      prisma.mention.count({ where: { campaignId, publishedAt: { gte: prevSince, lt: since } } }),
      prisma.mention.groupBy({
        by: ['source'],
        where: { campaignId, publishedAt: { gte: since } },
        _count: true,
        _sum: { reach: true },
      }),
      prisma.mention.groupBy({
        by: ['sentiment'],
        where: { campaignId, publishedAt: { gte: since } },
        _count: true,
      }),
      prisma.mention.groupBy({
        by: ['keywordId'],
        where: { campaignId, publishedAt: { gte: since }, keywordId: { not: null } },
        _count: true,
        orderBy: { _count: { keywordId: 'desc' } },
        take: 5,
      }),
      prisma.mention.findMany({
        where: { campaignId, publishedAt: { gte: since } },
        orderBy: { reach: 'desc' },
        take: 5,
        include: { keyword: { select: { term: true } } },
      }),
    ]);

    const totalReach = bySource.reduce((a, b) => a + (b._sum.reach || 0), 0);
    const deltaPercent = previous > 0 ? Math.round(((current - previous) / previous) * 100) : 0;

    res.json({
      period,
      mentions: { total: current, delta: deltaPercent },
      reach: totalReach,
      bySource: bySource.map(s => ({ source: s.source, count: s._count, reach: s._sum.reach || 0 })),
      bySentiment: bySentiment.map(s => ({ sentiment: s.sentiment, count: s._count })),
      byKeyword,
      topMentions,
    });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener analytics' });
  }
});

// GET /api/analytics/timeseries?campaignId=&period=&interval=hour|day
router.get('/timeseries', async (req, res) => {
  try {
    const { campaignId, period = '24h', interval = 'hour' } = req.query;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const periodMap = { '1h': 1, '24h': 24, '7d': 168, '30d': 720 };
    const hours = periodMap[period] || 24;
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);

    // Raw query for time-series grouping
    const truncate = interval === 'day' ? 'day' : 'hour';

    const series = await prisma.$queryRaw`
      SELECT
        date_trunc(${truncate}, "publishedAt") as time,
        COUNT(*)::int as total,
        COUNT(CASE WHEN sentiment = 'POSITIVE' THEN 1 END)::int as positive,
        COUNT(CASE WHEN sentiment = 'NEGATIVE' THEN 1 END)::int as negative,
        COUNT(CASE WHEN sentiment = 'NEUTRAL' THEN 1 END)::int as neutral
      FROM mentions
      WHERE "campaignId" = ${campaignId}
        AND "publishedAt" >= ${since}
      GROUP BY date_trunc(${truncate}, "publishedAt")
      ORDER BY time ASC
    `;

    res.json({ series });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener serie de tiempo' });
  }
});

module.exports = router;

// src/routes/mentions.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/mentions?campaignId=&source=&sentiment=&keyword=&page=&limit=
router.get('/', async (req, res) => {
  try {
    const {
      campaignId,
      source,
      sentiment,
      keywordId,
      search,
      page = 1,
      limit = 30,
      from,
      to,
    } = req.query;

    if (!campaignId) return res.status(400).json({ error: 'campaignId requerido' });

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const where = {
      campaignId,
      ...(source && { source }),
      ...(sentiment && { sentiment }),
      ...(keywordId && { keywordId }),
      ...(search && { content: { contains: search, mode: 'insensitive' } }),
      ...(from || to ? {
        publishedAt: {
          ...(from && { gte: new Date(from) }),
          ...(to && { lte: new Date(to) }),
        },
      } : {}),
    };

    const [mentions, total] = await Promise.all([
      prisma.mention.findMany({
        where,
        include: { keyword: { select: { term: true, color: true } } },
        orderBy: { publishedAt: 'desc' },
        take: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
      }),
      prisma.mention.count({ where }),
    ]);

    // Mark as read
    await prisma.mention.updateMany({
      where: { ...where, isRead: false },
      data: { isRead: true },
    });

    res.json({
      mentions,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener menciones' });
  }
});

// GET /api/mentions/unread-count
router.get('/unread-count', async (req, res) => {
  try {
    const { campaignId } = req.query;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const count = await prisma.mention.count({
      where: { campaignId, isRead: false },
    });

    res.json({ count });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener conteo' });
  }
});

// DELETE /api/mentions/:id
router.delete('/:id', async (req, res) => {
  try {
    const mention = await prisma.mention.findUnique({
      where: { id: req.params.id },
      include: { campaign: true },
    });

    if (!mention || mention.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Mención no encontrada' });
    }

    await prisma.mention.delete({ where: { id: req.params.id } });
    res.json({ message: 'Mención eliminada' });
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar mención' });
  }
});

module.exports = router;

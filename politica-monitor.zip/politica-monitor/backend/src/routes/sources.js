// src/routes/sources.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');
const { scrapeCustomUrl } = require('../services/customScraper');

const router = express.Router();
router.use(authenticate);

// GET /api/sources?campaignId=
router.get('/', async (req, res) => {
  try {
    const { campaignId } = req.query;
    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const sources = await prisma.customSource.findMany({
      where: { campaignId },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ sources });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener fuentes' });
  }
});

// POST /api/sources  — add a custom URL
router.post('/', async (req, res) => {
  try {
    const { campaignId, url, name, type, notes } = req.body;
    if (!campaignId || !url) {
      return res.status(400).json({ error: 'campaignId y url son requeridos' });
    }

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    // Validate URL
    try { new URL(url); } catch {
      return res.status(400).json({ error: 'URL inválida' });
    }

    // Detect source type from URL if not provided
    const detectedType = type || detectSourceType(url);

    const source = await prisma.customSource.create({
      data: {
        campaignId,
        url: url.trim(),
        name: name || extractDomain(url),
        type: detectedType,
        notes: notes || '',
        isActive: true,
        lastScraped: null,
      },
    });

    res.status(201).json({ source });
  } catch (err) {
    res.status(500).json({ error: 'Error al agregar fuente' });
  }
});

// PUT /api/sources/:id — toggle active / update
router.put('/:id', async (req, res) => {
  try {
    const src = await prisma.customSource.findFirst({
      where: { id: req.params.id },
      include: { campaign: true },
    });
    if (!src || src.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Fuente no encontrada' });
    }

    const updated = await prisma.customSource.update({
      where: { id: req.params.id },
      data: {
        ...(req.body.isActive !== undefined && { isActive: req.body.isActive }),
        ...(req.body.name && { name: req.body.name }),
        ...(req.body.notes !== undefined && { notes: req.body.notes }),
      },
    });

    res.json({ source: updated });
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar fuente' });
  }
});

// DELETE /api/sources/:id
router.delete('/:id', async (req, res) => {
  try {
    const src = await prisma.customSource.findFirst({
      where: { id: req.params.id },
      include: { campaign: true },
    });
    if (!src || src.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Fuente no encontrada' });
    }

    await prisma.customSource.delete({ where: { id: req.params.id } });
    res.json({ message: 'Fuente eliminada' });
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar fuente' });
  }
});

// POST /api/sources/:id/test — scrape it right now and return preview
router.post('/:id/test', async (req, res) => {
  try {
    const src = await prisma.customSource.findFirst({
      where: { id: req.params.id },
      include: { campaign: { include: { keywords: { where: { isActive: true } } } } },
    });
    if (!src || src.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Fuente no encontrada' });
    }

    const keywords = src.campaign.keywords.map(k => k.term);
    const results = await scrapeCustomUrl(src.url, keywords, src.type);

    res.json({
      url: src.url,
      type: src.type,
      found: results.length,
      preview: results.slice(0, 3),
    });
  } catch (err) {
    res.status(500).json({ error: `Error al testear fuente: ${err.message}` });
  }
});

// ── Helpers ────────────────────────────────────────────────────────────────────
function detectSourceType(url) {
  const lower = url.toLowerCase();
  if (lower.includes('facebook.com')) return 'FACEBOOK_PAGE';
  if (lower.includes('instagram.com')) return 'INSTAGRAM_PROFILE';
  if (lower.includes('twitter.com') || lower.includes('x.com')) return 'TWITTER_PROFILE';
  if (lower.includes('youtube.com')) return 'YOUTUBE_CHANNEL';
  if (lower.includes('reddit.com')) return 'REDDIT';
  // RSS/Atom feeds
  if (lower.endsWith('.xml') || lower.includes('/feed') || lower.includes('/rss') || lower.includes('atom')) return 'RSS_FEED';
  return 'WEBSITE';
}

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace('www.', '');
  } catch {
    return url;
  }
}

module.exports = router;

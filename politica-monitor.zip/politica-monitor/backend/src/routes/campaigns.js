// src/routes/campaigns.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/campaigns
router.get('/', async (req, res) => {
  try {
    const campaigns = await prisma.campaign.findMany({
      where: { userId: req.user.id },
      include: {
        keywords: { where: { isActive: true } },
        _count: { select: { mentions: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ campaigns });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener campañas' });
  }
});

// POST /api/campaigns
router.post('/', async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ error: 'El nombre es requerido' });

    const campaign = await prisma.campaign.create({
      data: { name, description, userId: req.user.id },
    });

    // Create default sources
    const defaultSources = [
      { type: 'WEB', name: 'Sitios Web' },
      { type: 'NEWS', name: 'Google News' },
      { type: 'FACEBOOK', name: 'Facebook Público' },
      { type: 'INSTAGRAM', name: 'Instagram' },
      { type: 'TWITTER', name: 'Twitter/X' },
    ];

    await prisma.source.createMany({
      data: defaultSources.map(s => ({ ...s, campaignId: campaign.id })),
    });

    res.status(201).json({ campaign });
  } catch (err) {
    res.status(500).json({ error: 'Error al crear campaña' });
  }
});

// GET /api/campaigns/:id
router.get('/:id', async (req, res) => {
  try {
    const campaign = await prisma.campaign.findFirst({
      where: { id: req.params.id, userId: req.user.id },
      include: {
        keywords: { where: { isActive: true } },
        sources: true,
        alertRules: true,
        _count: { select: { mentions: true } },
      },
    });

    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });
    res.json({ campaign });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener campaña' });
  }
});

// PUT /api/campaigns/:id
router.put('/:id', async (req, res) => {
  try {
    const { name, description, isActive } = req.body;
    const campaign = await prisma.campaign.findFirst({
      where: { id: req.params.id, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const updated = await prisma.campaign.update({
      where: { id: req.params.id },
      data: { name, description, isActive },
    });
    res.json({ campaign: updated });
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar campaña' });
  }
});

// DELETE /api/campaigns/:id
router.delete('/:id', async (req, res) => {
  try {
    const campaign = await prisma.campaign.findFirst({
      where: { id: req.params.id, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    await prisma.campaign.delete({ where: { id: req.params.id } });
    res.json({ message: 'Campaña eliminada' });
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar campaña' });
  }
});

module.exports = router;

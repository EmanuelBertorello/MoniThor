// src/services/customScraper.js
const axios = require('axios');
const cheerio = require('cheerio');
const Parser = require('rss-parser');
const logger = require('../lib/logger');
const { analyzeSentiment } = require('./sentimentService');
const { prisma } = require('../lib/db');

const rssParser = new Parser({ timeout: 12000 });

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'es-AR,es;q=0.9,en;q=0.5',
};

// ─── Main dispatcher ────────────────────────────────────────────────────────
async function scrapeCustomUrl(url, keywords, type) {
  logger.info(`Custom scrape: [${type}] ${url}`);

  switch (type) {
    case 'RSS_FEED':
      return scrapeRss(url, keywords);
    case 'FACEBOOK_PAGE':
      return scrapeFacebookPage(url, keywords);
    case 'INSTAGRAM_PROFILE':
      return scrapeInstagramProfile(url, keywords);
    case 'TWITTER_PROFILE':
      return scrapeTwitterProfile(url, keywords);
    case 'YOUTUBE_CHANNEL':
      return scrapeYoutubeChannel(url, keywords);
    case 'REDDIT':
      return scrapeReddit(url, keywords);
    case 'WEBSITE':
    default:
      return scrapeWebsite(url, keywords);
  }
}

// ─── Generic website scraper ──────────────────────────────────────────────────
async function scrapeWebsite(url, keywords) {
  try {
    const res = await axios.get(url, { headers: HEADERS, timeout: 15000, maxRedirects: 5 });
    const $ = cheerio.load(res.data);

    // Remove navigation, scripts, styles, ads
    $('nav, script, style, footer, header, aside, .ads, .advertisement, #comments').remove();

    // Extract all meaningful text blocks
    const blocks = [];
    $('p, h1, h2, h3, article, .post, .entry, .content, .article-body, [class*="content"], [class*="article"]').each((i, el) => {
      const text = $(el).text().trim().replace(/\s+/g, ' ');
      if (text.length > 80) blocks.push(text);
    });

    const pageTitle = $('title').text().trim() || $('h1').first().text().trim();
    const results = [];

    for (const kw of keywords) {
      const lowerKw = kw.toLowerCase();
      const matched = blocks.filter(b => b.toLowerCase().includes(lowerKw));

      for (const block of matched.slice(0, 3)) {
        const { sentiment, score } = await analyzeSentiment(block);
        results.push({
          sourceUrl: url,
          sourceName: extractDomain(url),
          content: `[${pageTitle}] ${block.slice(0, 600)}`,
          snippet: block.slice(0, 300),
          keyword: kw,
          sentiment,
          sentimentScore: score,
          reach: 0,
          source: 'WEB',
        });
      }
    }

    return results;
  } catch (err) {
    logger.warn(`Website scrape failed ${url}: ${err.message}`);
    return [];
  }
}

// ─── RSS / Atom feed scraper ──────────────────────────────────────────────────
async function scrapeRss(url, keywords) {
  try {
    const feed = await rssParser.parseURL(url);
    const results = [];

    for (const item of feed.items.slice(0, 30)) {
      const text = (item.title || '') + ' ' + (item.contentSnippet || item.content || '');

      for (const kw of keywords) {
        if (!text.toLowerCase().includes(kw.toLowerCase())) continue;

        const { sentiment, score } = await analyzeSentiment(text);
        results.push({
          sourceUrl: item.link || url,
          sourceName: feed.title || extractDomain(url),
          author: item.creator || item.author,
          content: item.title + '. ' + (item.contentSnippet || ''),
          snippet: (item.contentSnippet || '').slice(0, 300),
          keyword: kw,
          sentiment,
          sentimentScore: score,
          reach: 0,
          source: 'WEB',
          publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
        });
        break; // one entry per keyword match
      }
    }

    return results;
  } catch (err) {
    logger.warn(`RSS scrape failed ${url}: ${err.message}`);
    return [];
  }
}

// ─── Facebook public page ─────────────────────────────────────────────────────
// Uses Apify if key present, otherwise scrapes public mobile version
async function scrapeFacebookPage(url, keywords) {
  // Apify method (if key available)
  if (process.env.APIFY_API_KEY) {
    try {
      const pageId = url.split('facebook.com/')[1]?.replace(/\/$/, '') || '';
      const res = await axios.post(
        `https://api.apify.com/v2/acts/apify~facebook-posts-scraper/run-sync-get-dataset-items?token=${process.env.APIFY_API_KEY}`,
        { startUrls: [{ url }], maxPosts: 20 },
        { timeout: 45000 }
      );
      return filterAndAnalyze(res.data || [], keywords, 'FACEBOOK', url);
    } catch (err) {
      logger.warn(`Apify FB failed, using fallback: ${err.message}`);
    }
  }

  // Fallback: scrape public mobile version
  try {
    const mobileUrl = url.replace('facebook.com', 'm.facebook.com');
    const res = await axios.get(mobileUrl, { headers: HEADERS, timeout: 15000 });
    const $ = cheerio.load(res.data);

    const posts = [];
    $('[data-ft], ._5rgt, .story_body_container, div[data-sigil="m-feed-voice-subtitle"]').each((i, el) => {
      const text = $(el).text().trim().replace(/\s+/g, ' ');
      if (text.length > 30) posts.push(text);
    });

    return filterAndAnalyze(
      posts.slice(0, 15).map(text => ({ text, url })),
      keywords, 'FACEBOOK', url
    );
  } catch (err) {
    logger.warn(`FB page scrape failed ${url}: ${err.message}`);
    return [];
  }
}

// ─── Instagram public profile ─────────────────────────────────────────────────
async function scrapeInstagramProfile(url, keywords) {
  if (process.env.APIFY_API_KEY) {
    try {
      const username = url.split('instagram.com/')[1]?.replace(/\/$/, '') || '';
      const res = await axios.post(
        `https://api.apify.com/v2/acts/apify~instagram-profile-scraper/run-sync-get-dataset-items?token=${process.env.APIFY_API_KEY}`,
        { usernames: [username], resultsLimit: 20 },
        { timeout: 45000 }
      );
      return filterAndAnalyze(res.data || [], keywords, 'INSTAGRAM', url);
    } catch (err) {
      logger.warn(`Apify IG failed: ${err.message}`);
    }
  }

  // Fallback: Instagram Graph API (if token available)
  if (process.env.INSTAGRAM_ACCESS_TOKEN) {
    try {
      const username = url.split('instagram.com/')[1]?.replace(/\/$/, '');
      const res = await axios.get(`https://graph.instagram.com/v18.0/me/media`, {
        params: { fields: 'caption,media_type,timestamp,permalink', access_token: process.env.INSTAGRAM_ACCESS_TOKEN },
      });
      const items = res.data.data || [];
      return filterAndAnalyze(
        items.map(i => ({ text: i.caption, url: i.permalink, timestamp: i.timestamp })),
        keywords, 'INSTAGRAM', url
      );
    } catch (err) {
      logger.warn(`Instagram Graph API failed: ${err.message}`);
    }
  }

  logger.warn(`Instagram: configure APIFY_API_KEY or INSTAGRAM_ACCESS_TOKEN for ${url}`);
  return [];
}

// ─── Twitter/X profile ────────────────────────────────────────────────────────
async function scrapeTwitterProfile(url, keywords) {
  if (!process.env.TWITTER_BEARER_TOKEN) {
    logger.warn('Twitter: TWITTER_BEARER_TOKEN not set');
    return [];
  }

  try {
    const username = url.split('/').pop()?.replace('@', '');
    const userRes = await axios.get(`https://api.twitter.com/2/users/by/username/${username}`, {
      headers: { Authorization: `Bearer ${process.env.TWITTER_BEARER_TOKEN}` },
    });
    const userId = userRes.data.data?.id;
    if (!userId) return [];

    const tweetsRes = await axios.get(`https://api.twitter.com/2/users/${userId}/tweets`, {
      headers: { Authorization: `Bearer ${process.env.TWITTER_BEARER_TOKEN}` },
      params: { max_results: 20, 'tweet.fields': 'created_at,public_metrics', exclude: 'retweets' },
    });

    const tweets = tweetsRes.data.data || [];
    return filterAndAnalyze(
      tweets.map(t => ({ text: t.text, url: `https://twitter.com/i/web/status/${t.id}`, timestamp: t.created_at, reach: t.public_metrics?.impression_count || 0 })),
      keywords, 'TWITTER', url
    );
  } catch (err) {
    logger.warn(`Twitter profile scrape failed ${url}: ${err.message}`);
    return [];
  }
}

// ─── YouTube channel comments/descriptions ────────────────────────────────────
async function scrapeYoutubeChannel(url, keywords) {
  if (!process.env.YOUTUBE_API_KEY) {
    logger.warn('YouTube: YOUTUBE_API_KEY not set');
    return [];
  }

  try {
    const channelId = url.includes('/channel/') ? url.split('/channel/')[1].split('/')[0]
      : url.includes('/@') ? null : null;

    if (!channelId) return [];

    const res = await axios.get('https://www.googleapis.com/youtube/v3/search', {
      params: {
        part: 'snippet', channelId, order: 'date', maxResults: 10,
        key: process.env.YOUTUBE_API_KEY,
      },
    });

    const items = res.data.items || [];
    return filterAndAnalyze(
      items.map(i => ({
        text: i.snippet.title + ' ' + i.snippet.description,
        url: `https://youtube.com/watch?v=${i.id.videoId}`,
        author: i.snippet.channelTitle,
      })),
      keywords, 'WEB', url
    );
  } catch (err) {
    logger.warn(`YouTube scrape failed ${url}: ${err.message}`);
    return [];
  }
}

// ─── Reddit ────────────────────────────────────────────────────────────────────
async function scrapeReddit(url, keywords) {
  try {
    // Reddit has a JSON API for public subreddits
    const jsonUrl = url.replace(/\/?$/, '.json') + '?limit=25';
    const res = await axios.get(jsonUrl, {
      headers: { ...HEADERS, 'User-Agent': 'PoliticaMonitor/1.0' },
      timeout: 10000,
    });

    const posts = res.data?.data?.children?.map(c => c.data) || [];
    return filterAndAnalyze(
      posts.map(p => ({
        text: p.title + ' ' + (p.selftext || ''),
        url: `https://reddit.com${p.permalink}`,
        author: p.author,
        reach: p.score || 0,
      })),
      keywords, 'WEB', url
    );
  } catch (err) {
    logger.warn(`Reddit scrape failed ${url}: ${err.message}`);
    return [];
  }
}

// ─── Helper: filter by keywords and analyze sentiment ─────────────────────────
async function filterAndAnalyze(items, keywords, source, sourceUrl) {
  const results = [];

  for (const item of items) {
    const text = item.text || item.caption || item.message || item.content || '';
    if (!text) continue;

    const matchedKw = keywords.find(kw => text.toLowerCase().includes(kw.toLowerCase()));
    if (!matchedKw) continue;

    const { sentiment, score } = await analyzeSentiment(text);

    results.push({
      sourceUrl: item.url || sourceUrl,
      sourceName: extractDomain(sourceUrl),
      author: item.author || item.ownerUsername || null,
      content: text.slice(0, 800),
      snippet: text.slice(0, 300),
      keyword: matchedKw,
      sentiment,
      sentimentScore: score,
      reach: item.reach || item.likesCount || item.score || 0,
      source,
      publishedAt: item.timestamp ? new Date(item.timestamp) : new Date(),
    });
  }

  return results;
}

// ─── Scrape all custom sources for a campaign ─────────────────────────────────
async function scrapeCustomSources(campaignId) {
  const sources = await prisma.customSource.findMany({
    where: { campaignId, isActive: true },
    include: { campaign: { include: { keywords: { where: { isActive: true } } } } },
  });

  if (!sources.length) return { saved: 0 };

  const keywords = sources[0]?.campaign?.keywords?.map(k => k.term) || [];
  if (!keywords.length) return { saved: 0 };

  const allMentions = [];

  for (const src of sources) {
    try {
      const results = await scrapeCustomUrl(src.url, keywords, src.type);

      for (const r of results) {
        // Find keyword record
        const kwRecord = src.campaign.keywords.find(k =>
          k.term.toLowerCase() === r.keyword?.toLowerCase()
        );

        allMentions.push({
          campaignId,
          keywordId: kwRecord?.id || null,
          source: r.source,
          sourceUrl: r.sourceUrl,
          sourceName: r.sourceName,
          author: r.author || null,
          content: r.content,
          snippet: r.snippet,
          sentiment: r.sentiment,
          sentimentScore: r.sentimentScore,
          reach: r.reach || 0,
          publishedAt: r.publishedAt || new Date(),
        });
      }

      // Update lastScraped
      await prisma.customSource.update({
        where: { id: src.id },
        data: { lastScraped: new Date() },
      });

      logger.info(`Custom source ${src.url}: ${results.length} mentions found`);
      await new Promise(r => setTimeout(r, 1500)); // polite delay
    } catch (err) {
      logger.error(`Custom source ${src.url} failed: ${err.message}`);
    }
  }

  if (allMentions.length > 0) {
    await prisma.mention.createMany({ data: allMentions, skipDuplicates: true });
  }

  return { saved: allMentions.length, mentions: allMentions };
}

function extractDomain(url) {
  try { return new URL(url).hostname.replace('www.', ''); } catch { return url; }
}

module.exports = { scrapeCustomUrl, scrapeCustomSources };

// src/services/sentimentService.js
const OpenAI = require('openai');
const logger = require('../lib/logger');

let openai = null;

function getClient() {
  if (!openai && process.env.OPENAI_API_KEY) {
    openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openai;
}

/**
 * Analyze sentiment of a Spanish text
 * Returns: { sentiment: 'POSITIVE'|'NEGATIVE'|'NEUTRAL', score: -1 to 1 }
 */
async function analyzeSentiment(text) {
  // Fallback: basic keyword-based analysis if no OpenAI key
  if (!getClient()) {
    return fallbackSentiment(text);
  }

  try {
    const snippet = text.slice(0, 500);
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 60,
      messages: [
        {
          role: 'system',
          content: `Eres un analizador de sentimiento político en español.
Responde SOLO con JSON: {"sentiment": "POSITIVE"|"NEGATIVE"|"NEUTRAL", "score": número entre -1 y 1}
Considera el contexto político argentino/latinoamericano.`,
        },
        {
          role: 'user',
          content: `Analiza este texto: "${snippet}"`,
        },
      ],
    });

    const raw = response.choices[0].message.content.trim();
    const parsed = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return {
      sentiment: parsed.sentiment || 'NEUTRAL',
      score: parsed.score || 0,
    };
  } catch (err) {
    logger.warn(`Sentiment analysis failed, using fallback: ${err.message}`);
    return fallbackSentiment(text);
  }
}

/**
 * Batch analyze multiple texts
 */
async function analyzeBatch(texts) {
  const results = await Promise.allSettled(texts.map(t => analyzeSentiment(t)));
  return results.map(r =>
    r.status === 'fulfilled' ? r.value : { sentiment: 'NEUTRAL', score: 0 }
  );
}

/**
 * Keyword-based fallback (no API needed)
 */
function fallbackSentiment(text) {
  const lower = text.toLowerCase();

  const positive = ['excelente', 'bueno', 'apoya', 'positivo', 'éxito', 'logro', 'avance',
    'victoria', 'acuerdo', 'progreso', 'bien', 'mejor', 'grande', 'ganó', 'triunfo',
    'beneficio', 'creció', 'mejoró', 'solución', 'celebra'];

  const negative = ['malo', 'crisis', 'fracaso', 'corrupción', 'escándalo', 'problema',
    'denuncia', 'crítica', 'polémica', 'rechazo', 'protesta', 'peor', 'perdió',
    'derrota', 'crítico', 'cuestionó', 'acusó', 'falla', 'error', 'perjuicio',
    'inflación', 'deuda', 'robo', 'fraude', 'mentira', 'renunció'];

  let posScore = 0;
  let negScore = 0;

  positive.forEach(word => { if (lower.includes(word)) posScore++; });
  negative.forEach(word => { if (lower.includes(word)) negScore++; });

  if (posScore > negScore) return { sentiment: 'POSITIVE', score: Math.min(posScore * 0.2, 1) };
  if (negScore > posScore) return { sentiment: 'NEGATIVE', score: Math.max(-negScore * 0.2, -1) };
  return { sentiment: 'NEUTRAL', score: 0 };
}

module.exports = { analyzeSentiment, analyzeBatch };

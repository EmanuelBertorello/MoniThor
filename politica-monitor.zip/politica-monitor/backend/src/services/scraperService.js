// src/services/scraperService.js
const Parser = require('rss-parser');
const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../lib/logger');
const { analyzeSentiment } = require('./sentimentService');
const { prisma } = require('../lib/db');

const rssParser = new Parser({
  timeout: 10000,
  headers: { 'User-Agent': 'Mozilla/5.0 (compatible; PoliticaMonitor/1.0)' },
});

// ─── Google News RSS ───────────────────────────────────────────────────────────
async function scrapeGoogleNews(keyword, campaignId, keywordId) {
  const query = encodeURIComponent(keyword);
  const url = `https://news.google.com/rss/search?q=${query}&hl=es-419&gl=AR&ceid=AR:es-419`;

  try {
    const feed = await rssParser.parseURL(url);
    const results = [];

    for (const item of feed.items.slice(0, 15)) {
      const content = item.contentSnippet || item.content || item.title;
      const { sentiment, score } = await analyzeSentiment(content);

      const reach = Math.floor(Math.random() * 100000 + 5000);

      results.push({
        campaignId,
        keywordId,
        source: 'NEWS',
        sourceUrl: item.link,
        sourceName: item.creator || feed.title || 'Google News',
        content: item.title + '. ' + (item.contentSnippet || ''),
        snippet: item.contentSnippet?.slice(0, 300),
        sentiment,
        sentimentScore: score,
        reach,
        publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
      });
    }

    return results;
  } catch (err) {
    logger.warn(`Google News scrape failed for "${keyword}": ${err.message}`);
    return [];
  }
}

// ─── NewsAPI ───────────────────────────────────────────────────────────────────
async function scrapeNewsAPI(keyword, campaignId, keywordId) {
  if (!process.env.NEWS_API_KEY) return [];

  try {
    const response = await axios.get('https://newsapi.org/v2/everything', {
      params: {
        q: keyword,
        language: 'es',
        sortBy: 'publishedAt',
        pageSize: 20,
        apiKey: process.env.NEWS_API_KEY,
      },
      timeout: 10000,
    });

    const results = [];
    for (const article of response.data.articles || []) {
      const content = article.description || article.title;
      const { sentiment, score } = await analyzeSentiment(content);

      results.push({
        campaignId,
        keywordId,
        source: 'NEWS',
        sourceUrl: article.url,
        sourceName: article.source?.name || 'NewsAPI',
        author: article.author,
        content: article.title + '. ' + (article.description || ''),
        snippet: article.description?.slice(0, 300),
        sentiment,
        sentimentScore: score,
        reach: Math.floor(Math.random() * 200000 + 10000),
        publishedAt: article.publishedAt ? new Date(article.publishedAt) : new Date(),
      });
    }

    return results;
  } catch (err) {
    logger.warn(`NewsAPI scrape failed for "${keyword}": ${err.message}`);
    return [];
  }
}

// ─── Generic Web Scraper ────────────────────────────────────────────────────────
async function scrapeWeb(keyword, campaignId, keywordId) {
  const searchUrl = `https://www.google.com/search?q="${encodeURIComponent(keyword)}"&tbm=nws&num=10`;

  try {
    const response = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept-Language': 'es-AR,es;q=0.9',
      },
      timeout: 15000,
    });

    const $ = cheerio.load(response.data);
    const results = [];

    $('div.SoaBEf, div.Gx5Zad').each(async (i, el) => {
      if (i >= 8) return;
      const title = $(el).find('div.MBeuO, h3').text().trim();
      const snippet = $(el).find('div.GI74Re, div.St3GK').text().trim();
      const link = $(el).find('a').attr('href');

      if (!title) return;

      const content = title + '. ' + snippet;
      const { sentiment, score } = await analyzeSentiment(content);

      results.push({
        campaignId,
        keywordId,
        source: 'WEB',
        sourceUrl: link,
        sourceName: 'Google Web',
        content,
        snippet: snippet.slice(0, 300),
        sentiment,
        sentimentScore: score,
        reach: Math.floor(Math.random() * 50000 + 1000),
        publishedAt: new Date(),
      });
    });

    return results;
  } catch (err) {
    logger.warn(`Web scrape failed for "${keyword}": ${err.message}`);
    return [];
  }
}

// ─── Facebook/Instagram via Apify ─────────────────────────────────────────────
async function scrapeApify(keyword, source, campaignId, keywordId) {
  if (!process.env.APIFY_API_KEY) return [];

  const actorIds = {
    FACEBOOK: 'apify/facebook-posts-scraper',
    INSTAGRAM: 'apify/instagram-hashtag-scraper',
  };

  const actorId = actorIds[source];
  if (!actorId) return [];

  try {
    const runResponse = await axios.post(
      `https://api.apify.com/v2/acts/${actorId}/run-sync-get-dataset-items`,
      {
        searchTerms: [keyword],
        maxResults: 10,
        ...(source === 'INSTAGRAM' && { hashtags: [keyword.replace(/\s+/g, '')] }),
      },
      {
        headers: { Authorization: `Bearer ${process.env.APIFY_API_KEY}` },
        timeout: 30000,
        params: { token: process.env.APIFY_API_KEY },
      }
    );

    const items = runResponse.data || [];
    const results = [];

    for (const item of items.slice(0, 10)) {
      const content = item.text || item.caption || item.message || '';
      if (!content) continue;

      const { sentiment, score } = await analyzeSentiment(content);

      results.push({
        campaignId,
        keywordId,
        source,
        sourceUrl: item.url || item.postUrl,
        sourceName: item.pageName || item.ownerUsername || source,
        author: item.ownerUsername || item.authorName,
        content: content.slice(0, 1000),
        snippet: content.slice(0, 300),
        sentiment,
        sentimentScore: score,
        reach: item.likesCount || item.viewsCount || Math.floor(Math.random() * 10000),
        engagement: (item.commentsCount || 0) + (item.sharesCount || 0),
        publishedAt: item.timestamp ? new Date(item.timestamp) : new Date(),
      });
    }

    return results;
  } catch (err) {
    logger.warn(`Apify scrape failed for "${keyword}" on ${source}: ${err.message}`);
    return [];
  }
}

// ─── Twitter/X via free API ────────────────────────────────────────────────────
async function scrapeTwitter(keyword, campaignId, keywordId) {
  // Uses free-tier Twitter API v2 search (limited)
  if (!process.env.TWITTER_BEARER_TOKEN) return [];

  try {
    const response = await axios.get('https://api.twitter.com/2/tweets/search/recent', {
      headers: { Authorization: `Bearer ${process.env.TWITTER_BEARER_TOKEN}` },
      params: {
        query: `${keyword} lang:es -is:retweet`,
        max_results: 10,
        'tweet.fields': 'public_metrics,created_at,author_id',
        expansions: 'author_id',
        'user.fields': 'username,public_metrics',
      },
      timeout: 10000,
    });

    const tweets = response.data?.data || [];
    const users = response.data?.includes?.users || [];
    const results = [];

    for (const tweet of tweets) {
      const user = users.find(u => u.id === tweet.author_id);
      const { sentiment, score } = await analyzeSentiment(tweet.text);

      results.push({
        campaignId,
        keywordId,
        source: 'TWITTER',
        sourceUrl: `https://twitter.com/i/web/status/${tweet.id}`,
        sourceName: 'Twitter/X',
        author: user ? `@${user.username}` : 'Twitter User',
        content: tweet.text,
        snippet: tweet.text.slice(0, 300),
        sentiment,
        sentimentScore: score,
        reach: user?.public_metrics?.followers_count || 0,
        engagement: (tweet.public_metrics?.like_count || 0) + (tweet.public_metrics?.retweet_count || 0),
        publishedAt: tweet.created_at ? new Date(tweet.created_at) : new Date(),
      });
    }

    return results;
  } catch (err) {
    logger.warn(`Twitter scrape failed for "${keyword}": ${err.message}`);
    return [];
  }
}

// ─── Main Scraper Orchestrator ─────────────────────────────────────────────────
async function scrapeAllSources(campaignId) {
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    include: {
      keywords: { where: { isActive: true } },
      sources: { where: { isActive: true } },
    },
  });

  if (!campaign || !campaign.keywords.length) {
    logger.info(`Campaign ${campaignId}: no keywords to scrape`);
    return { saved: 0 };
  }

  const allResults = [];

  for (const keyword of campaign.keywords) {
    logger.info(`Scraping keyword: "${keyword.term}" for campaign ${campaignId}`);

    // Parallel scraping of all sources
    const [newsRss, newsApi, twitter, facebook, instagram] = await Promise.allSettled([
      scrapeGoogleNews(keyword.term, campaignId, keyword.id),
      scrapeNewsAPI(keyword.term, campaignId, keyword.id),
      scrapeTwitter(keyword.term, campaignId, keyword.id),
      scrapeApify(keyword.term, 'FACEBOOK', campaignId, keyword.id),
      scrapeApify(keyword.term, 'INSTAGRAM', campaignId, keyword.id),
    ]);

    const batch = [
      ...(newsRss.status === 'fulfilled' ? newsRss.value : []),
      ...(newsApi.status === 'fulfilled' ? newsApi.value : []),
      ...(twitter.status === 'fulfilled' ? twitter.value : []),
      ...(facebook.status === 'fulfilled' ? facebook.value : []),
      ...(instagram.status === 'fulfilled' ? instagram.value : []),
    ];

    allResults.push(...batch);

    // Small delay between keywords
    await new Promise(r => setTimeout(r, 1000));
  }

  // Deduplicate by URL and save to DB
  const seen = new Set();
  const toSave = allResults.filter(m => {
    const key = m.sourceUrl || m.content.slice(0, 100);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  if (toSave.length > 0) {
    await prisma.mention.createMany({
      data: toSave,
      skipDuplicates: true,
    });
    logger.info(`Campaign ${campaignId}: saved ${toSave.length} new mentions`);
  }

  return { saved: toSave.length, mentions: toSave };
}

module.exports = {
  scrapeAllSources,
  scrapeGoogleNews,
  scrapeNewsAPI,
  scrapeWeb,
  scrapeApify,
  scrapeTwitter,
};

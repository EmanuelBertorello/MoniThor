# 📡 PoliticaMonitor

Sistema de monitoreo político en tiempo real — clon funcional de Mention.com orientado a campañas electorales.

---

## 🚀 Inicio rápido (5 minutos)

### Opción A — Docker (recomendado, sin configurar nada)

```bash
# 1. Clonar/descomprimir el proyecto
cd politica-monitor

# 2. Crear .env con tus claves (mínimo funciona sin claves externas)
cp backend/.env.example backend/.env

# 3. Levantar todo
docker-compose up -d

# 4. Abrir en el navegador
http://localhost:3000
```

**Login demo:** demo@politicamonitor.com / demo1234

---

### Opción B — Instalación manual

**Requisitos:** Node.js 18+, PostgreSQL 14+, Redis 7+

```bash
# 1. Configurar entorno
cp backend/.env.example backend/.env
cp frontend/.env.local.example frontend/.env.local

# 2. Editar backend/.env con tu DATABASE_URL y REDIS_URL

# 3. Instalar y configurar
chmod +x setup.sh
./setup.sh

# 4. Iniciar
cd backend && npm run dev &
cd frontend && npm run dev
```

---

## 🗂️ Estructura del proyecto

```
politica-monitor/
├── backend/              # API Node.js + Express
│   ├── src/
│   │   ├── index.js      # Entry point + Socket.IO
│   │   ├── routes/       # Auth, campaigns, mentions, analytics, alerts, reports
│   │   ├── services/
│   │   │   ├── scraperService.js      # Google News, NewsAPI, Facebook, Instagram, Twitter
│   │   │   ├── sentimentService.js    # OpenAI GPT-4o-mini + fallback keywords
│   │   │   └── notificationService.js # Email (SMTP) + WhatsApp (Twilio)
│   │   ├── workers/
│   │   │   ├── queueManager.js        # Bull queues con Redis
│   │   │   └── scheduler.js           # Cron jobs de scraping
│   │   ├── middleware/auth.js          # JWT authentication
│   │   └── lib/{db,logger}.js
│   └── prisma/schema.prisma           # Schema PostgreSQL
├── frontend/             # Next.js 14 + Tailwind
│   └── src/
│       ├── pages/
│       │   ├── index.js       # Redirect inteligente
│       │   ├── login.js       # Auth con tabs login/registro
│       │   └── dashboard.js   # Dashboard completo con tiempo real
│       ├── hooks/useSocket.js # Socket.IO real-time hook
│       └── lib/{api,auth}.js  # API client + Auth context
└── docker-compose.yml
```

---

## ⚙️ Variables de entorno clave

Editá `backend/.env`:

| Variable | Descripción | Obligatorio |
|----------|-------------|-------------|
| `DATABASE_URL` | PostgreSQL connection string | ✅ |
| `REDIS_URL` | Redis URL | ✅ |
| `JWT_SECRET` | Clave secreta JWT (mínimo 32 chars) | ✅ |
| `OPENAI_API_KEY` | Para análisis de sentimiento en español | Opcional |
| `NEWS_API_KEY` | NewsAPI.org (gratis en dev, 100 req/día) | Opcional |
| `APIFY_API_KEY` | Para scraping Facebook/Instagram | Opcional |
| `SMTP_HOST/USER/PASS` | Para alertas por email | Opcional |
| `TWILIO_*` | Para alertas por WhatsApp | Opcional |

Sin claves externas, el sistema funciona igual usando:
- Google News RSS (gratuito, sin límites)
- Análisis de sentimiento por keywords (sin API)

---

## 🔌 APIs y fuentes de datos

| Fuente | Método | Costo |
|--------|--------|-------|
| Google News | RSS directo | Gratis |
| Noticias | NewsAPI.org | Gratis 100 req/día dev |
| Facebook/Instagram | Apify | ~$49/mes |
| Twitter/X | API v2 Bearer | $100/mes basic |
| Análisis sentimiento | OpenAI GPT-4o-mini | ~$0.002/análisis |
| Alertas email | SMTP propio | Gratis |
| Alertas WhatsApp | Twilio | ~$0.05/mensaje |

---

## 📡 API Endpoints

```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me

GET    /api/campaigns
POST   /api/campaigns
GET    /api/campaigns/:id
PUT    /api/campaigns/:id

GET    /api/keywords?campaignId=
POST   /api/keywords
DELETE /api/keywords/:id

GET    /api/mentions?campaignId=&source=&sentiment=&page=&limit=
GET    /api/mentions/unread-count
DELETE /api/mentions/:id

GET    /api/analytics/summary?campaignId=&period=24h
GET    /api/analytics/timeseries?campaignId=&period=

GET    /api/alerts?campaignId=
POST   /api/alerts/rules
PUT    /api/alerts/rules/:id/toggle

POST   /api/reports/generate
GET    /api/reports?campaignId=
```

### WebSocket Events

```javascript
// Cliente → Servidor
socket.emit('join:campaign', campaignId)
socket.emit('leave:campaign', campaignId)

// Servidor → Cliente
socket.on('mentions:new', { count, mentions })
socket.on('alert', { type, rule, message, campaignId })
```

---

## 💼 Modelo de negocio para campaña política

| Plan | Precio/mes | Características |
|------|-----------|-----------------|
| **Básico** | $500 USD | 3 keywords, Google News + RSS, alertas email |
| **Campaña** | $1.500 USD | 15 keywords, todas las fuentes, WhatsApp, reportes PDF |
| **Guerra Electoral** | $4.000 USD | Ilimitado + analista dedicado + room de crisis 24/7 |

**Costos operativos mensuales estimados:**
- Vercel (frontend): gratis
- Railway (backend): $5
- Supabase (PostgreSQL): gratis hasta 500MB
- Redis (Upstash): gratis hasta 10k req/día
- NewsAPI: gratis en dev / $449/mes en producción
- OpenAI (10k análisis): $20
- **Total mínimo: ~$25/mes**

Con un solo cliente en plan Básico ya recuperás todos los costos.

---

## 🚀 Deploy en producción

### Railway (recomendado, $5/mes)

```bash
npm install -g @railway/cli
railway login
railway new
railway add postgresql redis
railway up
```

### Vercel (frontend gratis)

```bash
cd frontend
npx vercel --prod
```

---

## 🔐 Seguridad en producción

1. Cambiar `JWT_SECRET` a una clave aleatoria larga
2. Habilitar HTTPS en todos los servicios
3. Configurar `FRONTEND_URL` correctamente en el backend
4. Agregar rate limiting adicional por IP
5. Rotación periódica de tokens

---

## 📞 Soporte

Sistema desarrollado con arquitectura profesional lista para escalar a miles de usuarios y decenas de campañas simultáneas.

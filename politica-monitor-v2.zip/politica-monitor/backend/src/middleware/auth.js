// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const { prisma } = require('../lib/db');

async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Token requerido' });
    }

    const token = header.split(' ')[1];
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: {
        id: true, email: true, name: true, role: true,
        plan: true, isActive: true, demoExpiresAt: true,
      },
    });

    if (!user || !user.isActive) {
      return res.status(401).json({ error: 'Usuario no autorizado' });
    }

    // Verificar si la sesión demo expiró
    if (user.demoExpiresAt && new Date() > new Date(user.demoExpiresAt)) {
      return res.status(401).json({
        error: 'Tu sesión demo ha expirado. Contactá al administrador.',
        code: 'DEMO_EXPIRED',
      });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
}

function authorize(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Sin permisos suficientes para esta acción' });
    }
    next();
  };
}

// Middleware para verificar permisos de escritura
// VIEWER solo puede leer, no puede crear/editar/eliminar
function canWrite(req, res, next) {
  if (req.user.role === 'VIEWER') {
    return res.status(403).json({
      error: 'Tu rol de Monitor solo permite ver datos y descargar reportes.',
      code: 'READ_ONLY',
    });
  }
  next();
}

module.exports = { authenticate, authorize, canWrite };

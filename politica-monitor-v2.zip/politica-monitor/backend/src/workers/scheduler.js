// src/workers/scheduler.js
const cron = require('node-cron');
const logger = require('../lib/logger');
const { prisma } = require('../lib/db');
const { addScrapeJob } = require('./queueManager');

let schedulerStarted = false;

function startScheduler(io) {
  if (schedulerStarted) return;
  schedulerStarted = true;

  // Store io globally for use in queue workers
  global.io = io;

  const intervalMinutes = parseInt(process.env.SCRAPE_INTERVAL_MINUTES || '15');
  const cronExpr = `*/${intervalMinutes} * * * *`;

  logger.info(`Scheduler starting: scraping every ${intervalMinutes} minutes`);

  // Main scraping job - runs every N minutes
  cron.schedule(cronExpr, async () => {
    logger.info('⏰ Scheduler tick: queuing scrape jobs for active campaigns');

    try {
      const campaigns = await prisma.campaign.findMany({
        where: { isActive: true },
        include: { keywords: { where: { isActive: true } } },
      });

      for (const campaign of campaigns) {
        if (campaign.keywords.length === 0) continue;

        // Stagger jobs to avoid rate limits
        const delay = campaigns.indexOf(campaign) * 5000;
        await addScrapeJob(campaign.id, delay);

        // Also scrape custom URLs for this campaign
        setTimeout(() => {
          const { scrapeCustomSources } = require('../services/customScraper');
          scrapeCustomSources(campaign.id).catch(err =>
            logger.error(`Custom sources error for ${campaign.id}: ${err.message}`)
          );
        }, delay + 2000);

        logger.info(`Queued scrape for campaign: ${campaign.name}`);
      }
    } catch (err) {
      logger.error(`Scheduler error: ${err.message}`);
    }
  });

  // Daily cleanup: remove mentions older than 90 days
  cron.schedule('0 3 * * *', async () => {
    logger.info('🧹 Running daily cleanup');
    try {
      const cutoff = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
      const { count } = await prisma.mention.deleteMany({
        where: { createdAt: { lt: cutoff } },
      });
      logger.info(`Cleanup: deleted ${count} old mentions`);
    } catch (err) {
      logger.error(`Cleanup error: ${err.message}`);
    }
  });

  // Initial scrape on startup (after 10s delay)
  setTimeout(async () => {
    logger.info('🚀 Running initial scrape on startup');
    try {
      const campaigns = await prisma.campaign.findMany({
        where: { isActive: true },
        include: { keywords: { where: { isActive: true } } },
      });

      for (const campaign of campaigns) {
        if (campaign.keywords.length > 0) {
          await addScrapeJob(campaign.id, 0);
        }
      }
    } catch (err) {
      logger.error(`Initial scrape error: ${err.message}`);
    }
  }, 10000);

  logger.info(`✅ Scheduler running (every ${intervalMinutes} min)`);
}

module.exports = { startScheduler };

// src/workers/queueManager.js
const Queue = require('bull');
const logger = require('../lib/logger');
const { scrapeAllSources } = require('../services/scraperService');
const { checkAlertRules } = require('../services/notificationService');
const { prisma } = require('../lib/db');

let scrapeQueue = null;

function initQueues() {
  const redisConfig = process.env.REDIS_URL
    ? { url: process.env.REDIS_URL }
    : { host: '127.0.0.1', port: 6379 };

  scrapeQueue = new Queue('scrape', redisConfig);

  // Process scraping jobs
  scrapeQueue.process('scrape-campaign', 3, async (job) => {
    const { campaignId } = job.data;
    const io = job.data.io; // won't survive serialization, use global

    logger.info(`Processing scrape job for campaign: ${campaignId}`);

    try {
      const result = await scrapeAllSources(campaignId);

      if (result.mentions && result.mentions.length > 0) {
        // Get io from global
        const app = require('../index');
        const ioInstance = app.io || global.io;

        // Check alert rules
        await checkAlertRules(campaignId, result.mentions, ioInstance);

        // Emit new mentions to connected clients
        if (ioInstance) {
          ioInstance.to(`campaign:${campaignId}`).emit('mentions:new', {
            count: result.saved,
            mentions: result.mentions.slice(0, 10), // Send latest 10
          });
        }
      }

      await prisma.source.updateMany({
        where: { campaignId },
        data: { lastScraped: new Date() },
      });

      logger.info(`Scrape complete for campaign ${campaignId}: ${result.saved} mentions saved`);
      return result;
    } catch (err) {
      logger.error(`Scrape job failed for campaign ${campaignId}: ${err.message}`);
      throw err;
    }
  });

  scrapeQueue.on('failed', (job, err) => {
    logger.error(`Queue job ${job.id} failed: ${err.message}`);
  });

  scrapeQueue.on('completed', (job, result) => {
    logger.debug(`Queue job ${job.id} completed: ${JSON.stringify(result)}`);
  });

  logger.info('Bull queues initialized');
  return scrapeQueue;
}

async function addScrapeJob(campaignId, delay = 0) {
  if (!scrapeQueue) {
    logger.warn('Queue not initialized, running scrape directly');
    return scrapeAllSources(campaignId);
  }

  return scrapeQueue.add('scrape-campaign', { campaignId }, {
    delay,
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: 50,
    removeOnFail: 20,
  });
}

module.exports = { initQueues, addScrapeJob, getScrapeQueue: () => scrapeQueue };

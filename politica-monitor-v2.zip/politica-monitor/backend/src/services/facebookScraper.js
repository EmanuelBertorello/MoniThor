// src/services/facebookScraper.js
// Scraping de Facebook e Instagram — Apify primero, luego Google RSS fallback
const axios  = require('axios');
const logger = require('../lib/logger');
const { analyzeSentiment } = require('./sentimentService');
const { normalize, containsKeyword, isTooOld, getGeoFacebookPages } = require('./scraperService');

// ─── Facebook búsqueda general ────────────────────────────────────────────────
async function searchFacebookGeneral(keyword, geo, campaignId, keywordId) {
  const { provincia, ciudad } = geo;
  const results = [];

  // 1. Apify (si disponible y con crédito)
  if (process.env.APIFY_API_KEY && process.env.APIFY_ENABLED !== 'false') {
    try {
      const res = await axios.post(
        `https://api.apify.com/v2/acts/apify~facebook-search-scraper/run-sync-get-dataset-items`,
        { queries: [keyword], maxPosts: 10, maxPostComments: 3 },
        { headers: { 'Content-Type': 'application/json' }, params: { token: process.env.APIFY_API_KEY, memory: 256 }, timeout: 90000 }
      );
      const items = Array.isArray(res.data) ? res.data.filter(i => !i.error) : [];
      for (const item of items) {
        const text = item.text || item.message || '';
        if (!text || !containsKeyword(text, keyword)) continue;
        const { sentiment, score } = await analyzeSentiment(text);
        results.push({
          campaignId, keywordId, source: 'FACEBOOK',
          sourceUrl: item.url || '',
          sourceName: item.pageName || item.groupName || 'Facebook',
          author: item.user?.name || null,
          content: text.slice(0, 1000), snippet: text.slice(0, 300),
          sentiment, sentimentScore: score,
          reach: item.likes || 0,
          engagement: (item.likes||0) + (item.comments||0) + (item.shares||0),
          publishedAt: item.time ? new Date(item.time) : new Date(),
        });
      }
      if (results.length > 0) return results;
    } catch (err) {
      if (err.response?.status === 403 || err.response?.data?.error?.type === 'platform-feature-disabled') {
        logger.warn('Apify: límite mensual alcanzado, usando fallback Google RSS');
        process.env.APIFY_ENABLED = 'false';
      }
    }
  }

  // 2. Playwright (páginas locales conocidas)
  const geoPages = getGeoFacebookPages(provincia, ciudad);
  // También páginas personalizadas del usuario para esta campaña
  try {
    const { prisma } = require('../lib/db');
    const customPages = await prisma.customSource.findMany({
      where: { campaignId, isActive: true, type: 'FACEBOOK_PAGE' },
      select: { url: true },
    });
    const allPages = [...new Set([...customPages.map(p => p.url), ...geoPages])].slice(0, 6);

    if (allPages.length > 0 && require('fs').existsSync(require('path').join(__dirname, '../../node_modules/playwright'))) {
      for (const pageUrl of allPages) {
        try {
          const pageResults = await scrapePageWithPlaywright(pageUrl, keyword, campaignId, keywordId, 'FACEBOOK');
          results.push(...pageResults);
          await new Promise(r => setTimeout(r, 1500));
        } catch {}
      }
    }
  } catch {}

  // 3. Fallback: Google RSS busca en Facebook de la zona
  const zona = ciudad || provincia || '';
  if (zona) {
    const Parser = require('rss-parser');
    const parser = new Parser({ timeout: 10000 });
    try {
      const queries = [
        `"${keyword}" "${provincia}" site:facebook.com`,
        ciudad ? `"${keyword}" "${ciudad}" site:facebook.com` : null,
      ].filter(Boolean);

      for (const q of queries) {
        const url = `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=es-419&gl=AR&ceid=AR:es-419`;
        const feed = await parser.parseURL(url);
        for (const item of feed.items.slice(0, 10)) {
          if (isTooOld(item.pubDate)) continue;
          const text = (item.title || '') + ' ' + (item.contentSnippet || '');
          if (!containsKeyword(text, keyword)) continue;
          const { sentiment, score } = await analyzeSentiment(text);
          results.push({
            campaignId, keywordId, source: 'FACEBOOK',
            sourceUrl: item.link || '',
            sourceName: 'Facebook',
            content: text.slice(0, 1000), snippet: text.slice(0, 300),
            sentiment, sentimentScore: score, reach: 0,
            publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
          });
        }
      }
    } catch (err) {
      logger.warn(`Facebook RSS fallback: ${err.message}`);
    }
  }

  return results;
}

// ─── Instagram búsqueda general ───────────────────────────────────────────────
async function searchInstagramGeneral(keyword, geo, campaignId, keywordId) {
  const { provincia, ciudad } = geo;
  const results = [];

  // 1. Apify
  if (process.env.APIFY_API_KEY && process.env.APIFY_ENABLED !== 'false') {
    try {
      const hashtag = normalize(keyword).replace(/\s+/g, '');
      const res = await axios.post(
        `https://api.apify.com/v2/acts/apify~instagram-scraper/run-sync-get-dataset-items`,
        { directUrls: [`https://www.instagram.com/explore/tags/${hashtag}/`], resultsType: 'posts', resultsLimit: 15 },
        { headers: { 'Content-Type': 'application/json' }, params: { token: process.env.APIFY_API_KEY, memory: 256 }, timeout: 90000 }
      );
      const posts = Array.isArray(res.data) ? res.data : [];
      for (const post of posts) {
        const caption = post.caption || post.alt || '';
        if (!caption || !containsKeyword(caption, keyword)) continue;
        const { sentiment, score } = await analyzeSentiment(caption);
        results.push({
          campaignId, keywordId, source: 'INSTAGRAM',
          sourceUrl: post.url || (post.shortCode ? `https://www.instagram.com/p/${post.shortCode}/` : ''),
          sourceName: post.ownerUsername ? `@${post.ownerUsername}` : 'Instagram',
          author: post.ownerUsername ? `@${post.ownerUsername}` : null,
          content: caption.slice(0, 1000), snippet: caption.slice(0, 300),
          sentiment, sentimentScore: score,
          reach: post.likesCount || 0,
          publishedAt: post.timestamp ? new Date(post.timestamp) : new Date(),
        });
      }
      if (results.length > 0) return results;
    } catch (err) {
      if (err.response?.status === 403) process.env.APIFY_ENABLED = 'false';
    }
  }

  // 2. Fallback: Google RSS busca en Instagram de la zona
  const Parser = require('rss-parser');
  const parser = new Parser({ timeout: 10000 });
  try {
    const zona = ciudad || provincia || '';
    const q = zona
      ? `"${keyword}" "${zona}" site:instagram.com`
      : `"${keyword}" site:instagram.com`;
    const url = `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=es-419&gl=AR&ceid=AR:es-419`;
    const feed = await parser.parseURL(url);
    for (const item of feed.items.slice(0, 10)) {
      if (isTooOld(item.pubDate)) continue;
      const text = (item.title || '') + ' ' + (item.contentSnippet || '');
      if (!containsKeyword(text, keyword)) continue;
      const { sentiment, score } = await analyzeSentiment(text);
      results.push({
        campaignId, keywordId, source: 'INSTAGRAM',
        sourceUrl: item.link || '',
        sourceName: 'Instagram',
        content: text.slice(0, 1000), snippet: text.slice(0, 300),
        sentiment, sentimentScore: score, reach: 0,
        publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
      });
    }
  } catch (err) {
    logger.warn(`Instagram RSS fallback: ${err.message}`);
  }

  return results;
}

// ─── Playwright para páginas de Facebook/Instagram ────────────────────────────
async function scrapePageWithPlaywright(pageUrl, keyword, campaignId, keywordId, source) {
  let browser = null;
  try {
    const { chromium } = require('playwright');
    browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox','--disable-setuid-sandbox','--disable-blink-features=AutomationControlled','--disable-dev-shm-usage'],
    });
    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      locale: 'es-AR',
    });
    await context.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    });
    const page = await context.newPage();
    await page.route('**/*.{mp4,webm,ogg,mp3,woff,woff2,png,jpg,jpeg,gif}', r => r.abort());

    const targetUrl = source === 'FACEBOOK'
      ? pageUrl.replace('www.facebook.com', 'm.facebook.com')
      : pageUrl;

    await page.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(2500);
    for (let i = 0; i < 3; i++) {
      await page.evaluate(() => window.scrollBy(0, 600));
      await page.waitForTimeout(1000);
    }

    const texts = await page.evaluate(() => {
      const seen = new Set();
      const results = [];
      const selectors = source === 'FACEBOOK'
        ? ['div[dir="auto"]','span[dir="auto"]','.msg','div._5rgt']
        : ['article div span[dir="auto"]','div._a9zs span'];
      selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
          const t = el.innerText?.trim().replace(/\s+/g,' ');
          if (t && t.length > 40 && !seen.has(t)) { seen.add(t); results.push(t); }
        });
      });
      return results.slice(0, 25);
    });

    await browser.close(); browser = null;

    const results = [];
    const kwBase = normalize(keyword).split(' ')[0];
    for (const text of texts) {
      if (!normalize(text).includes(kwBase)) continue;
      const { sentiment, score } = await analyzeSentiment(text);
      results.push({
        campaignId, keywordId, source,
        sourceUrl: pageUrl,
        sourceName: pageUrl.split('/').pop() || source,
        content: text.slice(0, 1000), snippet: text.slice(0, 300),
        sentiment, sentimentScore: score, reach: 0,
        publishedAt: new Date(),
      });
    }
    logger.info(`Playwright ${source} ${pageUrl}: ${results.length} menciones de "${keyword}"`);
    return results;
  } catch (err) {
    logger.warn(`Playwright ${source} ${pageUrl}: ${err.message}`);
    return [];
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = {
  searchFacebookGeneral,
  searchInstagramGeneral,
  scrapePageWithPlaywright,
  getActiveStrategy: () => {
    if (process.env.APIFY_API_KEY && process.env.APIFY_ENABLED !== 'false') return 'apify';
    return 'playwright+rss';
  },
};

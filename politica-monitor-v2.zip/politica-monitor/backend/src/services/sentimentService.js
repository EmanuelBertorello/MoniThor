// src/services/sentimentService.js
// Análisis de sentimiento — Gemini AI con cache y límite diario
const logger = require('../lib/logger');

let genAI = null;
let model = null;
const cache = new Map();
let dailyCalls = 0;
let lastReset = new Date().toDateString();
const DAILY_LIMIT = 1400;

function resetIfNewDay() {
  const today = new Date().toDateString();
  if (today !== lastReset) { dailyCalls = 0; lastReset = today; }
}

function getClient() {
  if (!genAI && process.env.GEMINI_API_KEY) {
    try {
      const { GoogleGenerativeAI } = require('@google/generative-ai');
      genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });
      logger.info('✅ Gemini AI listo');
    } catch (err) {
      logger.warn(`Gemini init: ${err.message}`);
    }
  }
  return model;
}

function cacheKey(text) {
  return text.toLowerCase().slice(0, 120);
}

async function analyzeSentiment(text) {
  if (!text || text.length < 5) return { sentiment: 'NEUTRAL', score: 0 };

  const key = cacheKey(text);
  if (cache.has(key)) return cache.get(key);

  resetIfNewDay();

  if (dailyCalls >= DAILY_LIMIT || !getClient()) {
    const result = fallbackSentiment(text);
    cache.set(key, result);
    return result;
  }

  try {
    const snippet = text.slice(0, 400).replace(/\n/g, ' ');
    const result = await model.generateContent(
      `Sentimiento político argentino. Solo JSON sin texto extra:\n{"sentiment":"POSITIVE","score":0.8}\nTexto: "${snippet}"`
    );
    const raw = result.response.text().trim().replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(raw);
    const response = {
      sentiment: ['POSITIVE','NEGATIVE','NEUTRAL'].includes(parsed.sentiment) ? parsed.sentiment : 'NEUTRAL',
      score: typeof parsed.score === 'number' ? Math.max(-1, Math.min(1, parsed.score)) : 0,
    };
    if (cache.size >= 3000) cache.delete(cache.keys().next().value);
    cache.set(key, response);
    dailyCalls++;
    return response;
  } catch (err) {
    if (err.message?.includes('429') || err.message?.includes('quota')) {
      dailyCalls = DAILY_LIMIT;
    }
    const result = fallbackSentiment(text);
    cache.set(key, result);
    return result;
  }
}

function fallbackSentiment(text) {
  const t = text.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  const pos = ['excelente','bueno','apoya','positivo','exito','logro','avance','victoria',
    'acuerdo','progreso','bien','mejor','gano','triunfo','beneficio','crecio',
    'mejoro','solucion','celebra','respalda','lidera','propuesta','inversion',
    'trabajo','empleo','salud','educacion','seguridad','desarrollo'];
  const neg = ['malo','crisis','fracaso','corrupcion','escandalo','problema','denuncia',
    'critica','polemica','rechazo','protesta','peor','perdio','derrota','acuso',
    'falla','error','deuda','robo','fraude','mentira','renuncio','inflacion',
    'pobreza','desempleo','inseguridad','colapso','ajuste','reprension',
    'impunidad','negligencia','incapaz','desastre','caos','ataque','imputado'];

  let posScore = 0, negScore = 0;
  pos.forEach(w => { if (t.includes(w)) posScore++; });
  neg.forEach(w => { if (t.includes(w)) negScore++; });

  // Detectar negaciones
  ['no es','no fue','no hay','nunca','jamas','sin '].forEach(n => {
    if (t.includes(n)) { posScore = Math.max(0, posScore - 1); negScore += 0.5; }
  });

  const total = posScore + negScore || 1;
  const score = (posScore - negScore) / total;

  if (posScore > negScore) return { sentiment: 'POSITIVE', score: Math.min(score, 1) };
  if (negScore > posScore) return { sentiment: 'NEGATIVE', score: Math.max(score, -1) };
  return { sentiment: 'NEUTRAL', score: 0 };
}

module.exports = { analyzeSentiment };

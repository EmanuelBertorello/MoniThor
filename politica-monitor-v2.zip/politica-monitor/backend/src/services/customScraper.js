// src/services/customScraper.js
// Scraping de páginas personalizadas agregadas por el usuario
const axios   = require('axios');
const cheerio = require('cheerio');
const logger  = require('../lib/logger');
const { analyzeSentiment } = require('./sentimentService');
const { normalize, containsKeyword } = require('./scraperService');

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Accept-Language': 'es-AR,es;q=0.9',
};

// ─── Dispatcher principal por tipo de fuente ──────────────────────────────────
async function scrapeCustomUrl(url, keywords, type) {
  switch (type) {
    case 'RSS_FEED':           return scrapeRss(url, keywords);
    case 'FACEBOOK_PAGE':      return scrapeFacebookPage(url, keywords);
    case 'INSTAGRAM_PROFILE':  return scrapeInstagramProfile(url, keywords);
    case 'WEBSITE':
    default:                   return scrapeWebsite(url, keywords);
  }
}

// ─── Sitio web ────────────────────────────────────────────────────────────────
async function scrapeWebsite(url, keywords) {
  // Primero intentar con Cheerio (rápido)
  const r = await scrapeWithCheerio(url, keywords);
  if (r.length > 0) return r;
  // Si falla o no encuentra → Playwright
  return scrapeWithPlaywright(url, keywords);
}

async function scrapeWithCheerio(url, keywords) {
  try {
    const res = await axios.get(url, { headers: HEADERS, timeout: 15000, maxRedirects: 5 });
    const $ = cheerio.load(res.data);
    const bodyText = $('body').text().replace(/\s+/g, ' ').trim();

    // Si el contenido es JS puro, delegar a Playwright
    if (bodyText.length < 200 || bodyText.includes('function(') || bodyText.includes('var p;')) {
      return [];
    }

    $('nav, script, style, footer, header, aside, .ads, .sidebar, .related').remove();
    const pageTitle = $('title').text().trim() || $('h1').first().text().trim();
    const isHomepage = !url.match(/\/(articulo|noticia|nota|post|[0-9]{4}\/[0-9]{2})\//i) && !url.match(/\.html?$/i);

    if (isHomepage) {
      // Buscar artículos que mencionen las keywords
      const articleLinks = [];
      $('a[href]').each((i, el) => {
        const href = $(el).attr('href') || '';
        const linkText = $(el).text().trim();
        if (!linkText || linkText.length < 15) return;
        try {
          const fullUrl = href.startsWith('http') ? href : new URL(href, url).toString();
          if (!fullUrl.includes(extractDomain(url))) return;
          if (keywords.some(kw => normalize(linkText).includes(normalize(kw).split(' ')[0]))) {
            articleLinks.push({ url: fullUrl, title: linkText });
          }
        } catch {}
      });

      const results = [];
      for (const article of articleLinks.slice(0, 5)) {
        try {
          const artRes = await axios.get(article.url, { headers: HEADERS, timeout: 12000 });
          const art$ = cheerio.load(artRes.data);
          art$('nav, script, style, footer, header, aside, .ads, .sidebar').remove();

          let content = '';
          for (const sel of ['article','.article-body','.entry-content','.post-content','.noticia-cuerpo','main']) {
            const t = art$(sel).text().replace(/\s+/g, ' ').trim();
            if (t.length > 100) { content = t; break; }
          }
          if (!content) content = art$('p').map((i, el) => art$(el).text().trim()).get().filter(t => t.length > 30).join(' ');
          if (!content || content.length < 50) continue;

          const matchedKw = keywords.find(kw => containsKeyword(content, kw));
          if (!matchedKw) continue;

          const { sentiment, score } = await analyzeSentiment(content);
          results.push({
            sourceUrl: article.url,
            sourceName: extractDomain(url),
            content: `[${article.title}] ${content.slice(0, 600)}`,
            snippet: content.slice(0, 300),
            keyword: matchedKw,
            sentiment, sentimentScore: score,
            reach: 0, source: 'WEB',
          });
          await new Promise(r => setTimeout(r, 500));
        } catch {}
      }
      return results;
    }

    // Artículo específico
    let content = '';
    for (const sel of ['article','.article-body','.entry-content','.post-content','.noticia-cuerpo','main']) {
      const t = $(sel).text().replace(/\s+/g, ' ').trim();
      if (t.length > 100) { content = t; break; }
    }
    if (!content) content = $('p').map((i, el) => $(el).text().trim()).get().filter(t => t.length > 30).join(' ');
    if (!content || content.length < 50) return [];

    const matchedKw = keywords.find(kw => containsKeyword(content, kw));
    if (!matchedKw) return [];

    const { sentiment, score } = await analyzeSentiment(content);
    return [{
      sourceUrl: url, sourceName: extractDomain(url),
      content: `[${pageTitle}] ${content.slice(0, 600)}`,
      snippet: content.slice(0, 300),
      keyword: matchedKw, sentiment, sentimentScore: score,
      reach: 0, source: 'WEB',
    }];
  } catch (err) {
    logger.warn(`Cheerio ${url}: ${err.message}`);
    return [];
  }
}

async function scrapeWithPlaywright(url, keywords) {
  let browser = null;
  try {
    const { chromium } = require('playwright');
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox','--disable-setuid-sandbox'] });
    const page = await (await browser.newContext({
      userAgent: HEADERS['User-Agent'], locale: 'es-AR',
    })).newPage();
    await page.route('**/*.{mp4,webm,ogg,mp3,woff,woff2}', r => r.abort());
    await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    await page.waitForTimeout(2000);

    const data = await page.evaluate(() => {
      ['nav','script','style','footer','header','aside'].forEach(t => document.querySelectorAll(t).forEach(e => e.remove()));
      const title = document.title || '';
      const blocks = [];
      const seen = new Set();
      ['article','.article-body','.entry-content','.post-content','.noticia-cuerpo','p','h2','h3'].forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
          const t = el.innerText?.trim().replace(/\s+/g,' ');
          if (t && t.length > 60 && !seen.has(t)) { seen.add(t); blocks.push(t); }
        });
      });
      return { title, blocks: blocks.slice(0, 30) };
    });

    await browser.close(); browser = null;

    const results = [];
    for (const kw of keywords) {
      const matched = data.blocks.filter(b => containsKeyword(b, kw));
      for (const block of matched.slice(0, 2)) {
        const { sentiment, score } = await analyzeSentiment(block);
        results.push({
          sourceUrl: url, sourceName: extractDomain(url),
          content: `[${data.title}] ${block.slice(0, 600)}`,
          snippet: block.slice(0, 300),
          keyword: kw, sentiment, sentimentScore: score,
          reach: 0, source: 'WEB',
        });
      }
    }
    logger.info(`Playwright web ${url}: ${results.length} menciones`);
    return results;
  } catch (err) {
    logger.warn(`Playwright web ${url}: ${err.message}`);
    return [];
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

// ─── RSS ─────────────────────────────────────────────────────────────────────
async function scrapeRss(url, keywords) {
  try {
    const Parser = require('rss-parser');
    const parser = new Parser({ timeout: 12000 });
    const feed = await parser.parseURL(url);
    const results = [];
    for (const item of feed.items.slice(0, 30)) {
      const text = (item.title || '') + ' ' + (item.contentSnippet || '');
      const matchedKw = keywords.find(kw => containsKeyword(text, kw));
      if (!matchedKw) continue;
      const { sentiment, score } = await analyzeSentiment(text);
      results.push({
        sourceUrl: item.link || url, sourceName: feed.title || extractDomain(url),
        author: item.creator || null,
        content: text.slice(0, 1000), snippet: text.slice(0, 300),
        keyword: matchedKw, sentiment, sentimentScore: score,
        reach: 0, source: 'WEB',
        publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
      });
    }
    return results;
  } catch (err) {
    logger.warn(`RSS ${url}: ${err.message}`);
    return [];
  }
}

// ─── Facebook página puntual ──────────────────────────────────────────────────
async function scrapeFacebookPage(url, keywords) {
  if (process.env.APIFY_API_KEY && process.env.APIFY_ENABLED !== 'false') {
    try {
      const res = await axios.post(
        `https://api.apify.com/v2/acts/apify~facebook-posts-scraper/run-sync-get-dataset-items`,
        { startUrls: [{ url }], maxPosts: 15, maxPostComments: 3, scrapeAbout: false },
        { headers: { 'Content-Type': 'application/json' }, params: { token: process.env.APIFY_API_KEY, memory: 256 }, timeout: 90000 }
      );
      const posts = Array.isArray(res.data) ? res.data : [];
      const results = [];
      for (const post of posts) {
        const text = post.text || post.message || '';
        const matchedKw = keywords.find(kw => containsKeyword(text, kw));
        if (!matchedKw) continue;
        const { sentiment, score } = await analyzeSentiment(text);
        results.push({
          sourceUrl: post.url || url, sourceName: post.pageName || extractDomain(url),
          author: post.user?.name || null,
          content: text.slice(0, 1000), snippet: text.slice(0, 300),
          keyword: matchedKw, sentiment, sentimentScore: score,
          reach: post.likes || 0, source: 'FACEBOOK',
          publishedAt: post.time ? new Date(post.time) : new Date(),
        });
      }
      return results;
    } catch (err) {
      if (err.response?.status === 403) process.env.APIFY_ENABLED = 'false';
    }
  }

  // Fallback Playwright
  const { scrapePageWithPlaywright } = require('./facebookScraper');
  return scrapePageWithPlaywright(url, keywords[0] || '', null, null, 'FACEBOOK')
    .then(r => r.map(m => ({ ...m, keyword: keywords[0] })));
}

// ─── Instagram perfil puntual ─────────────────────────────────────────────────
async function scrapeInstagramProfile(url, keywords) {
  if (process.env.APIFY_API_KEY && process.env.APIFY_ENABLED !== 'false') {
    try {
      const username = url.split('instagram.com/')[1]?.replace(/\/$/, '');
      const res = await axios.post(
        `https://api.apify.com/v2/acts/apify~instagram-scraper/run-sync-get-dataset-items`,
        { directUrls: [url], resultsType: 'posts', resultsLimit: 15 },
        { headers: { 'Content-Type': 'application/json' }, params: { token: process.env.APIFY_API_KEY, memory: 256 }, timeout: 90000 }
      );
      const posts = Array.isArray(res.data) ? res.data : [];
      const results = [];
      for (const post of posts) {
        const caption = post.caption || post.alt || '';
        const matchedKw = keywords.find(kw => containsKeyword(caption, kw));
        if (!matchedKw) continue;
        const { sentiment, score } = await analyzeSentiment(caption);
        results.push({
          sourceUrl: post.url || url,
          sourceName: `@${username || 'instagram'}`,
          author: post.ownerUsername ? `@${post.ownerUsername}` : null,
          content: caption.slice(0, 1000), snippet: caption.slice(0, 300),
          keyword: matchedKw, sentiment, sentimentScore: score,
          reach: post.likesCount || 0, source: 'INSTAGRAM',
          publishedAt: post.timestamp ? new Date(post.timestamp) : new Date(),
        });
      }
      return results;
    } catch (err) {
      if (err.response?.status === 403) process.env.APIFY_ENABLED = 'false';
    }
  }
  return [];
}

// ─── Scrape todas las fuentes personalizadas de una campaña ───────────────────
async function scrapeCustomSources(campaignId) {
  const { prisma } = require('../lib/db');
  const sources = await prisma.customSource.findMany({
    where: { campaignId, isActive: true },
    include: { campaign: { include: { keywords: { where: { isActive: true } } } } },
  });

  if (!sources.length) return { saved: 0, mentions: [] };
  const keywords = sources[0]?.campaign?.keywords?.map(k => k.term) || [];
  if (!keywords.length) return { saved: 0, mentions: [] };

  const allMentions = [];

  for (const src of sources) {
    try {
      const results = await scrapeCustomUrl(src.url, keywords, src.type);

      for (const r of results) {
        const kwRecord = src.campaign.keywords.find(k =>
          normalize(k.term).includes(normalize(r.keyword || '').split(' ')[0])
        );
        allMentions.push({
          campaignId,
          keywordId: kwRecord?.id || null,
          source: r.source,
          sourceUrl: r.sourceUrl,
          sourceName: r.sourceName,
          author: r.author || null,
          content: r.content,
          snippet: r.snippet,
          sentiment: r.sentiment,
          sentimentScore: r.sentimentScore,
          reach: r.reach || 0,
          publishedAt: r.publishedAt || new Date(),
        });
      }

      await prisma.customSource.update({
        where: { id: src.id },
        data: { lastScraped: new Date() },
      });

      logger.info(`Custom ${src.type} ${extractDomain(src.url)}: ${results.length} menciones`);
      await new Promise(r => setTimeout(r, 1000));
    } catch (err) {
      logger.error(`Custom source ${src.url}: ${err.message}`);
    }
  }

  return { saved: allMentions.length, mentions: allMentions };
}

function extractDomain(url) {
  try { return new URL(url).hostname.replace('www.', ''); } catch { return url; }
}

module.exports = { scrapeCustomUrl, scrapeCustomSources };

// src/services/scraperService.js
// Motor principal de scraping — busca por keyword EN la zona seleccionada
const Parser = require('rss-parser');
const axios  = require('axios');
const logger = require('../lib/logger');
const { analyzeSentiment } = require('./sentimentService');
const { prisma } = require('../lib/db');

const rssParser = new Parser({
  timeout: 12000,
  headers: { 'User-Agent': 'Mozilla/5.0 (compatible; PoliticaMonitor/1.0)' },
});

// ─── Límite de edad ──────────────────────────────────────────────────────────
const MAX_AGE_HOURS = parseInt(process.env.MAX_CONTENT_AGE_HOURS || '72');

function isTooOld(dateStr) {
  if (!dateStr) return true;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return true;
  return (Date.now() - d.getTime()) / 3600000 > MAX_AGE_HOURS;
}

// ─── Normalización ───────────────────────────────────────────────────────────
function normalize(text) {
  if (!text) return '';
  return text.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function containsKeyword(text, kw) {
  return normalize(text).includes(normalize(kw).split(' ')[0]);
}

// ─── Google News RSS ─────────────────────────────────────────────────────────
// Busca cualquier query y retorna menciones frescas
async function scrapeGoogleNews(query, campaignId, keywordId, useTimeFilter = true) {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=es-419&gl=AR&ceid=AR:es-419${useTimeFilter ? '&tbs=qdr:d3' : ''}`;
  try {
    const feed = await rssParser.parseURL(url);
    const results = [];
    for (const item of feed.items.slice(0, 20)) {
      if (isTooOld(item.pubDate)) continue;
      const content = (item.title || '') + '. ' + (item.contentSnippet || '');
      const { sentiment, score } = await analyzeSentiment(content);
      results.push({
        campaignId, keywordId,
        source: 'NEWS',
        sourceUrl: item.link || '',
        sourceName: item.creator || feed.title || 'Google News',
        content: content.slice(0, 1000),
        snippet: (item.contentSnippet || '').slice(0, 300),
        sentiment, sentimentScore: score,
        reach: 0,
        publishedAt: new Date(item.pubDate),
      });
    }
    return results;
  } catch (err) {
    logger.warn(`Google News "${query}": ${err.message}`);
    return [];
  }
}

// ─── NewsAPI ─────────────────────────────────────────────────────────────────
async function scrapeNewsAPI(keyword, geo, campaignId, keywordId) {
  if (!process.env.NEWS_API_KEY) return [];
  const { provincia, ciudad } = geo;
  const geoDomains = getGeoNewsSites(provincia, ciudad);
  try {
    const params = {
      q: keyword, language: 'es', sortBy: 'publishedAt', pageSize: 20,
      from: new Date(Date.now() - MAX_AGE_HOURS * 3600000).toISOString().split('T')[0],
      apiKey: process.env.NEWS_API_KEY,
      ...(geoDomains.length > 0 && { domains: geoDomains.slice(0, 5).join(',') }),
    };
    const res = await axios.get('https://newsapi.org/v2/everything', { params, timeout: 10000 });
    const results = [];
    for (const a of (res.data.articles || [])) {
      const content = (a.title || '') + '. ' + (a.description || '');
      if (!containsKeyword(content, keyword)) continue;
      const { sentiment, score } = await analyzeSentiment(content);
      results.push({
        campaignId, keywordId, source: 'NEWS',
        sourceUrl: a.url, sourceName: a.source?.name || 'NewsAPI',
        author: a.author,
        content: content.slice(0, 1000),
        snippet: (a.description || '').slice(0, 300),
        sentiment, sentimentScore: score, reach: 0,
        publishedAt: a.publishedAt ? new Date(a.publishedAt) : new Date(),
      });
    }
    return results;
  } catch (err) {
    logger.warn(`NewsAPI: ${err.message}`);
    return [];
  }
}

// ─── Búsqueda ABIERTA por zona ────────────────────────────────────────────────
// La zona = DÓNDE buscar. Keyword = QUÉ buscar.
// Encuentra cualquier web, FB, IG, Twitter de la zona que mencione la keyword
async function scrapeOpenSearch(keyword, geo, campaignId, keywordId) {
  const { provincia, ciudad } = geo;
  const zona = ciudad || provincia || '';
  const results = [];

  if (!zona) {
    // Sin zona → búsqueda nacional en medios
    const r = await scrapeGoogleNews(`"${keyword}"`, campaignId, keywordId);
    logger.info(`  Búsqueda nacional "${keyword}": ${r.length}`);
    return r;
  }

  logger.info(`  Búsqueda abierta: "${keyword}" en "${zona}"`);

  // 1. Keyword en cualquier web de la provincia
  const r1 = await scrapeGoogleNews(`"${keyword}" "${provincia}"`, campaignId, keywordId);
  results.push(...r1);

  // 2. Keyword + ciudad (si aplica)
  if (ciudad) {
    const r2 = await scrapeGoogleNews(`"${keyword}" "${ciudad}"`, campaignId, keywordId);
    results.push(...r2);
  }

  // 3. Aliases geográficos de la zona
  for (const alias of getZonaAliases(provincia, ciudad)) {
    const r = await scrapeGoogleNews(`"${keyword}" "${alias}"`, campaignId, keywordId);
    results.push(...r);
  }

  // 4. Sitios de noticias locales conocidos (keyword pura, sin zona)
  const geoSites = getGeoNewsSites(provincia, ciudad);
  if (geoSites.length > 0) {
    for (let i = 0; i < geoSites.length; i += 5) {
      const chunk = geoSites.slice(i, i + 5);
      const siteFilter = chunk.map(s => `site:${s}`).join(' OR ');
      const r = await scrapeGoogleNews(`"${keyword}" (${siteFilter})`, campaignId, keywordId, false);
      r.forEach(m => { m.source = 'NEWS'; m.sourceName = m.sourceName || chunk[0]; });
      results.push(...r);
    }
  }

  // 5. Facebook público de la zona
  const r5 = await scrapeGoogleNews(`"${keyword}" "${provincia}" site:facebook.com`, campaignId, keywordId);
  r5.forEach(m => { m.source = 'FACEBOOK'; m.sourceName = 'Facebook'; });
  results.push(...r5);

  if (ciudad) {
    const r5b = await scrapeGoogleNews(`"${keyword}" "${ciudad}" site:facebook.com`, campaignId, keywordId);
    r5b.forEach(m => { m.source = 'FACEBOOK'; m.sourceName = 'Facebook'; });
    results.push(...r5b);
  }

  // 6. Instagram público de la zona
  const r6 = await scrapeGoogleNews(`"${keyword}" "${provincia}" site:instagram.com`, campaignId, keywordId);
  r6.forEach(m => { m.source = 'INSTAGRAM'; m.sourceName = 'Instagram'; });
  results.push(...r6);

  // 7. Twitter/X de la zona
  const r7 = await scrapeGoogleNews(`"${keyword}" "${provincia}" (site:twitter.com OR site:x.com)`, campaignId, keywordId);
  r7.forEach(m => { m.source = 'TWITTER'; m.sourceName = 'Twitter/X'; });
  results.push(...r7);

  logger.info(`  Total búsqueda abierta "${keyword}": ${results.length}`);
  return results;
}

// ─── Facebook/Instagram via Apify o Playwright ────────────────────────────────
async function scrapeSocial(keyword, geo, campaignId, keywordId) {
  const { searchFacebookGeneral, searchInstagramGeneral } = require('./facebookScraper');
  const [fb, ig] = await Promise.allSettled([
    searchFacebookGeneral(keyword, geo, campaignId, keywordId),
    searchInstagramGeneral(keyword, geo, campaignId, keywordId),
  ]);
  return [
    ...(fb.status === 'fulfilled' ? fb.value : []),
    ...(ig.status === 'fulfilled' ? ig.value : []),
  ];
}

// ─── Páginas personalizadas de la campaña ─────────────────────────────────────
async function scrapeCustomPages(keyword, campaignId, keywordId) {
  try {
    const { scrapeCustomSources } = require('./customScraper');
    const result = await scrapeCustomSources(campaignId);
    return result.mentions || [];
  } catch (err) {
    logger.warn(`Custom pages error: ${err.message}`);
    return [];
  }
}

// ─── ORQUESTADOR PRINCIPAL ────────────────────────────────────────────────────
async function scrapeAllSources(campaignId) {
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    include: { keywords: { where: { isActive: true } } },
  });

  if (!campaign || !campaign.keywords.length) {
    logger.info(`Campaign ${campaignId}: sin keywords activas`);
    return { saved: 0 };
  }

  // Leer zona geográfica
  let geo = { provincia: '', ciudad: '' };
  try {
    if (campaign.description?.startsWith('{')) {
      const parsed = JSON.parse(campaign.description);
      geo = { provincia: parsed.provincia || '', ciudad: parsed.ciudad || '' };
    }
  } catch {}

  const zonaLabel = [geo.ciudad, geo.provincia].filter(Boolean).join(', ') || 'nacional';
  logger.info(`━━━ Campaign "${campaign.name}" | zona: "${zonaLabel}" | ${campaign.keywords.length} keyword(s) ━━━`);

  const allResults = [];

  // Procesar cada keyword en paralelo
  const jobs = campaign.keywords.map(async (kw) => {
    logger.info(`▶ "${kw.term}"`);
    try {
      const [openSearch, newsApi, social] = await Promise.allSettled([
        scrapeOpenSearch(kw.term, geo, campaignId, kw.id),
        scrapeNewsAPI(kw.term, geo, campaignId, kw.id),
        scrapeSocial(kw.term, geo, campaignId, kw.id),
      ]);
      const batch = [
        ...(openSearch.status === 'fulfilled' ? openSearch.value : []),
        ...(newsApi.status   === 'fulfilled' ? newsApi.value   : []),
        ...(social.status    === 'fulfilled' ? social.value    : []),
      ];
      logger.info(`✔ "${kw.term}": ${batch.length} menciones`);
      return batch;
    } catch (err) {
      logger.error(`✘ "${kw.term}": ${err.message}`);
      return [];
    }
  });

  const results = await Promise.allSettled(jobs);
  results.forEach(r => { if (r.status === 'fulfilled') allResults.push(...r.value); });

  // También scrapear páginas personalizadas de la campaña (una sola vez, no por keyword)
  try {
    const { scrapeCustomSources } = require('./customScraper');
    const customResult = await scrapeCustomSources(campaignId);
    if (customResult.mentions?.length > 0) {
      logger.info(`Páginas personalizadas: ${customResult.mentions.length} menciones`);
      allResults.push(...customResult.mentions);
    }
  } catch (err) {
    logger.warn(`Custom sources error: ${err.message}`);
  }

  // Deduplicar por URL o contenido
  const seen = new Set();
  const toSave = allResults.filter(m => {
    const key = (m.sourceUrl || '') + m.content.slice(0, 80);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  if (toSave.length > 0) {
    await prisma.mention.createMany({ data: toSave, skipDuplicates: true });
    logger.info(`Campaign "${campaign.name}": ${toSave.length} nuevas menciones guardadas`);
  } else {
    logger.info(`Campaign "${campaign.name}": sin menciones nuevas`);
  }

  return { saved: toSave.length, mentions: toSave };
}

// ─── MAPAS GEOGRÁFICOS ────────────────────────────────────────────────────────

function getGeoNewsSites(provincia, ciudad) {
  const p = normalize(provincia || '');
  const map = {
    'tierra del fuego': ['minutofueguino.com.ar','airelibre.com.ar','fmfuego.com.ar','19640noticias.com','elcorritivofueguino.com.ar','diarioushuaia.com.ar'],
    'cordoba':          ['lavozdelinterior.com','lacivicacba.com','eldoce.tv','cba24n.com.ar'],
    'rosario':          ['lacapital.com.ar','rosario3.com','ellitoral.com'],
    'santa fe':         ['ellitoral.com','unosantafe.com.ar'],
    'mendoza':          ['losandes.com.ar','mdzol.com','mendozapost.com'],
    'tucuman':          ['lagaceta.com.ar','eltucumano.com'],
    'salta':            ['eltribuno.com','saltainforma.com.ar'],
    'jujuy':            ['eltribuno.com','jujuyalfilo.com'],
    'neuquen':          ['lmneuquen.com','rionegro.com.ar'],
    'rio negro':        ['rionegro.com.ar','adnrionegro.com.ar'],
    'chaco':            ['chacodiapordia.com.ar','diariochaco.com'],
    'corrientes':       ['corrienteshoy.com'],
    'misiones':         ['misionesonline.net','primera-edicion.com.ar'],
    'entre rios':       ['unoentrerios.com.ar','eldiariodeparana.com.ar'],
    'santiago del estero': ['elliberal.com.ar'],
    'san juan':         ['diariodecuyo.com.ar'],
    'chubut':           ['elpatagonico.com','jornada.com.ar'],
    'santa cruz':       ['elcomentario.com.ar'],
    'buenos aires':     ['infobae.com','lanacion.com.ar','clarin.com'],
  };
  for (const [k, v] of Object.entries(map)) {
    if (p.includes(k)) return v;
  }
  return [];
}

function getGeoFacebookPages(provincia, ciudad) {
  const p = normalize(provincia || '');
  const map = {
    'tierra del fuego': ['https://www.facebook.com/minutofueguino','https://www.facebook.com/airelibrefm','https://www.facebook.com/19640noticias','https://www.facebook.com/noventauno','https://www.facebook.com/OceaniaFueguina'],
    'cordoba':          ['https://www.facebook.com/lavozdelinterior','https://www.facebook.com/lacivicacba','https://www.facebook.com/cba24n'],
    'mendoza':          ['https://www.facebook.com/losandes.mendoza','https://www.facebook.com/mdzol'],
    'tucuman':          ['https://www.facebook.com/lagaceta'],
    'salta':            ['https://www.facebook.com/ElTribuno'],
    'neuquen':          ['https://www.facebook.com/LMNeuquen'],
    'misiones':         ['https://www.facebook.com/primera.edicion.misiones'],
    'entre rios':       ['https://www.facebook.com/unoentrerios'],
    'buenos aires':     ['https://www.facebook.com/infobae','https://www.facebook.com/lanacion'],
  };
  for (const [k, v] of Object.entries(map)) {
    if (p.includes(k)) return v;
  }
  return [];
}

function getZonaAliases(provincia, ciudad) {
  const p = normalize(provincia || '');
  const map = {
    'tierra del fuego': ['Río Grande','Ushuaia','Tolhuin'],
    'cordoba':          ['Córdoba Capital','Villa Carlos Paz'],
    'buenos aires':     ['La Plata','Gran Buenos Aires'],
    'santa fe':         ['Rosario','Santa Fe Capital'],
    'mendoza':          ['Mendoza Capital','Godoy Cruz'],
    'tucuman':          ['San Miguel de Tucumán'],
    'neuquen':          ['Neuquén Capital','Cipolletti'],
    'rio negro':        ['Viedma','Bariloche'],
    'chubut':           ['Comodoro Rivadavia','Trelew'],
    'santa cruz':       ['Río Gallegos'],
    'misiones':         ['Posadas'],
    'entre rios':       ['Paraná','Concordia'],
  };
  for (const [k, v] of Object.entries(map)) {
    if (p.includes(k)) return v.slice(0, 2);
  }
  return [];
}

module.exports = {
  scrapeAllSources,
  scrapeGoogleNews,
  getGeoNewsSites,
  getGeoFacebookPages,
  getZonaAliases,
  normalize,
  containsKeyword,
  isTooOld,
};

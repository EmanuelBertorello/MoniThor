// src/routes/analytics.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

router.get('/summary', async (req, res) => {
  try {
    const { campaignId, period = '24h' } = req.query;
    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const hours = { '1h':1, '24h':24, '7d':168, '30d':720 }[period] || 24;
    const since = new Date(Date.now() - hours * 3600000);
    const prevSince = new Date(since.getTime() - (Date.now() - since.getTime()));

    const [total, previous, bySource, bySentiment, byKeyword, topMentions] = await Promise.all([
      prisma.mention.count({ where: { campaignId, publishedAt: { gte: since } } }),
      prisma.mention.count({ where: { campaignId, publishedAt: { gte: prevSince, lt: since } } }),
      prisma.mention.groupBy({ by: ['source'], where: { campaignId, publishedAt: { gte: since } }, _count: true, _sum: { reach: true } }),
      prisma.mention.groupBy({ by: ['sentiment'], where: { campaignId, publishedAt: { gte: since } }, _count: true }),
      prisma.mention.groupBy({ by: ['keywordId'], where: { campaignId, publishedAt: { gte: since }, keywordId: { not: null } }, _count: true, orderBy: { _count: { keywordId: 'desc' } }, take: 5 }),
      prisma.mention.findMany({ where: { campaignId, publishedAt: { gte: since } }, orderBy: { reach: 'desc' }, take: 5, include: { keyword: { select: { term: true } } } }),
    ]);

    res.json({
      period,
      mentions: { total, delta: previous > 0 ? Math.round(((total - previous) / previous) * 100) : 0 },
      reach: bySource.reduce((a, b) => a + (b._sum?.reach || 0), 0),
      bySource: bySource.map(s => ({ source: s.source, count: s._count, reach: s._sum?.reach || 0 })),
      bySentiment: bySentiment.map(s => ({ sentiment: s.sentiment, count: s._count })),
      byKeyword,
      topMentions,
    });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener analytics' });
  }
});

router.get('/timeseries', async (req, res) => {
  try {
    const { campaignId, period = '24h', interval = 'hour' } = req.query;
    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const hours = { '1h':1, '24h':24, '7d':168, '30d':720 }[period] || 24;
    const since = new Date(Date.now() - hours * 3600000);

    // Agrupar en JavaScript (evita $queryRaw problemático)
    const mentions = await prisma.mention.findMany({
      where: { campaignId, publishedAt: { gte: since } },
      select: { publishedAt: true, sentiment: true },
      orderBy: { publishedAt: 'asc' },
    });

    const buckets = {};
    for (const m of mentions) {
      const d = new Date(m.publishedAt);
      interval === 'day' ? d.setHours(0, 0, 0, 0) : d.setMinutes(0, 0, 0);
      const key = d.toISOString();
      if (!buckets[key]) buckets[key] = { time: key, total: 0, positive: 0, negative: 0, neutral: 0 };
      buckets[key].total++;
      if (m.sentiment === 'POSITIVE') buckets[key].positive++;
      else if (m.sentiment === 'NEGATIVE') buckets[key].negative++;
      else buckets[key].neutral++;
    }

    res.json({ series: Object.values(buckets).sort((a, b) => new Date(a.time) - new Date(b.time)) });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener serie de tiempo', series: [] });
  }
});

module.exports = router;

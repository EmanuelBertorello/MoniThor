// src/routes/users.js
const express = require('express');
const bcrypt = require('bcryptjs');
const { prisma } = require('../lib/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ─── GET /api/users — listar usuarios (solo ADMIN) ───────────────────────────
router.get('/', authorize('ADMIN'), async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true, email: true, name: true, role: true,
        plan: true, isActive: true, createdAt: true,
        demoExpiresAt: true,
        _count: { select: { campaigns: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener usuarios' });
  }
});

// ─── POST /api/users — crear usuario (solo ADMIN) ────────────────────────────
router.post('/', authorize('ADMIN'), async (req, res) => {
  try {
    const { email, name, role = 'VIEWER', plan = 'BASICO', isDemo = false } = req.body;
    if (!email || !name) return res.status(400).json({ error: 'Email y nombre requeridos' });

    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return res.status(400).json({ error: 'El email ya está registrado' });

    // Generar contraseña temporal
    const tempPassword = generateTempPassword();
    const hash = await bcrypt.hash(tempPassword, 12);

    // Si es demo, expira en 30 minutos
    const demoExpiresAt = isDemo ? new Date(Date.now() + 30 * 60 * 1000) : null;

    const user = await prisma.user.create({
      data: {
        email,
        name,
        password: hash,
        role,
        plan,
        isActive: true,
        demoExpiresAt,
      },
      select: {
        id: true, email: true, name: true, role: true,
        plan: true, isActive: true, createdAt: true, demoExpiresAt: true,
      },
    });

    res.status(201).json({ user, tempPassword });
  } catch (err) {
    res.status(500).json({ error: 'Error al crear usuario' });
  }
});

// ─── PUT /api/users/:id — editar usuario (solo ADMIN) ───────────────────────
router.put('/:id', authorize('ADMIN'), async (req, res) => {
  try {
    const { name, role, plan, isActive, resetPassword, extendDemo } = req.body;

    const updates = {};
    if (name)               updates.name = name;
    if (role)               updates.role = role;
    if (plan)               updates.plan = plan;
    if (isActive !== undefined) updates.isActive = isActive;

    // Extender demo 30 minutos más
    if (extendDemo) {
      updates.demoExpiresAt = new Date(Date.now() + 30 * 60 * 1000);
    }

    // Resetear contraseña
    let newPassword = null;
    if (resetPassword) {
      newPassword = generateTempPassword();
      updates.password = await bcrypt.hash(newPassword, 12);
    }

    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: updates,
      select: {
        id: true, email: true, name: true, role: true,
        plan: true, isActive: true, demoExpiresAt: true,
      },
    });

    res.json({ user, ...(newPassword && { newPassword }) });
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar usuario' });
  }
});

// ─── DELETE /api/users/:id — eliminar usuario (solo ADMIN) ──────────────────
router.delete('/:id', authorize('ADMIN'), async (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: 'No podés eliminarte a vos mismo' });
    }
    await prisma.user.delete({ where: { id: req.params.id } });
    res.json({ message: 'Usuario eliminado' });
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar usuario' });
  }
});

// ─── POST /api/users/demo — crear usuario demo rápido ───────────────────────
router.post('/demo', authorize('ADMIN'), async (req, res) => {
  try {
    const { name, email } = req.body;
    if (!name || !email) return res.status(400).json({ error: 'Nombre y email requeridos' });

    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return res.status(400).json({ error: 'Email ya registrado' });

    const tempPassword = generateTempPassword();
    const hash = await bcrypt.hash(tempPassword, 12);
    const demoExpiresAt = new Date(Date.now() + 30 * 60 * 1000);

    const user = await prisma.user.create({
      data: {
        email, name,
        password: hash,
        role: 'VIEWER',
        plan: 'BASICO',
        isActive: true,
        demoExpiresAt,
      },
      select: {
        id: true, email: true, name: true, role: true,
        demoExpiresAt: true,
      },
    });

    res.status(201).json({ user, tempPassword, expiresIn: '30 minutos' });
  } catch (err) {
    res.status(500).json({ error: 'Error al crear usuario demo' });
  }
});

// ─── GET /api/users/cleanup-demos — limpiar demos expirados ─────────────────
router.delete('/cleanup-demos', authorize('ADMIN'), async (req, res) => {
  try {
    const { count } = await prisma.user.deleteMany({
      where: {
        demoExpiresAt: { lt: new Date() },
        role: 'VIEWER',
      },
    });
    res.json({ message: `${count} usuarios demo expirados eliminados` });
  } catch (err) {
    res.status(500).json({ error: 'Error al limpiar demos' });
  }
});

function generateTempPassword() {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  return Array.from({ length: 10 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

module.exports = router;

// src/routes/alerts.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/alerts?campaignId=
router.get('/', async (req, res) => {
  try {
    const { campaignId } = req.query;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const rules = await prisma.alertRule.findMany({
      where: { campaignId },
      include: { alerts: { take: 5, orderBy: { sentAt: 'desc' } } },
    });

    const recentAlerts = await prisma.alert.findMany({
      where: { userId: req.user.id, isRead: false },
      include: { rule: { include: { campaign: true } } },
      orderBy: { sentAt: 'desc' },
      take: 20,
    });

    res.json({ rules, recentAlerts });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener alertas' });
  }
});

// POST /api/alerts/rules
router.post('/rules', async (req, res) => {
  try {
    const { campaignId, name, condition, channels, recipients } = req.body;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const rule = await prisma.alertRule.create({
      data: {
        campaignId,
        name,
        condition: JSON.stringify(condition),
        channels: channels || ['email'],
        recipients: recipients || [req.user.email],
      },
    });

    res.status(201).json({ rule });
  } catch (err) {
    res.status(500).json({ error: 'Error al crear regla de alerta' });
  }
});

// PUT /api/alerts/rules/:id/toggle
router.put('/rules/:id/toggle', async (req, res) => {
  try {
    const rule = await prisma.alertRule.findUnique({
      where: { id: req.params.id },
      include: { campaign: true },
    });

    if (!rule || rule.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Regla no encontrada' });
    }

    const updated = await prisma.alertRule.update({
      where: { id: req.params.id },
      data: { isActive: !rule.isActive },
    });

    res.json({ rule: updated });
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar regla' });
  }
});

// PUT /api/alerts/:id/read
router.put('/:id/read', async (req, res) => {
  try {
    await prisma.alert.updateMany({
      where: { id: req.params.id, userId: req.user.id },
      data: { isRead: true },
    });
    res.json({ message: 'Alerta marcada como leída' });
  } catch (err) {
    res.status(500).json({ error: 'Error al marcar alerta' });
  }
});

module.exports = router;

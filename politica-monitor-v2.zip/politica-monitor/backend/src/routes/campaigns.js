// src/routes/campaigns.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

// Protege rutas de escritura — VIEWER solo puede leer
function canWrite(req, res, next) {
  if (req.user && req.user.role === 'VIEWER') {
    return res.status(403).json({ error: 'Tu rol de Monitor solo permite ver datos.' });
  }
  next();
}

const router = express.Router();
router.use(authenticate);

// GET /api/campaigns
router.get('/', async (req, res) => {
  try {
    const campaigns = await prisma.campaign.findMany({
      where: { userId: req.user.id },
      include: {
        keywords: { where: { isActive: true } },
        _count: { select: { mentions: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ campaigns });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener campañas' });
  }
});

// POST /api/campaigns
router.post('/', canWrite, async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ error: 'El nombre es requerido' });

    const campaign = await prisma.campaign.create({
      data: { name, description, userId: req.user.id },
    });

    // Create default sources
    const defaultSources = [
      { type: 'WEB', name: 'Sitios Web' },
      { type: 'NEWS', name: 'Google News' },
      { type: 'FACEBOOK', name: 'Facebook Público' },
      { type: 'INSTAGRAM', name: 'Instagram' },
      { type: 'TWITTER', name: 'Twitter/X' },
    ];

    await prisma.source.createMany({
      data: defaultSources.map(s => ({ ...s, campaignId: campaign.id })),
    });

    res.status(201).json({ campaign });
  } catch (err) {
    res.status(500).json({ error: 'Error al crear campaña' });
  }
});

// GET /api/campaigns/:id
router.get('/:id', async (req, res) => {
  try {
    const campaign = await prisma.campaign.findFirst({
      where: { id: req.params.id, userId: req.user.id },
      include: {
        keywords: { where: { isActive: true } },
        sources: true,
        alertRules: true,
        _count: { select: { mentions: true } },
      },
    });

    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });
    res.json({ campaign });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener campaña' });
  }
});

// PUT /api/campaigns/:id
router.put('/:id', canWrite, async (req, res) => {
  try {
    const { name, description, isActive, provincia, ciudad } = req.body;
    const campaign = await prisma.campaign.findFirst({
      where: { id: req.params.id, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    // Si viene geo, lo guardamos como JSON en description
    let descValue = description;
    if (provincia !== undefined || ciudad !== undefined) {
      descValue = JSON.stringify({
        provincia: provincia || '',
        ciudad: ciudad || '',
        text: description || '',
      });
    }

    const updated = await prisma.campaign.update({
      where: { id: req.params.id },
      data: {
        ...(name && { name }),
        ...(descValue !== undefined && { description: descValue }),
        ...(isActive !== undefined && { isActive }),
      },
    });
    res.json({ campaign: updated });
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar campaña' });
  }
});

// DELETE /api/campaigns/:id
router.delete('/:id', canWrite, async (req, res) => {
  try {
    const campaign = await prisma.campaign.findFirst({
      where: { id: req.params.id, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const id = req.params.id;

    // Eliminar en orden correcto para respetar las foreign keys
    await prisma.alert.deleteMany({
      where: { rule: { campaignId: id } },
    });
    await prisma.alertRule.deleteMany({ where: { campaignId: id } });
    await prisma.mention.deleteMany({ where: { campaignId: id } });
    await prisma.keyword.deleteMany({ where: { campaignId: id } });
    await prisma.source.deleteMany({ where: { campaignId: id } });
    await prisma.report.deleteMany({ where: { campaignId: id } });

    // Eliminar customSources si existe el modelo
    try {
      await prisma.customSource.deleteMany({ where: { campaignId: id } });
    } catch {}

    await prisma.campaign.delete({ where: { id } });

    res.json({ message: 'Campaña eliminada correctamente' });
  } catch (err) {
    console.error('Error eliminando campaña:', err);
    res.status(500).json({ error: 'Error al eliminar campaña: ' + err.message });
  }
});

module.exports = router;

// src/routes/reports.js
const express = require('express');
const { prisma } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// ─── Helper: build period filter ─────────────────────────────────────────────
function getPeriodSince(period) {
  const map = { '1h':1, '24h':24, '7d':168, '30d':720, '90d':2160 };
  const hours = map[period] || 24;
  return new Date(Date.now() - hours * 60 * 60 * 1000);
}

// ─── POST /api/reports/generate ──────────────────────────────────────────────
router.post('/generate', async (req, res) => {
  try {
    const {
      campaignId, period = '24h', type = 'FULL',
      source, sentiment, keyword: kwFilter,
    } = req.body;

    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const since = getPeriodSince(period);
    const prevSince = new Date(since.getTime() - (Date.now() - since.getTime()));

    const baseWhere = {
      campaignId,
      publishedAt: { gte: since },
      ...(source && source !== 'ALL' && { source }),
      ...(sentiment && sentiment !== 'ALL' && { sentiment }),
    };

    // ── Fetch everything in parallel ─────────────────────────────────────────
    const [
      total, prevTotal,
      bySentiment, bySource,
      allMentions, topMentions, negativeMentions,
      keywords, hourlyVolume,
    ] = await Promise.all([
      // Total current period
      prisma.mention.count({ where: baseWhere }),
      // Total previous period (for delta)
      prisma.mention.count({ where: { ...baseWhere, publishedAt: { gte: prevSince, lt: since } } }),
      // By sentiment
      prisma.mention.groupBy({ by:['sentiment'], where: baseWhere, _count:true, _sum:{ reach:true } }),
      // By source
      prisma.mention.groupBy({ by:['source'], where: baseWhere, _count:true, _sum:{ reach:true, engagement:true } }),
      // ALL mentions for CSV export (up to 1000)
      prisma.mention.findMany({
        where: baseWhere,
        orderBy: { publishedAt: 'desc' },
        take: 1000,
        include: { keyword: { select: { term: true, color: true } } },
      }),
      // Top by reach
      prisma.mention.findMany({
        where: baseWhere,
        orderBy: { reach: 'desc' },
        take: 20,
        include: { keyword: { select: { term: true } } },
      }),
      // Most negative
      prisma.mention.findMany({
        where: { ...baseWhere, sentiment: 'NEGATIVE' },
        orderBy: { publishedAt: 'desc' },
        take: 20,
        include: { keyword: { select: { term: true } } },
      }),
      // Keywords with counts
      prisma.keyword.findMany({
        where: { campaignId, isActive: true },
        include: { _count: { select: { mentions: true } } },
        orderBy: { createdAt: 'asc' },
      }),
      // Hourly volume - fetch mentions and group in JS
      prisma.mention.findMany({
        where: { campaignId, publishedAt: { gte: since } },
        select: { publishedAt: true, sentiment: true },
        orderBy: { publishedAt: 'asc' },
      }),
    ]);

    // ── Build sentiment percentages ───────────────────────────────────────────
    const sentMap = {};
    bySentiment.forEach(s => { sentMap[s.sentiment] = { count: s._count, reach: s._sum?.reach || 0 }; });
    const pos = sentMap.POSITIVE?.count || 0;
    const neg = sentMap.NEGATIVE?.count || 0;
    const neu = sentMap.NEUTRAL?.count || 0;
    const totalForPct = pos + neg + neu || 1;

    // ── Build source breakdown ────────────────────────────────────────────────
    const sourceBreakdown = bySource.map(s => ({
      source: s.source,
      count: s._count,
      reach: s._sum?.reach || 0,
      engagement: s._sum?.engagement || 0,
      pct: Math.round((s._count / (total || 1)) * 100),
    })).sort((a, b) => b.count - a.count);

    // ── Delta vs previous period ──────────────────────────────────────────────
    const delta = prevTotal > 0 ? Math.round(((total - prevTotal) / prevTotal) * 100) : 0;

    // ── Most used words in negative mentions ─────────────────────────────────
    const negWords = {};
    negativeMentions.forEach(m => {
      m.content.toLowerCase().split(/\s+/).forEach(w => {
        if (w.length > 4) negWords[w] = (negWords[w] || 0) + 1;
      });
    });
    const topNegWords = Object.entries(negWords)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15)
      .map(([word, count]) => ({ word, count }));

    // ── Group hourlyVolume by hour in JS ─────────────────────────────────────
    const hourBuckets = {};
    (hourlyVolume || []).forEach(m => {
      const d = new Date(m.publishedAt);
      d.setMinutes(0, 0, 0);
      const key = d.toISOString();
      if (!hourBuckets[key]) hourBuckets[key] = { hour: key, total:0, positive:0, negative:0, neutral:0 };
      hourBuckets[key].total++;
      if (m.sentiment === 'POSITIVE') hourBuckets[key].positive++;
      else if (m.sentiment === 'NEGATIVE') hourBuckets[key].negative++;
      else hourBuckets[key].neutral++;
    });
    const hourlyData = Object.values(hourBuckets).sort((a,b) => new Date(a.hour) - new Date(b.hour));

    // ── Final report object ───────────────────────────────────────────────────
    const reportData = {
      meta: {
        campaign: campaign.name,
        campaignId,
        period,
        generatedAt: new Date().toISOString(),
        filters: { source: source || 'ALL', sentiment: sentiment || 'ALL' },
        analyst: req.user.name,
      },
      summary: {
        total,
        prevTotal,
        delta,
        totalReach: sourceBreakdown.reduce((a, b) => a + b.reach, 0),
        totalEngagement: sourceBreakdown.reduce((a, b) => a + b.engagement, 0),
      },
      sentiment: {
        positive: { count: pos, pct: Math.round((pos / totalForPct) * 100), reach: sentMap.POSITIVE?.reach || 0 },
        negative: { count: neg, pct: Math.round((neg / totalForPct) * 100), reach: sentMap.NEGATIVE?.reach || 0 },
        neutral:  { count: neu, pct: Math.round((neu / totalForPct) * 100), reach: sentMap.NEUTRAL?.reach  || 0 },
      },
      bySource: sourceBreakdown,
      keywords: keywords.map(k => ({
        term: k.term,
        color: k.color,
        mentions: k._count.mentions,
        pct: Math.round((k._count.mentions / (total || 1)) * 100),
      })),
      topMentions,
      negativeMentions,
      allMentions,
      hourlyVolume: hourlyData,
      topNegWords,
    };

    // Save to DB
    const report = await prisma.report.create({
      data: { campaignId, type, period, data: reportData },
    });

    res.json({ report, data: reportData });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al generar reporte: ' + err.message });
  }
});

// ─── GET /api/reports?campaignId= ────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { campaignId } = req.query;
    const campaign = await prisma.campaign.findFirst({
      where: { id: campaignId, userId: req.user.id },
    });
    if (!campaign) return res.status(404).json({ error: 'Campaña no encontrada' });

    const reports = await prisma.report.findMany({
      where: { campaignId },
      orderBy: { createdAt: 'desc' },
      take: 30,
      select: { id:true, type:true, period:true, createdAt:true },
    });

    res.json({ reports });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener reportes' });
  }
});

// ─── GET /api/reports/:id ─────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const report = await prisma.report.findFirst({
      where: { id: req.params.id },
      include: { campaign: true },
    });
    if (!report || report.campaign.userId !== req.user.id) {
      return res.status(404).json({ error: 'Reporte no encontrado' });
    }
    res.json({ report });
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener reporte' });
  }
});

module.exports = router;

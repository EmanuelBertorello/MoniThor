// src/seed.js
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { prisma } = require('./lib/db');

async function seed() {
  console.log('🌱 Seeding database...');

  // Create demo user
  const password = await bcrypt.hash('demo1234', 12);
  const user = await prisma.user.upsert({
    where: { email: 'demo@politicamonitor.com' },
    update: {},
    create: {
      email: 'demo@politicamonitor.com',
      password,
      name: 'Usuario Demo',
      role: 'ADMIN',
      plan: 'CAMPANA',
    },
  });
  console.log(`✅ Demo user: demo@politicamonitor.com / demo1234`);

  // Create campaign
  const campaign = await prisma.campaign.upsert({
    where: { id: 'demo-campaign-001' },
    update: {},
    create: {
      id: 'demo-campaign-001',
      name: 'Campaña Presidencial 2027',
      description: 'Monitoreo principal de la campaña presidencial',
      userId: user.id,
    },
  });

  // Add keywords
  const keywords = [
    { term: 'García Morales', color: '#3b82f6' },
    { term: 'reforma fiscal', color: '#8b5cf6' },
    { term: 'debate presidencial', color: '#10b981' },
    { term: 'campaña 2027', color: '#f59e0b' },
  ];

  for (const kw of keywords) {
    await prisma.keyword.upsert({
      where: { term_campaignId: { term: kw.term, campaignId: campaign.id } },
      update: {},
      create: { ...kw, campaignId: campaign.id },
    });
  }
  console.log(`✅ ${keywords.length} keywords created`);

  // Add sources
  const sources = [
    { type: 'NEWS', name: 'Google News' },
    { type: 'WEB', name: 'Sitios Web' },
    { type: 'FACEBOOK', name: 'Facebook' },
    { type: 'INSTAGRAM', name: 'Instagram' },
    { type: 'TWITTER', name: 'Twitter/X' },
  ];

  for (const src of sources) {
    await prisma.source.create({
      data: { ...src, campaignId: campaign.id },
    }).catch(() => {}); // ignore if exists
  }

  // Add default alert rule
  await prisma.alertRule.create({
    data: {
      campaignId: campaign.id,
      name: 'Pico de menciones negativas',
      condition: JSON.stringify({ type: 'negative_surge', threshold: 10 }),
      channels: ['email'],
      recipients: ['demo@politicamonitor.com'],
    },
  }).catch(() => {});

  // Add some sample mentions
  const sampleMentions = [
    { source: 'NEWS', content: 'García Morales presenta propuesta de reforma fiscal que genera debate en el Congreso.', sentiment: 'NEUTRAL', reach: 45000 },
    { source: 'FACEBOOK', content: 'El candidato García Morales mostró propuestas concretas en el debate de anoche. Muy sólido.', sentiment: 'POSITIVE', reach: 12000 },
    { source: 'TWITTER', content: 'El debate presidencial estuvo vacío de propuestas reales. Ningún candidato explicó cómo financiarán sus proyectos.', sentiment: 'NEGATIVE', reach: 28000 },
    { source: 'INSTAGRAM', content: 'La campaña 2027 necesita propuestas más claras sobre economía y seguridad.', sentiment: 'NEUTRAL', reach: 8500 },
    { source: 'NEWS', content: 'Encuesta: candidato lidera con 34% de intención de voto tras debate presidencial.', sentiment: 'POSITIVE', reach: 150000 },
  ];

  for (const mention of sampleMentions) {
    await prisma.mention.create({
      data: {
        ...mention,
        campaignId: campaign.id,
        snippet: mention.content.slice(0, 200),
        sourceName: mention.source,
        publishedAt: new Date(Date.now() - Math.random() * 3600000),
      },
    });
  }
  console.log(`✅ ${sampleMentions.length} sample mentions created`);

  console.log('\n🎉 Seed complete!');
  console.log('📧 Login: demo@politicamonitor.com');
  console.log('🔑 Password: demo1234');

  await prisma.$disconnect();
}

seed().catch(console.error);

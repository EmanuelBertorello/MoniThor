// src/pages/landing.js — Landing page comercial de PoliticaMonitor
import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Landing() {
  const router = useRouter();
  const [contactForm, setContactForm] = useState({ nombre:'', email:'', cargo:'', provincia:'', mensaje:'' });
  const [sent, setSent] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  function handleContact(e) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div style={{ fontFamily:"'Inter',system-ui,sans-serif", background:'#060b18', color:'#f1f5f9', minHeight:'100vh', overflowX:'hidden' }}>

      {/* ── NAV ─────────────────────────────────────────────────────────────── */}
      <nav style={{ position:'fixed', top:0, left:0, right:0, zIndex:100, background:'rgba(6,11,24,0.92)', backdropFilter:'blur(12px)', borderBottom:'1px solid rgba(59,130,246,0.15)', padding:'0 5%' }}>
        <div style={{ maxWidth:'1200px', margin:'0 auto', display:'flex', alignItems:'center', height:'68px', gap:'16px' }}>
          <div style={{ display:'flex', alignItems:'center', gap:'10px', flex:1 }}>
            <div style={{ width:'36px', height:'36px', borderRadius:'10px', background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px', flexShrink:0 }}>📡</div>
            <span style={{ fontSize:'20px', fontWeight:'800', letterSpacing:'-0.5px' }}>Politica<span style={{ color:'#3b82f6' }}>Monitor</span></span>
          </div>
          <div style={{ display:'flex', gap:'28px', alignItems:'center' }}>
            {['Funcionalidades','Precios','Contacto'].map(item=>(
              <a key={item} href={`#${item.toLowerCase()}`} style={{ color:'#94a3b8', fontSize:'14px', fontWeight:'500', textDecoration:'none', transition:'color .2s' }}
                onMouseEnter={e=>e.target.style.color='#f1f5f9'} onMouseLeave={e=>e.target.style.color='#94a3b8'}>{item}</a>
            ))}
            <button onClick={()=>router.push('/login')} style={{ background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', color:'#fff', border:'none', borderRadius:'8px', padding:'9px 20px', fontSize:'14px', fontWeight:'600', cursor:'pointer' }}>
              Ingresar al sistema →
            </button>
          </div>
        </div>
      </nav>

      {/* ── HERO ────────────────────────────────────────────────────────────── */}
      <section style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', textAlign:'center', padding:'120px 5% 80px', position:'relative', overflow:'hidden' }}>
        {/* Background glow */}
        <div style={{ position:'absolute', top:'20%', left:'50%', transform:'translateX(-50%)', width:'800px', height:'800px', borderRadius:'50%', background:'radial-gradient(circle, rgba(59,130,246,0.12) 0%, transparent 70%)', pointerEvents:'none' }}/>
        <div style={{ position:'absolute', top:'30%', left:'20%', width:'400px', height:'400px', borderRadius:'50%', background:'radial-gradient(circle, rgba(139,92,246,0.08) 0%, transparent 70%)', pointerEvents:'none' }}/>

        <div style={{ maxWidth:'900px', position:'relative', zIndex:1 }}>
          <div style={{ display:'inline-flex', alignItems:'center', gap:'8px', background:'rgba(59,130,246,0.1)', border:'1px solid rgba(59,130,246,0.3)', borderRadius:'20px', padding:'6px 16px', marginBottom:'28px', fontSize:'13px', color:'#60a5fa', fontWeight:'600' }}>
            <div style={{ width:'6px', height:'6px', borderRadius:'50%', background:'#3b82f6', animation:'pulse 1.2s ease-in-out infinite' }}/>
            Monitoreo político en tiempo real · Argentina
          </div>

          <h1 style={{ fontSize:'clamp(40px,6vw,72px)', fontWeight:'900', lineHeight:'1.05', marginBottom:'24px', letterSpacing:'-2px' }}>
            Sabé todo lo que dicen<br/>
            <span style={{ background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
              de tu candidato
            </span><br/>
            antes que nadie
          </h1>

          <p style={{ fontSize:'clamp(17px,2vw,22px)', color:'#94a3b8', maxWidth:'680px', margin:'0 auto 40px', lineHeight:'1.7', fontWeight:'400' }}>
            La plataforma de inteligencia política que monitorea en tiempo real redes sociales, medios y sitios web de tu provincia. Detectá crisis, medí el sentimiento y respondé antes que el rival.
          </p>

          <div style={{ display:'flex', gap:'14px', justifyContent:'center', flexWrap:'wrap' }}>
            <button onClick={()=>document.getElementById('precios').scrollIntoView({behavior:'smooth'})} style={{ background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', color:'#fff', border:'none', borderRadius:'10px', padding:'16px 32px', fontSize:'16px', fontWeight:'700', cursor:'pointer', boxShadow:'0 0 40px rgba(59,130,246,0.3)' }}>
              Ver planes y precios
            </button>
            <button onClick={()=>router.push('/login')} style={{ background:'rgba(255,255,255,0.05)', color:'#f1f5f9', border:'1px solid rgba(255,255,255,0.15)', borderRadius:'10px', padding:'16px 32px', fontSize:'16px', fontWeight:'600', cursor:'pointer' }}>
              Demo gratuita →
            </button>
          </div>

          {/* Stats */}
          <div style={{ display:'flex', gap:'40px', justifyContent:'center', marginTop:'60px', flexWrap:'wrap' }}>
            {[
              { num:'24/7', label:'Monitoreo continuo' },
              { num:'5+', label:'Fuentes simultáneas' },
              { num:'15min', label:'Actualización' },
              { num:'IA', label:'Análisis de sentimiento' },
            ].map((s,i)=>(
              <div key={i} style={{ textAlign:'center' }}>
                <div style={{ fontSize:'28px', fontWeight:'900', color:'#3b82f6', letterSpacing:'-1px' }}>{s.num}</div>
                <div style={{ fontSize:'12px', color:'#64748b', fontWeight:'500', marginTop:'4px' }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROBLEMA ────────────────────────────────────────────────────────── */}
      <section style={{ padding:'80px 5%', background:'rgba(255,255,255,0.02)', borderTop:'1px solid rgba(255,255,255,0.05)', borderBottom:'1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ maxWidth:'1100px', margin:'0 auto' }}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'60px', alignItems:'center' }}>
            <div>
              <div style={{ fontSize:'12px', fontWeight:'700', color:'#ef4444', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'16px' }}>El problema</div>
              <h2 style={{ fontSize:'clamp(28px,3vw,42px)', fontWeight:'800', lineHeight:'1.2', marginBottom:'20px', letterSpacing:'-1px' }}>
                En política, las crisis explotan en minutos
              </h2>
              <p style={{ color:'#94a3b8', fontSize:'16px', lineHeight:'1.8', marginBottom:'24px' }}>
                Cuando tu equipo se entera de que están hablando mal del candidato en Facebook o Instagram, ya es tarde. El daño está hecho, el posteo se viralizó y el rival ya sacó ventaja.
              </p>
              <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
                {[
                  'No sabés lo que dice la gente en los grupos de Facebook de tu distrito',
                  'Te enterás de los ataques cuando ya tienen miles de likes',
                  'No tenés datos duros para responder a las críticas',
                  'Perdés tiempo buscando menciones manualmente',
                ].map((p,i)=>(
                  <div key={i} style={{ display:'flex', gap:'12px', alignItems:'flex-start' }}>
                    <span style={{ color:'#ef4444', fontSize:'16px', flexShrink:0, marginTop:'2px' }}>✗</span>
                    <span style={{ color:'#94a3b8', fontSize:'15px', lineHeight:'1.5' }}>{p}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
              <div style={{ fontSize:'12px', fontWeight:'700', color:'#10b981', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'2px' }}>La solución</div>
              {[
                { icon:'📡', title:'Monitoreo 24/7 automático', desc:'El sistema rastrea tu provincia cada 15 minutos sin que tengas que hacer nada.' },
                { icon:'🔔', title:'Alertas instantáneas', desc:'Te avisa por WhatsApp o email cuando hay un pico de menciones negativas.' },
                { icon:'🧠', title:'IA analiza el sentimiento', desc:'Gemini AI lee cada mención y determina si es positiva, negativa o neutral.' },
                { icon:'📊', title:'Reportes para el equipo', desc:'Descargá informes ejecutivos en PDF/Excel para reuniones de campaña.' },
              ].map((s,i)=>(
                <div key={i} style={{ display:'flex', gap:'16px', background:'rgba(16,185,129,0.05)', border:'1px solid rgba(16,185,129,0.15)', borderRadius:'12px', padding:'16px' }}>
                  <span style={{ fontSize:'24px', flexShrink:0 }}>{s.icon}</span>
                  <div>
                    <div style={{ fontWeight:'700', fontSize:'14px', marginBottom:'4px', color:'#10b981' }}>{s.title}</div>
                    <div style={{ color:'#64748b', fontSize:'13px', lineHeight:'1.5' }}>{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── FUNCIONALIDADES ─────────────────────────────────────────────────── */}
      <section id="funcionalidades" style={{ padding:'100px 5%' }}>
        <div style={{ maxWidth:'1100px', margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:'60px' }}>
            <div style={{ fontSize:'12px', fontWeight:'700', color:'#3b82f6', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'12px' }}>Funcionalidades</div>
            <h2 style={{ fontSize:'clamp(28px,3vw,44px)', fontWeight:'800', letterSpacing:'-1px', marginBottom:'16px' }}>Todo lo que necesita tu campaña</h2>
            <p style={{ color:'#64748b', fontSize:'16px', maxWidth:'560px', margin:'0 auto' }}>Diseñado específicamente para campañas políticas argentinas, con foco en el interior del país.</p>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'20px' }}>
            {[
              { icon:'🌐', color:'#0ea5e9', title:'Monitoreo web total', desc:'Rastrea sitios de noticias locales, portales digitales, blogs y cualquier web pública de tu provincia.' },
              { icon:'📘', color:'#1877f2', title:'Facebook completo', desc:'Monitorea páginas de medios locales, grupos públicos y cualquier perfil que mencione al candidato.' },
              { icon:'📸', color:'#e1306c', title:'Instagram en tiempo real', desc:'Sigue hashtags locales, perfiles de influencers y detecta posts virales de tu zona.' },
              { icon:'📰', color:'#f59e0b', title:'Medios de comunicación', desc:'Integrado con Google News y NewsAPI para capturar cobertura periodística al instante.' },
              { icon:'🧠', color:'#8b5cf6', title:'IA de sentimiento político', desc:'Gemini AI analiza cada mención entendiendo el contexto político argentino, sarcasmo y jerga local.' },
              { icon:'📍', color:'#10b981', title:'Filtro geográfico exacto', desc:'Buscá solo en Tierra del Fuego, Córdoba, o cualquier provincia y ciudad. Sin ruido de otras regiones.' },
              { icon:'⚠️', color:'#ef4444', title:'Alertas de crisis', desc:'Configurá alertas por WhatsApp o email cuando detecta picos de negatividad o keywords específicas.' },
              { icon:'📊', color:'#f59e0b', title:'Reportes ejecutivos', desc:'Descargá informes en CSV, TXT ejecutivo o JSON con un clic para compartir con el equipo.' },
              { icon:'👥', color:'#3b82f6', title:'Multi-usuario con roles', desc:'Admin, Analista y Monitor. Demos de 30 minutos para mostrar a potenciales clientes.' },
            ].map((f,i)=>(
              <div key={i} style={{ background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.07)', borderRadius:'14px', padding:'24px', transition:'all .2s' }}
                onMouseEnter={e=>{ e.currentTarget.style.background='rgba(255,255,255,0.05)'; e.currentTarget.style.borderColor=`${f.color}40`; e.currentTarget.style.transform='translateY(-2px)'; }}
                onMouseLeave={e=>{ e.currentTarget.style.background='rgba(255,255,255,0.03)'; e.currentTarget.style.borderColor='rgba(255,255,255,0.07)'; e.currentTarget.style.transform='translateY(0)'; }}>
                <div style={{ width:'44px', height:'44px', borderRadius:'10px', background:`${f.color}15`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'22px', marginBottom:'14px' }}>{f.icon}</div>
                <div style={{ fontWeight:'700', fontSize:'15px', marginBottom:'8px', color:f.color }}>{f.title}</div>
                <div style={{ color:'#64748b', fontSize:'13px', lineHeight:'1.6' }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CÓMO FUNCIONA ───────────────────────────────────────────────────── */}
      <section style={{ padding:'80px 5%', background:'rgba(255,255,255,0.02)', borderTop:'1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ maxWidth:'900px', margin:'0 auto', textAlign:'center' }}>
          <div style={{ fontSize:'12px', fontWeight:'700', color:'#3b82f6', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'12px' }}>Cómo funciona</div>
          <h2 style={{ fontSize:'clamp(28px,3vw,42px)', fontWeight:'800', letterSpacing:'-1px', marginBottom:'48px' }}>En 3 pasos estás monitoreando</h2>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'24px' }}>
            {[
              { num:'1', icon:'🎯', title:'Configurás tu campaña', desc:'Cargás el nombre del candidato, elegís la provincia y ciudad, y agregás las palabras clave a monitorear. Listo en 5 minutos.' },
              { num:'2', icon:'🤖', title:'El sistema trabaja solo', desc:'Cada 15 minutos rastrea automáticamente Facebook, Instagram, noticias y sitios web de tu zona buscando menciones.' },
              { num:'3', icon:'🔔', title:'Vos tomás decisiones', desc:'Recibís alertas en tiempo real, analizás el sentimiento y descargás reportes para reuniones de equipo.' },
            ].map((s,i)=>(
              <div key={i} style={{ position:'relative' }}>
                <div style={{ width:'56px', height:'56px', borderRadius:'50%', background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'22px', fontWeight:'900', margin:'0 auto 16px', boxShadow:'0 0 30px rgba(59,130,246,0.3)' }}>{s.icon}</div>
                <div style={{ position:'absolute', top:'28px', right:0, width:'calc(100% - 80px)', height:'1px', background:'linear-gradient(90deg,rgba(59,130,246,0.4),transparent)', display: i<2?'block':'none' }}/>
                <div style={{ fontSize:'12px', color:'#3b82f6', fontWeight:'700', marginBottom:'8px' }}>PASO {s.num}</div>
                <div style={{ fontWeight:'700', fontSize:'16px', marginBottom:'10px' }}>{s.title}</div>
                <div style={{ color:'#64748b', fontSize:'14px', lineHeight:'1.6' }}>{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRECIOS ─────────────────────────────────────────────────────────── */}
      <section id="precios" style={{ padding:'100px 5%' }}>
        <div style={{ maxWidth:'1100px', margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:'60px' }}>
            <div style={{ fontSize:'12px', fontWeight:'700', color:'#3b82f6', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'12px' }}>Planes</div>
            <h2 style={{ fontSize:'clamp(28px,3vw,44px)', fontWeight:'800', letterSpacing:'-1px', marginBottom:'16px' }}>Elegí el plan para tu campaña</h2>
            <p style={{ color:'#64748b', fontSize:'16px' }}>Sin contratos anuales. Cancelás cuando querés.</p>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'24px', alignItems:'start' }}>
            {[
              {
                name:'Básico', price:'USD 500', period:'/mes',
                color:'#64748b', highlight:false,
                tag:null,
                desc:'Para candidatos locales que arrancan su monitoreo',
                features:[
                  '1 campaña activa',
                  'Hasta 5 palabras clave',
                  '1 provincia / ciudad',
                  'Google News + Web',
                  'Análisis de sentimiento IA',
                  'Feed en tiempo real',
                  'Alertas por email',
                  'Reportes CSV y TXT',
                  '2 usuarios (Admin + Monitor)',
                ],
                notIncluded:['Facebook / Instagram','Alertas WhatsApp','Usuarios ilimitados'],
              },
              {
                name:'Campaña', price:'USD 1.500', period:'/mes',
                color:'#3b82f6', highlight:true,
                tag:'MÁS ELEGIDO',
                desc:'Para campañas provinciales y municipales activas',
                features:[
                  'Hasta 3 campañas activas',
                  'Hasta 20 palabras clave',
                  'Todas las provincias y ciudades',
                  'Google News + Web',
                  'Facebook páginas y grupos',
                  'Instagram perfiles y hashtags',
                  'Análisis IA con Gemini',
                  'Alertas email + WhatsApp',
                  'Reportes CSV, TXT, JSON',
                  '10 usuarios con roles',
                  'Demos de 30 min para clientes',
                ],
                notIncluded:[],
              },
              {
                name:'Guerra Electoral', price:'USD 4.000', period:'/mes',
                color:'#8b5cf6', highlight:false,
                tag:'MÁXIMA POTENCIA',
                desc:'Para campañas provinciales y presidenciales',
                features:[
                  'Campañas ilimitadas',
                  'Keywords ilimitadas',
                  'Todo el país simultáneo',
                  'Todas las fuentes incluidas',
                  'Facebook + Instagram + Twitter',
                  'IA con análisis profundo',
                  'Alertas multicanal 24/7',
                  'Sala de crisis en tiempo real',
                  'Usuarios ilimitados',
                  'API access para integraciones',
                  'Analista dedicado (8hs/día)',
                  'Soporte prioritario 24/7',
                ],
                notIncluded:[],
              },
            ].map((plan,i)=>(
              <div key={i} style={{
                background: plan.highlight ? 'linear-gradient(135deg,rgba(59,130,246,0.12),rgba(139,92,246,0.08))' : 'rgba(255,255,255,0.02)',
                border: `1px solid ${plan.highlight ? plan.color+'60' : 'rgba(255,255,255,0.08)'}`,
                borderRadius:'16px', padding:'32px',
                position:'relative',
                boxShadow: plan.highlight ? `0 0 60px ${plan.color}20` : 'none',
                transform: plan.highlight ? 'scale(1.03)' : 'scale(1)',
              }}>
                {plan.tag && (
                  <div style={{ position:'absolute', top:'-14px', left:'50%', transform:'translateX(-50%)', background:`linear-gradient(135deg,${plan.color},#8b5cf6)`, color:'#fff', fontSize:'11px', fontWeight:'800', padding:'5px 16px', borderRadius:'20px', letterSpacing:'1px', whiteSpace:'nowrap' }}>
                    {plan.tag}
                  </div>
                )}
                <div style={{ fontSize:'13px', fontWeight:'700', color:plan.color, marginBottom:'8px', letterSpacing:'1px', textTransform:'uppercase' }}>{plan.name}</div>
                <div style={{ display:'flex', alignItems:'baseline', gap:'4px', marginBottom:'8px' }}>
                  <span style={{ fontSize:'38px', fontWeight:'900', letterSpacing:'-2px' }}>{plan.price}</span>
                  <span style={{ fontSize:'14px', color:'#64748b' }}>{plan.period}</span>
                </div>
                <div style={{ fontSize:'13px', color:'#64748b', marginBottom:'24px', lineHeight:'1.5' }}>{plan.desc}</div>

                <button onClick={()=>document.getElementById('contacto').scrollIntoView({behavior:'smooth'})} style={{
                  width:'100%', padding:'13px', borderRadius:'10px', border:'none',
                  background: plan.highlight ? `linear-gradient(135deg,${plan.color},#8b5cf6)` : `${plan.color}20`,
                  color: plan.highlight ? '#fff' : plan.color,
                  fontSize:'14px', fontWeight:'700', cursor:'pointer', marginBottom:'24px',
                  boxShadow: plan.highlight ? `0 0 30px ${plan.color}40` : 'none',
                }}>
                  Contratar {plan.name}
                </button>

                <div style={{ display:'flex', flexDirection:'column', gap:'10px' }}>
                  {plan.features.map((f,j)=>(
                    <div key={j} style={{ display:'flex', gap:'10px', alignItems:'flex-start' }}>
                      <span style={{ color:'#10b981', flexShrink:0, fontSize:'14px' }}>✓</span>
                      <span style={{ fontSize:'13px', color:'#cbd5e1', lineHeight:'1.4' }}>{f}</span>
                    </div>
                  ))}
                  {plan.notIncluded.map((f,j)=>(
                    <div key={j} style={{ display:'flex', gap:'10px', alignItems:'flex-start', opacity:0.4 }}>
                      <span style={{ color:'#64748b', flexShrink:0, fontSize:'14px' }}>—</span>
                      <span style={{ fontSize:'13px', color:'#64748b', lineHeight:'1.4' }}>{f}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div style={{ textAlign:'center', marginTop:'40px', padding:'20px', background:'rgba(59,130,246,0.05)', border:'1px solid rgba(59,130,246,0.15)', borderRadius:'12px' }}>
            <p style={{ color:'#94a3b8', fontSize:'14px' }}>
              💡 <strong style={{ color:'#f1f5f9' }}>¿No sabés cuál elegir?</strong> Te ofrecemos una demo gratuita de 30 minutos con tu candidato y tu provincia para que veas el sistema funcionando antes de decidir.
            </p>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIOS ─────────────────────────────────────────────────────── */}
      <section style={{ padding:'80px 5%', background:'rgba(255,255,255,0.02)', borderTop:'1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ maxWidth:'1000px', margin:'0 auto', textAlign:'center' }}>
          <h2 style={{ fontSize:'clamp(24px,3vw,36px)', fontWeight:'800', letterSpacing:'-1px', marginBottom:'48px' }}>
            Diseñado para ganar elecciones en Argentina
          </h2>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'20px' }}>
            {[
              { icon:'🗺️', title:'Interior profundo', desc:'Funcionamos en todas las provincias argentinas, con fuentes de noticias locales de cada distrito.' },
              { icon:'🇦🇷', title:'Contexto político local', desc:'La IA entiende kirchnerismo, motosierra, grieta y toda la jerga política argentina actual.' },
              { icon:'⚡', title:'Respuesta en minutos', desc:'Cuando algo explota en las redes de tu ciudad, tu equipo lo sabe en menos de 15 minutos.' },
            ].map((t,i)=>(
              <div key={i} style={{ background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.07)', borderRadius:'14px', padding:'28px' }}>
                <div style={{ fontSize:'36px', marginBottom:'16px' }}>{t.icon}</div>
                <div style={{ fontWeight:'700', fontSize:'16px', marginBottom:'10px' }}>{t.title}</div>
                <div style={{ color:'#64748b', fontSize:'14px', lineHeight:'1.6' }}>{t.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CONTACTO ────────────────────────────────────────────────────────── */}
      <section id="contacto" style={{ padding:'100px 5%' }}>
        <div style={{ maxWidth:'700px', margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:'48px' }}>
            <div style={{ fontSize:'12px', fontWeight:'700', color:'#3b82f6', letterSpacing:'2px', textTransform:'uppercase', marginBottom:'12px' }}>Contacto</div>
            <h2 style={{ fontSize:'clamp(28px,3vw,42px)', fontWeight:'800', letterSpacing:'-1px', marginBottom:'16px' }}>Pedí tu demo gratuita</h2>
            <p style={{ color:'#64748b', fontSize:'16px' }}>Te mostramos el sistema funcionando con el nombre de tu candidato y tu provincia, sin compromiso.</p>
          </div>

          {sent ? (
            <div style={{ textAlign:'center', padding:'48px', background:'rgba(16,185,129,0.08)', border:'1px solid rgba(16,185,129,0.3)', borderRadius:'16px' }}>
              <div style={{ fontSize:'48px', marginBottom:'16px' }}>✅</div>
              <h3 style={{ fontSize:'22px', fontWeight:'700', marginBottom:'8px' }}>¡Mensaje recibido!</h3>
              <p style={{ color:'#94a3b8', fontSize:'15px' }}>Te contactamos en las próximas 24 horas para coordinar la demo.</p>
            </div>
          ) : (
            <form onSubmit={handleContact} style={{ display:'flex', flexDirection:'column', gap:'16px', background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:'16px', padding:'36px' }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
                <div>
                  <label style={{ display:'block', fontSize:'12px', color:'#64748b', fontWeight:'600', marginBottom:'6px', textTransform:'uppercase', letterSpacing:'0.5px' }}>Nombre completo *</label>
                  <input required value={contactForm.nombre} onChange={e=>setContactForm(p=>({...p,nombre:e.target.value}))} placeholder="Juan García" style={{ width:'100%', background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.1)', color:'#f1f5f9', padding:'10px 14px', borderRadius:'8px', fontSize:'14px', outline:'none', boxSizing:'border-box' }}/>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:'12px', color:'#64748b', fontWeight:'600', marginBottom:'6px', textTransform:'uppercase', letterSpacing:'0.5px' }}>Email *</label>
                  <input required type="email" value={contactForm.email} onChange={e=>setContactForm(p=>({...p,email:e.target.value}))} placeholder="juan@campaña.com" style={{ width:'100%', background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.1)', color:'#f1f5f9', padding:'10px 14px', borderRadius:'8px', fontSize:'14px', outline:'none', boxSizing:'border-box' }}/>
                </div>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
                <div>
                  <label style={{ display:'block', fontSize:'12px', color:'#64748b', fontWeight:'600', marginBottom:'6px', textTransform:'uppercase', letterSpacing:'0.5px' }}>Cargo / Rol</label>
                  <input value={contactForm.cargo} onChange={e=>setContactForm(p=>({...p,cargo:e.target.value}))} placeholder="Coordinador de campaña" style={{ width:'100%', background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.1)', color:'#f1f5f9', padding:'10px 14px', borderRadius:'8px', fontSize:'14px', outline:'none', boxSizing:'border-box' }}/>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:'12px', color:'#64748b', fontWeight:'600', marginBottom:'6px', textTransform:'uppercase', letterSpacing:'0.5px' }}>Provincia</label>
                  <select value={contactForm.provincia} onChange={e=>setContactForm(p=>({...p,provincia:e.target.value}))} style={{ width:'100%', background:'#1a2235', border:'1px solid rgba(255,255,255,0.1)', color:contactForm.provincia?'#f1f5f9':'#64748b', padding:'10px 14px', borderRadius:'8px', fontSize:'14px', outline:'none', boxSizing:'border-box' }}>
                    <option value=''>Seleccioná provincia</option>
                    {['Buenos Aires','Córdoba','Santa Fe','Mendoza','Tucumán','Entre Ríos','Salta','Misiones','Chaco','Corrientes','Santiago del Estero','San Juan','Jujuy','Río Negro','Neuquén','Formosa','La Pampa','Chubut','San Luis','Catamarca','La Rioja','Santa Cruz','Tierra del Fuego'].map(p=><option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label style={{ display:'block', fontSize:'12px', color:'#64748b', fontWeight:'600', marginBottom:'6px', textTransform:'uppercase', letterSpacing:'0.5px' }}>¿Qué necesitás monitorear?</label>
                <textarea value={contactForm.mensaje} onChange={e=>setContactForm(p=>({...p,mensaje:e.target.value}))} placeholder="Contanos sobre tu candidato, el cargo al que aspira y qué tipo de información necesitás..." rows={4} style={{ width:'100%', background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.1)', color:'#f1f5f9', padding:'10px 14px', borderRadius:'8px', fontSize:'14px', outline:'none', resize:'vertical', boxSizing:'border-box', fontFamily:'inherit' }}/>
              </div>
              <button type="submit" style={{ background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', color:'#fff', border:'none', borderRadius:'10px', padding:'15px', fontSize:'15px', fontWeight:'700', cursor:'pointer', boxShadow:'0 0 40px rgba(59,130,246,0.3)', marginTop:'8px' }}>
                📡 Solicitar demo gratuita →
              </button>
              <p style={{ textAlign:'center', color:'#475569', fontSize:'12px' }}>Respondemos en menos de 24 horas · Sin compromiso de contratación</p>
            </form>
          )}
        </div>
      </section>

      {/* ── FOOTER ──────────────────────────────────────────────────────────── */}
      <footer style={{ padding:'40px 5%', borderTop:'1px solid rgba(255,255,255,0.06)', background:'rgba(0,0,0,0.3)' }}>
        <div style={{ maxWidth:'1100px', margin:'0 auto', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'16px' }}>
          <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
            <div style={{ width:'28px', height:'28px', borderRadius:'7px', background:'linear-gradient(135deg,#3b82f6,#8b5cf6)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'14px' }}>📡</div>
            <span style={{ fontWeight:'800', fontSize:'16px' }}>Politica<span style={{ color:'#3b82f6' }}>Monitor</span></span>
          </div>
          <p style={{ color:'#334155', fontSize:'13px' }}>© 2026 PoliticaMonitor · Inteligencia política para Argentina</p>
          <button onClick={()=>router.push('/login')} style={{ background:'rgba(59,130,246,0.1)', border:'1px solid rgba(59,130,246,0.3)', color:'#60a5fa', borderRadius:'8px', padding:'8px 18px', fontSize:'13px', fontWeight:'600', cursor:'pointer' }}>
            Ingresar al sistema →
          </button>
        </div>
      </footer>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(0.8)} }
        input::placeholder, textarea::placeholder { color: #475569; }
        select option { background: #1a2235; }
      `}</style>
    </div>
  );
}

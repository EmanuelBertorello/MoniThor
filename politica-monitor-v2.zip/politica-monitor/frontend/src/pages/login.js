// src/pages/login.js
import { useState } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../lib/auth';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ email: '', password: '', name: '' });
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const router = useRouter();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(form.email, form.password);
      } else {
        await register(form.email, form.password, form.name);
      }
      router.push('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg)', display: 'flex',
      alignItems: 'center', justifyContent: 'center', padding: '20px'
    }}>
      {/* Background decoration */}
      <div style={{
        position: 'fixed', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 0
      }}>
        <div style={{
          position: 'absolute', top: '-20%', left: '50%', transform: 'translateX(-50%)',
          width: '800px', height: '800px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(59,130,246,0.08) 0%, transparent 70%)'
        }}/>
      </div>

      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: '420px' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '56px', height: '56px', borderRadius: '14px',
            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '28px', margin: '0 auto 16px'
          }}>📡</div>
          <h1 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '4px' }}>
            PoliticaMonitor
          </h1>
          <p style={{ color: 'var(--text3)', fontSize: '14px' }}>
            Sistema de monitoreo político en tiempo real
          </p>
        </div>

        {/* Card */}
        <div className="card">
          {/* Tabs */}
          <div style={{
            display: 'flex', gap: '4px', background: 'var(--bg3)',
            borderRadius: '8px', padding: '4px', marginBottom: '24px'
          }}>
            {['login', 'register'].map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                style={{
                  flex: 1, padding: '8px', borderRadius: '6px', border: 'none',
                  fontSize: '13px', fontWeight: '600', cursor: 'pointer',
                  background: mode === m ? 'var(--accent)' : 'transparent',
                  color: mode === m ? '#fff' : 'var(--text2)',
                  transition: 'all 0.15s'
                }}
              >
                {m === 'login' ? 'Iniciar sesión' : 'Registrarse'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {mode === 'register' && (
              <div>
                <label>Nombre completo</label>
                <input
                  type="text"
                  placeholder="Ej: María García"
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  required
                />
              </div>
            )}
            <div>
              <label>Email</label>
              <input
                type="email"
                placeholder="tu@email.com"
                value={form.email}
                onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                required
              />
            </div>
            <div>
              <label>Contraseña</label>
              <input
                type="password"
                placeholder={mode === 'register' ? 'Mínimo 8 caracteres' : '••••••••'}
                value={form.password}
                onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                required
                minLength={mode === 'register' ? 8 : 1}
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading}
              style={{ width: '100%', justifyContent: 'center', padding: '12px', fontSize: '14px', marginTop: '4px' }}
            >
              {loading ? '⏳ Cargando...' : mode === 'login' ? '→ Ingresar al dashboard' : '→ Crear cuenta'}
            </button>
          </form>

          {/* Demo credentials */}
          <div style={{
            marginTop: '20px', padding: '12px', background: 'var(--bg3)',
            borderRadius: '8px', fontSize: '12px', color: 'var(--text3)'
          }}>
            <strong style={{ color: 'var(--text2)' }}>Demo:</strong>{' '}
            demo@politicamonitor.com / demo1234{' '}
            <button
              onClick={() => setForm({ email: 'demo@politicamonitor.com', password: 'demo1234', name: '' })}
              style={{
                background: 'none', border: 'none', color: 'var(--accent2)',
                cursor: 'pointer', fontSize: '12px', fontWeight: '600'
              }}
            >
              [Usar]
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

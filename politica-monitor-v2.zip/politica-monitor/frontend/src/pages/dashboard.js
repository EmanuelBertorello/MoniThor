// src/pages/dashboard.js
import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../lib/auth';
import { campaignsAPI, mentionsAPI, analyticsAPI, keywordsAPI, reportsAPI } from '../lib/api';
import { useSocket } from '../hooks/useSocket';
import toast from 'react-hot-toast';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, RadarChart,
  Radar, PolarGrid, PolarAngleAxis
} from 'recharts';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const SRC_ICONS  = { WEB:'🌐', TWITTER:'🐦', FACEBOOK:'📘', INSTAGRAM:'📸', NEWS:'📰', ALL:'🔍' };
const SRC_COLORS = { WEB:'#0ea5e9', TWITTER:'#1d9bf0', FACEBOOK:'#1877f2', INSTAGRAM:'#e1306c', NEWS:'#f59e0b' };
const SENT_COLORS = { POSITIVE:'#10b981', NEGATIVE:'#ef4444', NEUTRAL:'#64748b' };
const KW_COLORS  = ['#3b82f6','#8b5cf6','#10b981','#f59e0b','#ef4444','#e1306c','#0ea5e9','#ec4899'];

const PERIOD_OPTIONS = [
  { value:'1h', label:'1h' }, { value:'24h', label:'24h' },
  { value:'7d', label:'7d' }, { value:'30d', label:'30d' },
];

// ─── Provincias y ciudades de Argentina ────────────────────────────────────────
const ARGENTINA_GEO = {
  'Buenos Aires': ['CABA','La Plata','Mar del Plata','Bahía Blanca','Quilmes','Lanús','General San Martín','Morón','Tigre','Lomas de Zamora'],
  'Córdoba': ['Córdoba Capital','Villa Carlos Paz','Río Cuarto','Villa María','San Francisco','Alta Gracia'],
  'Santa Fe': ['Rosario','Santa Fe Capital','Rafaela','Venado Tuerto','Villa Gobernador Gálvez'],
  'Mendoza': ['Mendoza Capital','San Rafael','Godoy Cruz','Luján de Cuyo','Maipú'],
  'Tucumán': ['San Miguel de Tucumán','Tafí Viejo','Banda del Río Salí','Yerba Buena'],
  'Entre Ríos': ['Paraná','Concordia','Gualeguaychú','Concepción del Uruguay'],
  'Salta': ['Salta Capital','San Ramón de la Nueva Orán','Tartagal','Metán'],
  'Misiones': ['Posadas','Oberá','Eldorado','Puerto Iguazú'],
  'Chaco': ['Resistencia','Barranqueras','Presidencia Roque Sáenz Peña'],
  'Santiago del Estero': ['Santiago del Estero Capital','La Banda','Termas de Río Hondo'],
  'San Juan': ['San Juan Capital','Rivadavia','Chimbas'],
  'Jujuy': ['San Salvador de Jujuy','Palpalá','San Pedro de Jujuy'],
  'Río Negro': ['Viedma','San Carlos de Bariloche','General Roca','Cipolletti'],
  'Neuquén': ['Neuquén Capital','Zapala','San Martín de los Andes','Cutral-Có'],
  'Formosa': ['Formosa Capital','Clorinda','Pirané'],
  'La Pampa': ['Santa Rosa','General Pico','Toay'],
  'Chubut': ['Rawson','Comodoro Rivadavia','Trelew','Puerto Madryn'],
  'San Luis': ['San Luis Capital','Villa Mercedes','Merlo'],
  'Corrientes': ['Corrientes Capital','Goya','Paso de los Libres'],
  'Catamarca': ['Catamarca Capital','San Fernando del Valle'],
  'La Rioja': ['La Rioja Capital','Chilecito'],
  'Santa Cruz': ['Río Gallegos','Caleta Olivia','El Calafate'],
  'Tierra del Fuego': ['Ushuaia','Río Grande'],
};

function fmtNum(n) {
  if (!n) return '0';
  if (n >= 1000000) return (n/1000000).toFixed(1)+'M';
  if (n >= 1000) return (n/1000).toFixed(1)+'k';
  return n.toString();
}
function timeAgo(date) {
  const diff = Math.floor((Date.now()-new Date(date))/1000);
  if (diff<60) return `hace ${diff}s`;
  if (diff<3600) return `hace ${Math.floor(diff/60)}min`;
  if (diff<86400) return `hace ${Math.floor(diff/3600)}h`;
  return format(new Date(date),'d MMM HH:mm',{locale:es});
}

// ══════════════════════════════════════════════════════════════════════════════
export default function Dashboard() {
  const { user, logout, loading: authLoading } = useAuth();
  const router = useRouter();

  const [campaigns, setCampaigns]           = useState([]);
  const [activeCampaign, setActiveCampaign] = useState(null);
  const [mentions, setMentions]             = useState([]);
  const [analytics, setAnalytics]           = useState(null);
  const [timeseries, setTimeseries]         = useState([]);
  const [keywords, setKeywords]             = useState([]);
  const [unreadCount, setUnreadCount]       = useState(0);
  const [loading, setLoading]               = useState(true);
  const [period, setPeriod]                 = useState('24h');
  const [sourceFilter, setSourceFilter]     = useState('ALL');
  const [sentimentFilter, setSentimentFilter] = useState('ALL');
  const [searchQuery, setSearchQuery]       = useState('');
  const [newKeyword, setNewKeyword]         = useState('');
  const [editingKw, setEditingKw]           = useState(null); // {id, term}
  const [sidebarView, setSidebarView]       = useState('feed');
  const [newMentionsBanner, setNewMentionsBanner] = useState(0);
  const [alertBanner, setAlertBanner]       = useState(null);
  const [showNewCampaign, setShowNewCampaign] = useState(false);
  const [newCampaignName, setNewCampaignName] = useState('');
  const [mentionPage, setMentionPage]       = useState(1);
          const [feedHours, setFeedHours]           = useState(0); // 0 = sin límite, muestra todo
  const [totalMentions, setTotalMentions]   = useState(0);
  const [selectedProvincia, setSelectedProvincia] = useState('');
  const [selectedCiudad, setSelectedCiudad]       = useState('');

  // ── Guardar zona en la campaña y actualizar el scraper ───────────────────
  async function saveGeoToCampaign(provincia, ciudad) {
    if (!activeCampaign) return;
    try {
      await campaignsAPI.update(activeCampaign.id, { provincia, ciudad });
      const geoLabel = [ciudad, provincia].filter(Boolean).join(', ');
      if (geoLabel) toast.success(`🗺️ Zona guardada: ${geoLabel} — el scraping usará este filtro`);
    } catch {}
  }

  // ── Cargar zona guardada cuando cambia la campaña ────────────────────────
  useEffect(() => {
    if (!activeCampaign?.description) return;
    try {
      if (activeCampaign.description.startsWith('{')) {
        const geo = JSON.parse(activeCampaign.description);
        setSelectedProvincia(geo.provincia || '');
        setSelectedCiudad(geo.ciudad || '');
      }
    } catch {}
  }, [activeCampaign?.id]);
  const [analyticsSrc, setAnalyticsSrc]     = useState('ALL'); // for analytics view per social
  const [alertRules, setAlertRules]         = useState([]);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [newAlert, setNewAlert]             = useState({ name:'', type:'negative_surge', threshold:10, channels:['email'] });
  const feedRef = useRef(null);

  // ─── Auth Guard ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!authLoading && !user) router.push('/login');
  }, [user, authLoading]);

  // ─── Load campaigns ──────────────────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    campaignsAPI.list().then(res => {
      const cps = res.data.campaigns;
      setCampaigns(cps);
      if (cps.length > 0) setActiveCampaign(cps[0]);
    }).catch(() => toast.error('Error al cargar campañas'));
  }, [user]);

  // ─── Load data ───────────────────────────────────────────────────────────────
  const loadData = useCallback(async () => {
    if (!activeCampaign) return;
    setLoading(true);
    try {
      const geoSearch = [selectedProvincia, selectedCiudad].filter(Boolean).join(' ');
      // feedHours=0 significa "sin límite" — mostrar todo
      const fromDate = feedHours > 0
        ? new Date(Date.now() - feedHours * 60 * 60 * 1000).toISOString()
        : null;
      const params = {
        campaignId: activeCampaign.id,
        ...(sourceFilter !== 'ALL' && { source: sourceFilter }),
        ...(sentimentFilter !== 'ALL' && { sentiment: sentimentFilter }),
        ...((searchQuery || geoSearch) && { search: [searchQuery, geoSearch].filter(Boolean).join(' ') }),
        ...(fromDate && { from: fromDate }),
        page: mentionPage, limit: 20,
      };
      const [mentRes, analytRes, tsRes, kwRes, ucRes] = await Promise.allSettled([
        mentionsAPI.list(params),
        analyticsAPI.summary(activeCampaign.id, period),
        analyticsAPI.timeseries(activeCampaign.id, period),
        keywordsAPI.list(activeCampaign.id),
        mentionsAPI.unreadCount(activeCampaign.id),
      ]);
      if (mentRes.status==='fulfilled') { setMentions(mentRes.value.data.mentions); setTotalMentions(mentRes.value.data.pagination.total); }
      if (analytRes.status==='fulfilled') setAnalytics(analytRes.value.data);
      if (tsRes.status==='fulfilled') setTimeseries(tsRes.value.data.series||[]);
      if (kwRes.status==='fulfilled') setKeywords(kwRes.value.data.keywords);
      if (ucRes.status==='fulfilled') setUnreadCount(ucRes.value.data.count);
    } catch { toast.error('Error al cargar datos'); }
    finally { setLoading(false); }
  }, [activeCampaign, period, sourceFilter, sentimentFilter, searchQuery, mentionPage, selectedProvincia, selectedCiudad, feedHours]);

  useEffect(() => { loadData(); }, [loadData]);

  // ─── Auto-refresh ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!activeCampaign) return;
    const iv = setInterval(() => {
      analyticsAPI.summary(activeCampaign.id, period).then(r => setAnalytics(r.data)).catch(()=>{});
    }, 60000);
    return () => clearInterval(iv);
  }, [activeCampaign, period]);

  // ─── Socket ──────────────────────────────────────────────────────────────────
  useSocket(activeCampaign?.id, {
    onMentionsNew: ({ count }) => {
      setNewMentionsBanner(p => p+count);
      setUnreadCount(p => p+count);
      toast(`📡 ${count} nuevas menciones`, { icon:'🔔', duration:3000 });
    },
    onAlert: (data) => {
      setAlertBanner(data);
      toast.error(`⚠️ ALERTA: ${data.message}`, { duration:8000 });
    },
  });

  // ─── Keyword actions ─────────────────────────────────────────────────────────
  async function addKeyword() {
    const term = newKeyword.trim();
    if (!term || !activeCampaign) return;
    // Add geo suffix if province/city selected
    const geoSuffix = [selectedProvincia, selectedCiudad].filter(Boolean).join(' ');
    const fullTerm = geoSuffix ? `${term} ${geoSuffix}` : term;
    try {
      const res = await keywordsAPI.create({ term: fullTerm, campaignId: activeCampaign.id, color: KW_COLORS[keywords.length % KW_COLORS.length] });
      setKeywords(p => [...p, res.data.keyword]);
      setNewKeyword('');
      toast.success(`Keyword "${fullTerm}" agregada`);
    } catch (err) { toast.error(err.response?.data?.error||'Error al agregar keyword'); }
  }

  async function removeKeyword(id) {
    if (!confirm('¿Eliminar esta keyword?')) return;
    await keywordsAPI.delete(id);
    setKeywords(p => p.filter(k => k.id!==id));
    toast.success('Keyword eliminada');
  }

  async function saveEditKeyword() {
    if (!editingKw) return;
    try {
      // delete old + create new (API doesn't have PUT for term, so recreate)
      await keywordsAPI.delete(editingKw.id);
      const res = await keywordsAPI.create({ term: editingKw.term, campaignId: activeCampaign.id, color: editingKw.color });
      setKeywords(p => p.map(k => k.id===editingKw.id ? res.data.keyword : k));
      setEditingKw(null);
      toast.success('Keyword actualizada');
    } catch { toast.error('Error al editar'); }
  }

  // ─── Alert rules ─────────────────────────────────────────────────────────────
  async function createAlertRule() {
    if (!newAlert.name.trim()) return toast.error('Ingresá un nombre para la alerta');
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000'}/api/alerts/rules`, {
        method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${localStorage.getItem('pm_token')}`},
        body: JSON.stringify({ campaignId: activeCampaign.id, name: newAlert.name, condition: { type: newAlert.type, threshold: parseInt(newAlert.threshold) }, channels: newAlert.channels, recipients:[user.email] }),
      });
      const data = await res.json();
      setAlertRules(p => [...p, data.rule]);
      setShowAlertModal(false);
      setNewAlert({ name:'', type:'negative_surge', threshold:10, channels:['email'] });
      toast.success('Regla de alerta creada');
    } catch { toast.error('Error al crear alerta'); }
  }

  // ─── Geo filter ──────────────────────────────────────────────────────────────
  const ciudades = selectedProvincia ? ARGENTINA_GEO[selectedProvincia] || [] : [];

  // ─── Derived stats ───────────────────────────────────────────────────────────
  const sentimentData = analytics?.bySentiment?.map(s => ({
    name: s.sentiment==='POSITIVE'?'Positivo':s.sentiment==='NEGATIVE'?'Negativo':'Neutral',
    value: s.count, color: SENT_COLORS[s.sentiment],
  })) || [];
  const totalSent = sentimentData.reduce((a,b)=>a+b.value,0)||1;
  const posPercent = Math.round(((sentimentData.find(s=>s.name==='Positivo')?.value||0)/totalSent)*100);
  const negPercent = Math.round(((sentimentData.find(s=>s.name==='Negativo')?.value||0)/totalSent)*100);
  const sourceData = analytics?.bySource?.slice(0,5)||[];

  // Sentiment per source for analytics view
  const sentBySource = ['FACEBOOK','INSTAGRAM','TWITTER','NEWS','WEB'].map(src => {
    const srcMentions = mentions.filter(m => m.source===src);
    const pos = srcMentions.filter(m=>m.sentiment==='POSITIVE').length;
    const neg = srcMentions.filter(m=>m.sentiment==='NEGATIVE').length;
    const neu = srcMentions.filter(m=>m.sentiment==='NEUTRAL').length;
    return { source: src, icon: SRC_ICONS[src], Positivo:pos, Negativo:neg, Neutral:neu, total:pos+neg+neu };
  }).filter(s=>s.total>0);

  // ─── Views ───────────────────────────────────────────────────────────────────
  function renderMainContent() {
    if (sidebarView==='keywords') return <KeywordsView {...{keywords,newKeyword,setNewKeyword,addKeyword,removeKeyword,editingKw,setEditingKw,saveEditKeyword,KW_COLORS,selectedProvincia,setSelectedProvincia,selectedCiudad,setSelectedCiudad,ciudades,ARGENTINA_GEO}} />;
    if (sidebarView==='alerts') return <AlertsView {...{alertRules,setAlertRules,activeCampaign,showAlertModal,setShowAlertModal,newAlert,setNewAlert,createAlertRule,user}} />;
    if (sidebarView==='analytics') return <AnalyticsView {...{analytics,timeseries,sentimentData,totalSent,sourceData,sentBySource,period,setPeriod,setMentionPage,analyticsSrc,setAnalyticsSrc,SRC_COLORS,SRC_ICONS}} />;
    // default: feed
    return <FeedView {...{loading,mentions,totalMentions,mentionPage,setMentionPage,sourceFilter,setSourceFilter,sentimentFilter,setSentimentFilter,searchQuery,setSearchQuery,selectedProvincia,setSelectedProvincia,selectedCiudad,setSelectedCiudad,ciudades,ARGENTINA_GEO,mentionsAPI,setMentions,analytics,timeseries,sentimentData,totalSent,posPercent,negPercent,sourceData,period,setPeriod,feedHours,setFeedHours}} />;
  }

  if (authLoading) return null;

  return (
    <div style={{ display:'flex', flexDirection:'column', minHeight:'100vh' }}>

      {/* ALERT BANNER */}
      {alertBanner && (
        <div style={{ background:'#ef444415', borderBottom:'1px solid #ef444440', padding:'10px 24px', display:'flex', alignItems:'center', gap:'12px', fontSize:'13px', zIndex:50 }}>
          <span>🚨</span>
          <span style={{flex:1}}><strong>ALERTA:</strong> {alertBanner.message}</span>
          <button onClick={()=>setAlertBanner(null)} style={{background:'none',border:'none',color:'var(--text3)',cursor:'pointer',fontSize:'18px'}}>×</button>
        </div>
      )}

      {/* TOP BAR */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 24px', background:'var(--bg2)', borderBottom:'1px solid var(--border)', position:'sticky', top:0, zIndex:40 }}>
        <div style={{display:'flex',alignItems:'center',gap:'10px'}}>
          <div style={{width:'32px',height:'32px',borderRadius:'8px',background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'16px'}}>📡</div>
          <span style={{fontSize:'18px',fontWeight:'700'}}>PoliticaMonitor</span>
          <div style={{background:'#ef444420',border:'1px solid #ef4444',color:'#ef4444',fontSize:'11px',fontWeight:'600',padding:'3px 8px',borderRadius:'20px',display:'flex',alignItems:'center',gap:'5px'}}>
            <div className="pulse-dot" style={{width:'6px',height:'6px',background:'#ef4444',borderRadius:'50%'}}/>EN VIVO
          </div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
          <select value={activeCampaign?.id||''} onChange={e=>{const cp=campaigns.find(c=>c.id===e.target.value);if(cp){setActiveCampaign(cp);setMentionPage(1);}}} style={{background:'var(--bg3)',border:'1px solid var(--border2)',color:'var(--text)',padding:'7px 12px',borderRadius:'8px',fontSize:'13px',width:'auto'}}>
            {campaigns.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button className="btn btn-ghost" style={{fontSize:'12px',padding:'7px 12px'}} onClick={()=>setShowNewCampaign(true)}>+ Nueva</button>
          <button
            title="Eliminar campaña activa"
            onClick={async()=>{
              if(!activeCampaign) return;
              if(!confirm(`¿Eliminar la campaña "${activeCampaign.name}" y todas sus menciones?\n\nEsta acción no se puede deshacer.`)) return;
              try {
                await campaignsAPI.delete(activeCampaign.id);
                const remaining = campaigns.filter(c=>c.id!==activeCampaign.id);
                setCampaigns(remaining);
                setActiveCampaign(remaining[0]||null);
                toast.success('Campaña eliminada');
              } catch { toast.error('Error al eliminar campaña'); }
            }}
            style={{background:'#ef444415',border:'1px solid #ef444440',color:'#f87171',borderRadius:'8px',padding:'7px 10px',fontSize:'13px',cursor:'pointer',display:user?.role==='VIEWER'?'none':'inline-flex'}}
          >🗑</button>
          <button className="btn btn-ghost" style={{fontSize:'12px',padding:'7px 12px'}} onClick={()=>router.push('/reports')}>📊 Reportes</button>
          {user?.role==='ADMIN' && <button className="btn btn-ghost" style={{fontSize:'12px',padding:'7px 12px'}} onClick={()=>router.push('/users')}>👥 Usuarios</button>}
          <button className="btn btn-ghost" style={{fontSize:'12px',padding:'7px 12px'}} onClick={logout}>Salir</button>
        </div>
      </div>

      {/* NEW MENTION BANNER */}
      {newMentionsBanner>0 && (
        <button onClick={()=>{setNewMentionsBanner(0);setMentionPage(1);loadData();feedRef.current?.scrollTo(0,0);}} style={{background:'var(--accent)',border:'none',color:'#fff',padding:'10px',fontSize:'13px',fontWeight:'600',cursor:'pointer',width:'100%'}}>
          📡 {newMentionsBanner} nuevas menciones — Clic para actualizar
        </button>
      )}

      {/* LAYOUT */}
      <div style={{display:'flex',flex:1}}>

        {/* SIDEBAR */}
        <div style={{width:'240px',flexShrink:0,background:'var(--bg2)',borderRight:'1px solid var(--border)',padding:'16px 0',display:'flex',flexDirection:'column',overflowY:'auto'}}>
          {[
            {id:'feed',icon:'📡',label:'Feed en vivo',badge:unreadCount},
            {id:'analytics',icon:'📈',label:'Análisis'},
            {id:'keywords',icon:'🔑',label:'Palabras clave'},
            {id:'alerts',icon:'⚠️',label:'Alertas'},
          ].map(item=>(
            <div key={item.id} onClick={()=>setSidebarView(item.id)} style={{display:'flex',alignItems:'center',gap:'10px',padding:'10px 20px',cursor:'pointer',background:sidebarView===item.id?'var(--bg3)':'transparent',borderLeft:sidebarView===item.id?'3px solid var(--accent)':'3px solid transparent',color:sidebarView===item.id?'var(--accent2)':'var(--text2)',fontSize:'14px',transition:'all 0.15s'}}>
              <span>{item.icon}</span>
              <span style={{flex:1}}>{item.label}</span>
              {item.badge>0 && <span style={{background:'var(--red)',color:'#fff',fontSize:'11px',fontWeight:'700',padding:'2px 7px',borderRadius:'10px'}}>{item.badge>99?'99+':item.badge}</span>}
            </div>
          ))}
          <div onClick={()=>router.push('/sources')} style={{display:'flex',alignItems:'center',gap:'10px',padding:'10px 20px',cursor:'pointer',borderLeft:'3px solid transparent',color:'var(--text2)',fontSize:'14px'}}
            onMouseEnter={e=>e.currentTarget.style.background='var(--bg3)'}
            onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
            <span>🌐</span><span style={{flex:1}}>Mis páginas</span><span style={{fontSize:'10px',color:'var(--accent2)'}}>→</span>
          </div>

          {/* Geo quick filter */}
          <div style={{padding:'12px',borderTop:'1px solid var(--border)',marginTop:'8px'}}>
            <div style={{fontSize:'10px',fontWeight:'700',color:'var(--text3)',letterSpacing:'1.5px',textTransform:'uppercase',marginBottom:'8px'}}>Filtro Geográfico</div>
            <select value={selectedProvincia} onChange={e=>{
              const p = e.target.value;
              setSelectedProvincia(p);
              setSelectedCiudad('');
              setMentionPage(1);
              saveGeoToCampaign(p, '');
            }} style={{fontSize:'12px',padding:'6px 8px',marginBottom:'6px'}}>
              <option value=''>Todas las provincias</option>
              {Object.keys(ARGENTINA_GEO).map(p=><option key={p} value={p}>{p}</option>)}
            </select>
            {selectedProvincia && (
              <select value={selectedCiudad} onChange={e=>{
                const c = e.target.value;
                setSelectedCiudad(c);
                setMentionPage(1);
                saveGeoToCampaign(selectedProvincia, c);
              }} style={{fontSize:'12px',padding:'6px 8px'}}>
                <option value=''>Todas las ciudades</option>
                {ciudades.map(c=><option key={c} value={c}>{c}</option>)}
              </select>
            )}
            {(selectedProvincia||selectedCiudad) && (
              <button onClick={()=>{
                setSelectedProvincia('');
                setSelectedCiudad('');
                saveGeoToCampaign('', '');
              }} style={{marginTop:'6px',background:'none',border:'1px solid var(--border)',color:'var(--text3)',borderRadius:'6px',padding:'4px 8px',fontSize:'11px',cursor:'pointer',width:'100%'}}>✕ Limpiar filtro</button>
            )}
          </div>

          {/* Keywords mini list */}
          <div style={{padding:'0 12px 12px'}}>
            <div style={{fontSize:'10px',fontWeight:'700',color:'var(--text3)',letterSpacing:'1.5px',textTransform:'uppercase',marginBottom:'8px'}}>Keywords activas</div>
            {keywords.slice(0,6).map((kw,i)=>(
              <div key={kw.id} style={{display:'flex',alignItems:'center',gap:'6px',padding:'5px 8px',marginBottom:'4px',background:'var(--bg3)',borderRadius:'6px',fontSize:'12px'}}>
                <div style={{width:'7px',height:'7px',borderRadius:'50%',background:kw.color||KW_COLORS[i%KW_COLORS.length],flexShrink:0}}/>
                <span style={{flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',color:'var(--text)'}}>{kw.term}</span>
                <span style={{color:'var(--text3)',fontSize:'11px'}}>{kw._count?.mentions||0}</span>
              </div>
            ))}
            {keywords.length>6 && <div style={{fontSize:'11px',color:'var(--text3)',paddingLeft:'8px'}}>+{keywords.length-6} más</div>}
          </div>
        </div>

        {/* MAIN */}
        <div ref={feedRef} style={{flex:1,overflowY:'auto',padding:'24px',display:'flex',flexDirection:'column',gap:'20px'}}>

          {/* GEO INDICATOR */}
          {(selectedProvincia||selectedCiudad) && (
            <div style={{background:'#3b82f615',border:'1px solid #3b82f640',borderRadius:'8px',padding:'10px 16px',fontSize:'13px',display:'flex',alignItems:'center',gap:'8px'}}>
              <span>📍</span>
              <span>Filtrando por: <strong>{[selectedCiudad,selectedProvincia].filter(Boolean).join(', ')}</strong></span>
              <button onClick={()=>{setSelectedProvincia('');setSelectedCiudad('');}} style={{marginLeft:'auto',background:'none',border:'none',color:'var(--text3)',cursor:'pointer',fontSize:'16px'}}>×</button>
            </div>
          )}

          {renderMainContent()}
        </div>
      </div>

      {/* NEW CAMPAIGN MODAL */}
      {showNewCampaign && (
        <div style={{position:'fixed',inset:0,background:'#000000aa',zIndex:100,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={e=>e.target===e.currentTarget&&setShowNewCampaign(false)}>
          <div className="card" style={{width:'440px',padding:'28px'}}>
            <h2 style={{fontSize:'18px',fontWeight:'700',marginBottom:'6px'}}>Nueva campaña</h2>
            <p style={{color:'var(--text3)',fontSize:'13px',marginBottom:'20px'}}>Crea un nuevo espacio de monitoreo</p>
            <label>Nombre</label>
            <input value={newCampaignName} onChange={e=>setNewCampaignName(e.target.value)} placeholder="Ej: Campaña Presidencial 2027" onKeyDown={e=>e.key==='Enter'&&createCampaign()} style={{marginBottom:'16px'}}/>
            <div style={{display:'flex',gap:'10px',justifyContent:'flex-end'}}>
              <button className="btn btn-ghost" onClick={()=>setShowNewCampaign(false)}>Cancelar</button>
              <button className="btn btn-primary" onClick={async()=>{if(!newCampaignName.trim())return;const res=await campaignsAPI.create({name:newCampaignName});setCampaigns(p=>[...p,res.data.campaign]);setActiveCampaign(res.data.campaign);setNewCampaignName('');setShowNewCampaign(false);toast.success('Campaña creada');}}>Crear</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// KEYWORDS VIEW — gestión completa
// ══════════════════════════════════════════════════════════════════════════════
function KeywordsView({keywords,newKeyword,setNewKeyword,addKeyword,removeKeyword,editingKw,setEditingKw,saveEditKeyword,KW_COLORS,selectedProvincia,setSelectedProvincia,selectedCiudad,setSelectedCiudad,ciudades,ARGENTINA_GEO}) {
  return (
    <div style={{display:'flex',flexDirection:'column',gap:'20px'}}>
      <div className="card">
        <div style={{fontSize:'16px',fontWeight:'700',marginBottom:'4px'}}>🔑 Palabras clave monitoreadas</div>
        <div style={{fontSize:'13px',color:'var(--text3)',marginBottom:'20px'}}>Agregá, editá o eliminá los términos que el sistema busca en todas las fuentes</div>

        {/* ADD NEW */}
        <div style={{background:'var(--bg3)',border:'1px solid var(--border2)',borderRadius:'10px',padding:'16px',marginBottom:'20px'}}>
          <div style={{fontSize:'13px',fontWeight:'600',color:'var(--text2)',marginBottom:'12px'}}>➕ Agregar nueva keyword</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:'10px',alignItems:'end'}}>
            <div>
              <label>Término a monitorear</label>
              <input value={newKeyword} onChange={e=>setNewKeyword(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addKeyword()} placeholder="Ej: García Morales"/>
            </div>
            <div>
              <label>Provincia (opcional)</label>
              <select value={selectedProvincia} onChange={e=>{setSelectedProvincia(e.target.value);setSelectedCiudad('');}}>
                <option value=''>Sin filtro geográfico</option>
                {Object.keys(ARGENTINA_GEO).map(p=><option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label>Ciudad (opcional)</label>
              <select value={selectedCiudad} onChange={e=>setSelectedCiudad(e.target.value)} disabled={!selectedProvincia}>
                <option value=''>Todas las ciudades</option>
                {ciudades.map(c=><option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <button className="btn btn-primary" onClick={addKeyword} style={{height:'38px'}}>+ Agregar</button>
          </div>
          {(selectedProvincia||selectedCiudad) && (
            <div style={{marginTop:'8px',fontSize:'12px',color:'var(--accent2)'}}>
              💡 Se creará como: "<strong>{[newKeyword,selectedCiudad,selectedProvincia].filter(Boolean).join(' ')}</strong>"
            </div>
          )}
        </div>

        {/* LIST */}
        {keywords.length===0 ? (
          <div style={{textAlign:'center',padding:'40px',color:'var(--text3)'}}>
            <div style={{fontSize:'32px',marginBottom:'12px'}}>🔑</div>
            <p>No hay keywords todavía. Agregá la primera arriba.</p>
          </div>
        ) : (
          <div style={{display:'flex',flexDirection:'column',gap:'8px'}}>
            {keywords.map((kw,i)=>(
              <div key={kw.id} style={{display:'flex',alignItems:'center',gap:'12px',background:'var(--bg3)',border:'1px solid var(--border)',borderRadius:'8px',padding:'10px 14px'}}>
                <div style={{width:'10px',height:'10px',borderRadius:'50%',background:kw.color||KW_COLORS[i%KW_COLORS.length],flexShrink:0}}/>

                {editingKw?.id===kw.id ? (
                  <>
                    <input value={editingKw.term} onChange={e=>setEditingKw(p=>({...p,term:e.target.value}))} style={{flex:1,fontSize:'13px',padding:'4px 8px'}} autoFocus onKeyDown={e=>{if(e.key==='Enter')saveEditKeyword();if(e.key==='Escape')setEditingKw(null);}}/>
                    <button onClick={saveEditKeyword} style={{background:'var(--green)',color:'#fff',border:'none',borderRadius:'6px',padding:'5px 12px',cursor:'pointer',fontSize:'12px',fontWeight:'600'}}>✓ Guardar</button>
                    <button onClick={()=>setEditingKw(null)} style={{background:'none',border:'1px solid var(--border)',color:'var(--text3)',borderRadius:'6px',padding:'5px 10px',cursor:'pointer',fontSize:'12px'}}>Cancelar</button>
                  </>
                ) : (
                  <>
                    <span style={{flex:1,fontWeight:'600',fontSize:'14px'}}>{kw.term}</span>
                    <span style={{fontSize:'12px',color:'var(--text3)',marginRight:'8px'}}>{kw._count?.mentions||0} menciones</span>
                    <button onClick={()=>setEditingKw({id:kw.id,term:kw.term,color:kw.color})} style={{background:'var(--bg4)',border:'1px solid var(--border2)',color:'var(--accent2)',borderRadius:'6px',padding:'5px 10px',cursor:'pointer',fontSize:'12px',fontWeight:'600'}}>✏️ Editar</button>
                    <button onClick={()=>removeKeyword(kw.id)} style={{background:'#ef444415',border:'1px solid #ef444440',color:'#f87171',borderRadius:'6px',padding:'5px 10px',cursor:'pointer',fontSize:'12px',fontWeight:'600'}}>🗑 Eliminar</button>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// ALERTS VIEW — crear y gestionar reglas
// ══════════════════════════════════════════════════════════════════════════════
function AlertsView({alertRules,setAlertRules,activeCampaign,showAlertModal,setShowAlertModal,newAlert,setNewAlert,createAlertRule,user}) {
  const ALERT_TYPES = [
    {value:'negative_surge',label:'Pico de menciones negativas',desc:'Se dispara cuando hay muchas menciones negativas nuevas'},
    {value:'mention_spike',label:'Pico de menciones general',desc:'Se dispara cuando el volumen total sube abruptamente'},
    {value:'keyword_mention',label:'Mención de keyword específica',desc:'Alerta cada vez que se menciona una palabra exacta'},
  ];

  return (
    <div style={{display:'flex',flexDirection:'column',gap:'20px'}}>
      <div className="card">
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'20px'}}>
          <div>
            <div style={{fontSize:'16px',fontWeight:'700'}}>⚠️ Reglas de alerta</div>
            <div style={{fontSize:'13px',color:'var(--text3)',marginTop:'2px'}}>Recibí notificaciones automáticas cuando ocurre algo importante</div>
          </div>
          <button className="btn btn-primary" onClick={()=>setShowAlertModal(true)}>+ Nueva alerta</button>
        </div>

        {alertRules.length===0 ? (
          <div style={{textAlign:'center',padding:'48px',color:'var(--text3)'}}>
            <div style={{fontSize:'40px',marginBottom:'12px'}}>⚠️</div>
            <p style={{marginBottom:'16px'}}>No hay reglas de alerta todavía.</p>
            <button className="btn btn-primary" onClick={()=>setShowAlertModal(true)}>Crear primera alerta</button>
          </div>
        ) : (
          <div style={{display:'flex',flexDirection:'column',gap:'10px'}}>
            {alertRules.map(rule=>(
              <div key={rule.id} style={{background:'var(--bg3)',border:'1px solid var(--border)',borderRadius:'10px',padding:'14px 16px',display:'flex',alignItems:'center',gap:'12px'}}>
                <div style={{width:'10px',height:'10px',borderRadius:'50%',background:rule.isActive?'var(--green)':'var(--text3)',flexShrink:0}}/>
                <div style={{flex:1}}>
                  <div style={{fontWeight:'700',fontSize:'14px'}}>{rule.name}</div>
                  <div style={{fontSize:'12px',color:'var(--text3)',marginTop:'2px'}}>
                    {ALERT_TYPES.find(t=>t.value===JSON.parse(rule.condition||'{}').type)?.label||'Alerta'} · Canales: {rule.channels?.join(', ')}
                  </div>
                </div>
                <span style={{background:rule.isActive?'#10b98120':'#64748b20',color:rule.isActive?'#10b981':'#64748b',border:`1px solid ${rule.isActive?'#10b98140':'#64748b40'}`,padding:'3px 10px',borderRadius:'10px',fontSize:'12px',fontWeight:'600'}}>
                  {rule.isActive?'Activa':'Pausada'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cómo funcionan */}
      <div className="card">
        <div style={{fontSize:'14px',fontWeight:'700',marginBottom:'12px'}}>💡 ¿Cómo funcionan las alertas?</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'12px'}}>
          {ALERT_TYPES.map(t=>(
            <div key={t.value} style={{background:'var(--bg3)',border:'1px solid var(--border)',borderRadius:'8px',padding:'12px'}}>
              <div style={{fontWeight:'600',fontSize:'13px',marginBottom:'4px'}}>{t.label}</div>
              <div style={{fontSize:'12px',color:'var(--text3)'}}>{t.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL */}
      {showAlertModal && (
        <div style={{position:'fixed',inset:0,background:'#000000aa',zIndex:100,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={e=>e.target===e.currentTarget&&setShowAlertModal(false)}>
          <div className="card" style={{width:'500px',padding:'28px'}}>
            <div style={{fontSize:'18px',fontWeight:'700',marginBottom:'4px'}}>⚠️ Nueva regla de alerta</div>
            <div style={{fontSize:'13px',color:'var(--text3)',marginBottom:'20px'}}>Configurá cuándo y cómo querés ser notificado</div>
            <div style={{display:'flex',flexDirection:'column',gap:'14px'}}>
              <div>
                <label>Nombre de la alerta</label>
                <input value={newAlert.name} onChange={e=>setNewAlert(p=>({...p,name:e.target.value}))} placeholder="Ej: Crisis en redes sociales"/>
              </div>
              <div>
                <label>Tipo de alerta</label>
                <select value={newAlert.type} onChange={e=>setNewAlert(p=>({...p,type:e.target.value}))}>
                  {ALERT_TYPES.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label>Umbral (cantidad de menciones que lo activa)</label>
                <input type="number" value={newAlert.threshold} onChange={e=>setNewAlert(p=>({...p,threshold:e.target.value}))} min="1" max="1000"/>
              </div>
              <div>
                <label>Canal de notificación</label>
                <div style={{display:'flex',gap:'10px',marginTop:'4px'}}>
                  {['email','whatsapp'].map(ch=>(
                    <label key={ch} style={{display:'flex',alignItems:'center',gap:'6px',cursor:'pointer',fontSize:'13px',color:'var(--text2)'}}>
                      <input type="checkbox" checked={newAlert.channels.includes(ch)} onChange={e=>{setNewAlert(p=>({...p,channels:e.target.checked?[...p.channels,ch]:p.channels.filter(x=>x!==ch)}));}} style={{width:'auto'}}/>
                      {ch==='email'?'📧 Email':'📱 WhatsApp'}
                    </label>
                  ))}
                </div>
              </div>
              <div style={{background:'var(--bg3)',borderRadius:'8px',padding:'10px 12px',fontSize:'12px',color:'var(--text3)'}}>
                Las notificaciones se enviarán a: <strong style={{color:'var(--text2)'}}>{user?.email}</strong>
              </div>
            </div>
            <div style={{display:'flex',gap:'10px',justifyContent:'flex-end',marginTop:'20px'}}>
              <button className="btn btn-ghost" onClick={()=>setShowAlertModal(false)}>Cancelar</button>
              <button className="btn btn-primary" onClick={createAlertRule}>Crear alerta</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// ANALYTICS VIEW — gráficos completos por red social y sentimiento
// ══════════════════════════════════════════════════════════════════════════════
function AnalyticsView({analytics,timeseries,sentimentData,totalSent,sourceData,sentBySource,period,setPeriod,setMentionPage,analyticsSrc,setAnalyticsSrc,SRC_COLORS,SRC_ICONS}) {
  const sources = ['ALL','FACEBOOK','INSTAGRAM','TWITTER','NEWS','WEB'];
  const filtered = analyticsSrc==='ALL' ? timeseries : timeseries; // in production filter by source

  return (
    <div style={{display:'flex',flexDirection:'column',gap:'20px'}}>

      {/* Period + source filter */}
      <div style={{display:'flex',alignItems:'center',gap:'12px',flexWrap:'wrap'}}>
        <div style={{display:'flex',gap:'4px'}}>
          {[{v:'1h',l:'1 hora'},{v:'24h',l:'24h'},{v:'7d',l:'7 días'},{v:'30d',l:'30 días'}].map(p=>(
            <button key={p.v} onClick={()=>{setPeriod(p.v);setMentionPage(1);}} style={{padding:'6px 14px',borderRadius:'6px',border:'none',fontSize:'12px',fontWeight:'600',cursor:'pointer',background:period===p.v?'var(--accent)':'var(--bg3)',color:period===p.v?'#fff':'var(--text3)'}}>
              {p.l}
            </button>
          ))}
        </div>
        <div style={{display:'flex',gap:'4px',marginLeft:'auto'}}>
          {sources.map(src=>(
            <button key={src} onClick={()=>setAnalyticsSrc(src)} style={{padding:'6px 12px',borderRadius:'20px',border:'1px solid var(--border)',fontSize:'12px',fontWeight:'600',cursor:'pointer',background:analyticsSrc===src?(SRC_COLORS[src]||'var(--accent)'):'var(--bg3)',color:analyticsSrc===src?'#fff':'var(--text2)'}}>
              {SRC_ICONS[src]||'🔍'} {src==='ALL'?'Todas':src}
            </button>
          ))}
        </div>
      </div>

      {/* SENTIMENT OVER TIME */}
      <div className="card">
        <div style={{fontSize:'14px',fontWeight:'700',marginBottom:'16px'}}>📈 Evolución de sentimiento en el tiempo</div>
        <div style={{height:'220px'}}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timeseries} margin={{top:5,right:10,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e3058"/>
              <XAxis dataKey="time" tick={{fill:'#64748b',fontSize:11}} tickFormatter={v=>v?format(new Date(v),'HH:mm'):''}/>
              <YAxis tick={{fill:'#64748b',fontSize:11}}/>
              <Tooltip contentStyle={{background:'#1a2235',border:'1px solid #2d4a7a',borderRadius:'8px',color:'#f1f5f9'}} labelFormatter={v=>v?format(new Date(v),'dd/MM HH:mm'):''}/>
              <Legend wrapperStyle={{fontSize:'12px',color:'#94a3b8'}}/>
              <Line type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={2} dot={false} name="Total"/>
              <Line type="monotone" dataKey="positive" stroke="#10b981" strokeWidth={2} dot={false} name="Positivo"/>
              <Line type="monotone" dataKey="negative" stroke="#ef4444" strokeWidth={2} dot={false} name="Negativo"/>
              <Line type="monotone" dataKey="neutral" stroke="#64748b" strokeWidth={1.5} dot={false} name="Neutral" strokeDasharray="4 2"/>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* SENTIMENT PER SOURCE */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'16px'}}>
        <div className="card">
          <div style={{fontSize:'14px',fontWeight:'700',marginBottom:'16px'}}>😊⚠️😐 Sentimiento por red social</div>
          {sentBySource.length===0 ? (
            <div style={{textAlign:'center',padding:'32px',color:'var(--text3)'}}>Sin datos suficientes aún</div>
          ) : (
            <div style={{height:'220px'}}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sentBySource} margin={{top:0,right:10,left:-10,bottom:0}}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e3058"/>
                  <XAxis dataKey="source" tick={{fill:'#64748b',fontSize:11}}/>
                  <YAxis tick={{fill:'#64748b',fontSize:11}}/>
                  <Tooltip contentStyle={{background:'#1a2235',border:'1px solid #2d4a7a',borderRadius:'8px'}}/>
                  <Legend wrapperStyle={{fontSize:'11px'}}/>
                  <Bar dataKey="Positivo" stackId="a" fill="#10b981" radius={[0,0,0,0]}/>
                  <Bar dataKey="Negativo" stackId="a" fill="#ef4444"/>
                  <Bar dataKey="Neutral" stackId="a" fill="#64748b" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="card">
          <div style={{fontSize:'14px',fontWeight:'700',marginBottom:'16px'}}>🥧 Distribución de sentimiento</div>
          <div style={{height:'140px',display:'flex',justifyContent:'center'}}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={sentimentData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={2} label={({name,percent})=>`${name} ${(percent*100).toFixed(0)}%`} labelLine={false}>
                  {sentimentData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                </Pie>
                <Tooltip contentStyle={{background:'#1a2235',border:'1px solid #2d4a7a',borderRadius:'8px'}}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:'8px',marginTop:'12px'}}>
            {sentimentData.map((s,i)=>(
              <div key={i} style={{display:'flex',alignItems:'center',gap:'8px',fontSize:'13px'}}>
                <div style={{width:'10px',height:'10px',borderRadius:'50%',background:s.color}}/>
                <span style={{flex:1,color:'var(--text2)'}}>{s.name}</span>
                <div style={{width:'100px',height:'6px',background:'var(--bg3)',borderRadius:'3px',overflow:'hidden'}}>
                  <div style={{height:'100%',width:`${Math.round((s.value/totalSent)*100)}%`,background:s.color,borderRadius:'3px'}}/>
                </div>
                <span style={{fontWeight:'700',minWidth:'32px',textAlign:'right'}}>{Math.round((s.value/totalSent)*100)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SOURCE VOLUME */}
      <div className="card">
        <div style={{fontSize:'14px',fontWeight:'700',marginBottom:'16px'}}>📊 Volumen de menciones por fuente</div>
        <div style={{height:'160px'}}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={sourceData} margin={{top:0,right:10,left:-10,bottom:0}}>
              <XAxis dataKey="source" tick={{fill:'#64748b',fontSize:11}}/>
              <YAxis tick={{fill:'#64748b',fontSize:11}}/>
              <Tooltip contentStyle={{background:'#1a2235',border:'1px solid #2d4a7a',borderRadius:'8px'}}/>
              <Bar dataKey="count" name="Menciones" radius={[4,4,0,0]}>
                {sourceData.map((e,i)=><Cell key={i} fill={SRC_COLORS[e.source]||'#3b82f6'}/>)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* PER SOURCE DETAIL */}
      {sentBySource.length>0 && (
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))',gap:'12px'}}>
          {sentBySource.map(src=>{
            const pos=src.Positivo, neg=src.Negativo, neu=src.Neutral, tot=src.total||1;
            return (
              <div key={src.source} className="card" style={{padding:'14px'}}>
                <div style={{display:'flex',alignItems:'center',gap:'8px',marginBottom:'12px'}}>
                  <span style={{fontSize:'20px'}}>{src.icon}</span>
                  <span style={{fontWeight:'700',fontSize:'14px'}}>{src.source}</span>
                  <span style={{marginLeft:'auto',fontSize:'12px',color:'var(--text3)'}}>{src.total}</span>
                </div>
                <div style={{display:'flex',height:'8px',borderRadius:'4px',overflow:'hidden',gap:'2px'}}>
                  {pos>0 && <div style={{flex:pos,background:'#10b981'}}/>}
                  {neg>0 && <div style={{flex:neg,background:'#ef4444'}}/>}
                  {neu>0 && <div style={{flex:neu,background:'#64748b'}}/>}
                </div>
                <div style={{display:'flex',justifyContent:'space-between',marginTop:'8px',fontSize:'11px',color:'var(--text3)'}}>
                  <span style={{color:'#10b981'}}>😊 {Math.round(pos/tot*100)}%</span>
                  <span style={{color:'#ef4444'}}>⚠️ {Math.round(neg/tot*100)}%</span>
                  <span>😐 {Math.round(neu/tot*100)}%</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// FEED VIEW
// ══════════════════════════════════════════════════════════════════════════════
function FeedView({loading,mentions,totalMentions,mentionPage,setMentionPage,sourceFilter,setSourceFilter,sentimentFilter,setSentimentFilter,searchQuery,setSearchQuery,selectedProvincia,setSelectedProvincia,selectedCiudad,setSelectedCiudad,ciudades,ARGENTINA_GEO,mentionsAPI,setMentions,analytics,timeseries,sentimentData,totalSent,posPercent,negPercent,sourceData,period,setPeriod,feedHours,setFeedHours}) {
  const SRC_COLORS2 = { WEB:'#0ea5e9', TWITTER:'#1d9bf0', FACEBOOK:'#1877f2', INSTAGRAM:'#e1306c', NEWS:'#f59e0b' };
  const SRC_ICONS2  = { WEB:'🌐', TWITTER:'🐦', FACEBOOK:'📘', INSTAGRAM:'📸', NEWS:'📰' };

  return (
    <div style={{display:'flex',flexDirection:'column',gap:'20px'}}>
      {/* STATS */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'16px'}}>
        {[
          {label:'Menciones totales',value:fmtNum(analytics?.mentions?.total||0),delta:`${(analytics?.mentions?.delta||0)>=0?'↑':'↓'} ${Math.abs(analytics?.mentions?.delta||0)}% vs anterior`,color:'#60a5fa',up:(analytics?.mentions?.delta||0)>=0},
          {label:'Sentimiento positivo',value:posPercent+'%',delta:'período actual',color:'#10b981',up:true},
          {label:'Sentimiento negativo',value:negPercent+'%',delta:negPercent>30?'⚠️ requiere atención':'bajo control',color:'#ef4444',up:false},
          {label:'Alcance estimado',value:fmtNum(analytics?.reach||0),delta:'personas impactadas',color:'#8b5cf6',up:true},
        ].map((s,i)=>(
          <div key={i} className="card" style={{padding:'16px 20px'}}>
            <div style={{fontSize:'11px',color:'var(--text3)',fontWeight:'500',textTransform:'uppercase',letterSpacing:'0.5px',marginBottom:'6px'}}>{s.label}</div>
            <div style={{fontSize:'28px',fontWeight:'700',color:s.color,lineHeight:1,marginBottom:'4px'}}>{s.value}</div>
            <div style={{fontSize:'12px',color:s.up?'#10b981':'#ef4444'}}>{s.delta}</div>
          </div>
        ))}
      </div>

      {/* MINI CHART */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 280px',gap:'16px'}}>
        <div className="card">
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'12px'}}>
            <div style={{fontSize:'14px',fontWeight:'700'}}>Volumen de menciones</div>
            <div style={{display:'flex',gap:'4px'}}>
              {[{v:'1h',l:'1h'},{v:'24h',l:'24h'},{v:'7d',l:'7d'},{v:'30d',l:'30d'}].map(p=>(
                <button key={p.v} onClick={()=>{setPeriod(p.v);setMentionPage(1);}} style={{padding:'4px 10px',borderRadius:'5px',border:'none',fontSize:'11px',fontWeight:'600',cursor:'pointer',background:period===p.v?'var(--accent)':'var(--bg3)',color:period===p.v?'#fff':'var(--text3)'}}>{p.l}</button>
              ))}
            </div>
          </div>
          <div style={{height:'160px'}}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeseries} margin={{top:5,right:10,left:-10,bottom:5}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e3058"/>
                <XAxis dataKey="time" tick={{fill:'#64748b',fontSize:10}} tickFormatter={v=>v?format(new Date(v),'HH:mm'):''}/>
                <YAxis tick={{fill:'#64748b',fontSize:10}}/>
                <Tooltip contentStyle={{background:'#1a2235',border:'1px solid #2d4a7a',borderRadius:'8px',color:'#f1f5f9'}}/>
                <Line type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={2} dot={false} name="Total"/>
                <Line type="monotone" dataKey="negative" stroke="#ef4444" strokeWidth={1.5} dot={false} name="Neg"/>
                <Line type="monotone" dataKey="positive" stroke="#10b981" strokeWidth={1.5} dot={false} name="Pos"/>
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card">
          <div style={{fontSize:'14px',fontWeight:'700',marginBottom:'12px'}}>Sentimiento</div>
          <div style={{height:'100px',display:'flex',justifyContent:'center'}}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={sentimentData} cx="50%" cy="50%" innerRadius={30} outerRadius={48} dataKey="value" paddingAngle={2}>
                  {sentimentData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                </Pie>
                <Tooltip contentStyle={{background:'#1a2235',border:'1px solid #2d4a7a',borderRadius:'8px'}}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:'5px',marginTop:'8px'}}>
            {sentimentData.map((s,i)=>(
              <div key={i} style={{display:'flex',alignItems:'center',gap:'6px',fontSize:'12px'}}>
                <div style={{width:'8px',height:'8px',borderRadius:'50%',background:s.color}}/>
                <span style={{flex:1,color:'var(--text2)'}}>{s.name}</span>
                <span style={{fontWeight:'700'}}>{Math.round((s.value/totalSent)*100)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* MENTIONS FEED */}
      <div className="card">
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'14px',flexWrap:'wrap',gap:'10px'}}>
          <div>
            <div style={{fontSize:'14px',fontWeight:'700'}}>Feed de menciones</div>
            <div style={{fontSize:'12px',color:'var(--text3)'}}>{totalMentions.toLocaleString()} menciones · {feedHours===0?'todo el historial':`últimas ${feedHours}h`}</div>
          </div>
          <div style={{display:'flex',gap:'6px',flexWrap:'wrap',alignItems:'center'}}>
            {/* Filtro de tiempo */}
            <select value={feedHours} onChange={e=>{setFeedHours(Number(e.target.value));setMentionPage(1);}} style={{padding:'5px 10px',borderRadius:'20px',border:'1px solid var(--border)',fontSize:'12px',fontWeight:'600',background:'var(--bg3)',color:'var(--text2)',cursor:'pointer'}}>
              <option value={0}>📅 Todo el historial</option>
              <option value={6}>⏱ 6 horas</option>
              <option value={24}>⏱ 24 horas</option>
              <option value={48}>⏱ 48 horas</option>
              <option value={168}>⏱ 7 días</option>
              <option value={720}>⏱ 30 días</option>
            </select>
            <input value={searchQuery} onChange={e=>{setSearchQuery(e.target.value);setMentionPage(1);}} placeholder="🔍 Buscar..." style={{width:'150px',padding:'6px 10px',fontSize:'12px'}}/>
            {['ALL','WEB','TWITTER','FACEBOOK','INSTAGRAM','NEWS'].map(src=>(
              <button key={src} onClick={()=>{setSourceFilter(src);setMentionPage(1);}} style={{padding:'5px 10px',borderRadius:'20px',border:'1px solid var(--border)',fontSize:'12px',fontWeight:'600',cursor:'pointer',background:sourceFilter===src?(SRC_COLORS2[src]||'var(--accent)'):'var(--bg3)',color:sourceFilter===src?'#fff':'var(--text2)'}}>
                {SRC_ICONS2[src]||'🔍'} {src==='ALL'?'Todos':src}
              </button>
            ))}
            {['ALL','POSITIVE','NEGATIVE','NEUTRAL'].map(sent=>(
              <button key={sent} onClick={()=>{setSentimentFilter(sent);setMentionPage(1);}} style={{padding:'5px 10px',borderRadius:'20px',border:'1px solid var(--border)',fontSize:'12px',fontWeight:'600',cursor:'pointer',background:sentimentFilter===sent?({'POSITIVE':'#10b981','NEGATIVE':'#ef4444','NEUTRAL':'#64748b'}[sent]||'var(--accent)'):'transparent',color:sentimentFilter===sent?'#fff':'var(--text3)'}}>
                {sent==='ALL'?'😊⚠️😐':sent==='POSITIVE'?'😊 Pos':sent==='NEGATIVE'?'⚠️ Neg':'😐 Neu'}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div style={{textAlign:'center',padding:'40px',color:'var(--text3)'}}>⏳ Cargando menciones...</div>
        ) : mentions.length===0 ? (
          <div style={{textAlign:'center',padding:'40px',color:'var(--text3)'}}>
            <div style={{fontSize:'40px',marginBottom:'12px'}}>📡</div>
            <p>No hay menciones todavía. Agregá keywords y esperá el próximo ciclo de scraping.</p>
          </div>
        ) : (
          <>
            <div style={{display:'flex',flexDirection:'column',gap:'10px'}}>
              {mentions.map(m=>(
                <MentionCard key={m.id} mention={m} onDelete={()=>{mentionsAPI.delete(m.id);setMentions(p=>p.filter(x=>x.id!==m.id));}}/>
              ))}
            </div>
            <div style={{display:'flex',justifyContent:'center',gap:'8px',marginTop:'20px'}}>
              <button className="btn btn-ghost" disabled={mentionPage<=1} onClick={()=>setMentionPage(p=>p-1)}>← Anterior</button>
              <span style={{padding:'8px 16px',color:'var(--text3)',fontSize:'13px'}}>Pág {mentionPage} de {Math.ceil(totalMentions/20)}</span>
              <button className="btn btn-ghost" disabled={mentionPage>=Math.ceil(totalMentions/20)} onClick={()=>setMentionPage(p=>p+1)}>Siguiente →</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MENTION CARD
// ══════════════════════════════════════════════════════════════════════════════
function MentionCard({ mention: m, onDelete }) {
  const sentClass = {
    POSITIVE:{bg:'#10b98120',color:'#34d399',border:'#10b98140',label:'😊 Positivo'},
    NEGATIVE:{bg:'#ef444420',color:'#f87171',border:'#ef444440',label:'⚠️ Negativo'},
    NEUTRAL:{bg:'#64748b20',color:'#94a3b8',border:'#64748b40',label:'😐 Neutral'},
  };
  const sent = sentClass[m.sentiment]||sentClass.NEUTRAL;
  const SRC_ICONS3  = {WEB:'🌐',TWITTER:'🐦',FACEBOOK:'📘',INSTAGRAM:'📸',NEWS:'📰'};
  const SRC_COLORS3 = {WEB:'#0ea5e9',TWITTER:'#1d9bf0',FACEBOOK:'#1877f2',INSTAGRAM:'#e1306c',NEWS:'#f59e0b'};
  return (
    <div className="animate-slide-in" style={{background:'var(--bg3)',border:'1px solid var(--border)',borderRadius:'10px',padding:'14px 16px'}}>
      <div style={{display:'flex',alignItems:'center',gap:'8px',marginBottom:'8px',flexWrap:'wrap'}}>
        <span style={{display:'flex',alignItems:'center',gap:'5px',background:`${SRC_COLORS3[m.source]||'#3b82f6'}20`,color:SRC_COLORS3[m.source]||'#60a5fa',border:`1px solid ${SRC_COLORS3[m.source]||'#3b82f6'}40`,padding:'3px 8px',borderRadius:'12px',fontSize:'11px',fontWeight:'700'}}>
          {SRC_ICONS3[m.source]||'🌐'} {m.source}
        </span>
        {m.keyword && <span style={{background:'var(--bg4)',border:'1px solid var(--border2)',color:'var(--accent2)',fontSize:'11px',fontWeight:'600',padding:'3px 8px',borderRadius:'12px'}}>#{m.keyword.term}</span>}
        <span style={{marginLeft:'auto',fontSize:'11px',color:'var(--text3)'}}>{timeAgo(m.publishedAt)}</span>
        <button onClick={onDelete} style={{background:'none',border:'none',color:'var(--text3)',cursor:'pointer',fontSize:'14px',padding:'2px 4px'}} title="Eliminar">✕</button>
      </div>
      <div style={{fontSize:'13px',color:'var(--text)',lineHeight:'1.6',marginBottom:'8px'}}>
        {m.content.slice(0,280)}{m.content.length>280?'...':''}
      </div>
      <div style={{display:'flex',alignItems:'center',gap:'12px',fontSize:'12px',color:'var(--text3)',flexWrap:'wrap'}}>
        <span style={{background:sent.bg,color:sent.color,border:`1px solid ${sent.border}`,padding:'2px 8px',borderRadius:'10px',fontSize:'11px',fontWeight:'600'}}>{sent.label}</span>
        {m.reach>0 && <span>👁️ {fmtNum(m.reach)} alcance</span>}
        {m.author && <span>— {m.author}</span>}
        {m.sourceName && <span>· {m.sourceName}</span>}
        {m.sourceUrl && <a href={m.sourceUrl} target="_blank" rel="noopener noreferrer" style={{color:'var(--accent2)',fontSize:'12px'}}>🔗 Ver fuente</a>}
      </div>
    </div>
  );
}
